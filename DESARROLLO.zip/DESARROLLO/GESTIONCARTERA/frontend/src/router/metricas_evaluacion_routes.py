from flask import Blueprint, flash, redirect, render_template, request, url_for

from src.services import backend_client
from src.store.session_store import get_current_roles, get_token, is_authenticated, logout_user

metricas_evaluacion_bp = Blueprint("metricas_evaluacion", __name__, url_prefix="/scoring-morosidad/metricas-evaluacion")

ROLES_AUTORIZADOS = {"ADMINISTRADOR", "SUPERVISOR DE CARTERA"}


def _require_autorizado():
    if not is_authenticated():
        return redirect(url_for("main.login"))
    if not ROLES_AUTORIZADOS & set(get_current_roles()):
        flash("No tienes permiso para acceder a Métricas de evaluación del modelo.", "error")
        return redirect(url_for("scoring.index"))
    return None


def _handle_unauthorized(response) -> bool:
    if response.status_code == 401:
        logout_user(request.remote_addr)
        flash("Tu sesión expiró, inicia sesión nuevamente.", "error")
        return True
    return False


@metricas_evaluacion_bp.route("/")
def index():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    return render_template("pages/scoring/metricas_index.html")


@metricas_evaluacion_bp.route("/comparativo-alternativas")
def comparativo_alternativas():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    response = backend_client.get("/api/metricas-evaluacion/comparativo-alternativas", token=get_token())
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if response.status_code != 200:
        flash("No se pudo consultar la matriz comparativa de alternativas.", "error")
        return redirect(url_for("metricas_evaluacion.index"))
    return render_template("pages/scoring/metricas_comparativo.html", filas=response.json())


@metricas_evaluacion_bp.route("/desempeno-produccion")
def desempeno_produccion():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    response = backend_client.get("/api/metricas-evaluacion/desempeno-produccion", token=get_token())
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if response.status_code != 200:
        flash("No se pudo consultar el desempeño observado en producción.", "error")
        return redirect(url_for("metricas_evaluacion.index"))
    return render_template("pages/scoring/metricas_desempeno_produccion.html", datos=response.json())


@metricas_evaluacion_bp.route("/declarado-vs-observado")
def declarado_vs_observado():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    response = backend_client.get("/api/metricas-evaluacion/declarado-vs-observado", token=get_token())
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if response.status_code != 200:
        flash("No se pudo consultar el contraste declarado vs. observado.", "error")
        return redirect(url_for("metricas_evaluacion.index"))
    return render_template("pages/scoring/metricas_declarado_vs_observado.html", filas=response.json())
