from flask import Blueprint, flash, jsonify, redirect, render_template, request, send_file, url_for
from flask_wtf import FlaskForm

from src.entities import EntityDef
from src.services import backend_client
from src.services.excel_export import facturas_a_excel, nombre_archivo
from src.services.lookup_client import fetch_filter_options, fetch_options
from src.store.session_store import get_token, is_authenticated, logout_user
from src.utils.pagination import paginar


def _require_login():
    if not is_authenticated():
        return redirect(url_for("main.login"))
    return None


def _handle_unauthorized(response) -> bool:
    if response.status_code == 401:
        logout_user(request.remote_addr)
        flash("Tu sesión expiró, inicia sesión nuevamente.", "error")
        return True
    return False


def _flash_error(response) -> None:
    try:
        body = response.json()
    except ValueError:
        body = {}
    if "errores" in body:
        for mensaje in body["errores"].values():
            flash(mensaje, "error")
    elif "error" in body:
        flash(body["error"], "error")
    else:
        flash("Ocurrió un error al procesar la solicitud.", "error")


def _filtros_factura_desde_query() -> dict:
    return {
        "NumeroFactura": request.args.get("NumeroFactura") or None,
        "FechaEmision": request.args.get("FechaEmision") or None,
        "VendedorId": request.args.get("VendedorId") or None,
        "ClienteId": request.args.get("ClienteId") or None,
        "EstadoFacturaId": request.args.get("EstadoFacturaId") or None,
        "PlazoPagoId": request.args.get("PlazoPagoId") or None,
        "FechaVencimiento": request.args.get("FechaVencimiento") or None,
    }


def _filtros_cliente_desde_query() -> dict:
    return {
        "ClienteId": request.args.get("ClienteId") or None,
        "Nombre": request.args.get("Nombre") or None,
        "Identificacion": request.args.get("Identificacion") or None,
        "CiudadId": request.args.get("CiudadId") or None,
        "SegmentoRiesgoId": request.args.get("SegmentoRiesgoId") or None,
        "ClasificacionId": request.args.get("ClasificacionId") or None,
        "PlazoPagoId": request.args.get("PlazoPagoId") or None,
    }


def _filtros_abono_desde_query() -> dict:
    return {
        "FechaRegistro": request.args.get("FechaRegistro") or None,
        "NumeroFactura": request.args.get("NumeroFactura") or None,
        "AbonoId": request.args.get("AbonoId") or None,
        "FechaAbono": request.args.get("FechaAbono") or None,
        "FormaPagoId": request.args.get("FormaPagoId") or None,
        "ClienteId": request.args.get("ClienteId") or None,
        "UsuarioId": request.args.get("UsuarioId") or None,
    }


def _payload_from_form(entity: EntityDef, form) -> dict:
    payload = {}
    for field in entity.fields:
        if not field.editable:
            continue
        if field.type == "checkbox":
            payload[field.column] = field.column in form
        else:
            payload[field.column] = form.get(field.column, "")
    return payload


def make_admin_blueprint(entity: EntityDef) -> Blueprint:
    bp = Blueprint(f"admin_{entity.key}", __name__, url_prefix=f"/admin/{entity.key}")

    def _options_for_form() -> dict:
        return {f.column: fetch_options(f.fk_lookup) for f in entity.fields if f.fk_lookup}

    def _options_for_abono_nuevo() -> dict:
        """Para un abono nuevo, el combo de Factura solo debe ofrecer
        facturas con saldo pendiente (sp_FacturasConSaldo), no todas las
        vigentes. Cada opción trae además NumeroFactura/VendedorId como
        data-* para que el JS pueda consultar el saldo actual al elegirla."""
        options = _options_for_form()
        response = backend_client.get("/api/abonos/facturas-con-saldo", token=get_token())
        if response.status_code == 200:
            options["FacturaId"] = [
                {
                    "id": f["FacturaId"],
                    "label": f"{f['NumeroFactura']} - {f['Cliente']} (saldo: {f['SaldoPendiente']:.2f})",
                    "numero": f["NumeroFactura"],
                    "vendedor_id": f["VendedorId"],
                }
                for f in response.json()
            ]
        return options

    @bp.route("/")
    def listar():
        redirect_resp = _require_login()
        if redirect_resp:
            return redirect_resp

        if entity.key == "facturas":
            filtros = _filtros_factura_desde_query()
            response = backend_client.get(
                "/api/facturas/consultar",
                token=get_token(),
                params={k: v for k, v in filtros.items() if v is not None},
            )
            if _handle_unauthorized(response):
                return redirect(url_for("main.login"))
            todas = response.json() if response.status_code == 200 else []
            rows, pagina, total_paginas, total = paginar(todas)
            return render_template(
                "pages/admin/list.html",
                entity=entity,
                rows=rows,
                form=FlaskForm(),
                filtros=filtros,
                vendedor_opciones=fetch_filter_options("vendedores"),
                cliente_opciones=fetch_filter_options("clientes"),
                estado_factura_opciones=fetch_filter_options("estados-factura"),
                plazo_pago_opciones=fetch_filter_options("plazos-pago"),
                pagina=pagina,
                total_paginas=total_paginas,
                total=total,
            )

        if entity.key == "abonos":
            filtros = _filtros_abono_desde_query()
            response = backend_client.get(
                "/api/abonos/consultar",
                token=get_token(),
                params={k: v for k, v in filtros.items() if v is not None},
            )
            if _handle_unauthorized(response):
                return redirect(url_for("main.login"))
            todas = response.json() if response.status_code == 200 else []
            rows, pagina, total_paginas, total = paginar(todas)
            return render_template(
                "pages/admin/list.html",
                entity=entity,
                rows=rows,
                form=FlaskForm(),
                filtros=filtros,
                formapago_opciones=fetch_filter_options("formas-pago"),
                cliente_opciones=fetch_filter_options("clientes"),
                usuario_opciones=fetch_filter_options("usuarios"),
                pagina=pagina,
                total_paginas=total_paginas,
                total=total,
            )

        if entity.key == "clientes":
            filtros = _filtros_cliente_desde_query()
            response = backend_client.get(
                "/api/clientes/consultar",
                token=get_token(),
                params={k: v for k, v in filtros.items() if v is not None},
            )
            if _handle_unauthorized(response):
                return redirect(url_for("main.login"))
            todas = response.json() if response.status_code == 200 else []
            rows, pagina, total_paginas, total = paginar(todas)

            return render_template(
                "pages/admin/list.html",
                entity=entity,
                rows=rows,
                form=FlaskForm(),
                filtros=filtros,
                ciudad_opciones=fetch_filter_options("ciudades"),
                segmento_riesgo_opciones=fetch_filter_options("segmentos-riesgo"),
                clasificacion_opciones=fetch_filter_options("clasificaciones-cliente"),
                plazo_pago_opciones=fetch_filter_options("plazos-pago"),
                pagina=pagina,
                total_paginas=total_paginas,
                total=total,
            )

        response = backend_client.get(f"/api/{entity.resource}", token=get_token())
        if _handle_unauthorized(response):
            return redirect(url_for("main.login"))
        rows = response.json() if response.status_code == 200 else []
        return render_template("pages/admin/list.html", entity=entity, rows=rows, form=FlaskForm())

    @bp.route("/nuevo", methods=["GET", "POST"])
    def nuevo():
        redirect_resp = _require_login()
        if redirect_resp:
            return redirect_resp
        form = FlaskForm()
        if request.method == "POST" and form.validate_on_submit():
            payload = _payload_from_form(entity, request.form)
            response = backend_client.post(
                f"/api/{entity.resource}", token=get_token(), json=payload, client_ip=request.remote_addr
            )
            if _handle_unauthorized(response):
                return redirect(url_for("main.login"))
            if response.status_code == 201:
                flash(f"{entity.label} creado correctamente.", "success")
                return redirect(url_for(f"admin_{entity.key}.listar"))
            _flash_error(response)
        options = _options_for_abono_nuevo() if entity.key == "abonos" else _options_for_form()
        return render_template(
            "pages/admin/form.html", entity=entity, row={}, options=options, accion="nuevo", form=form
        )

    @bp.route("/<int:row_id>/editar", methods=["GET", "POST"])
    def editar(row_id):
        redirect_resp = _require_login()
        if redirect_resp:
            return redirect_resp
        form = FlaskForm()
        if request.method == "POST" and form.validate_on_submit():
            payload = _payload_from_form(entity, request.form)
            response = backend_client.put(
                f"/api/{entity.resource}/{row_id}", token=get_token(), json=payload, client_ip=request.remote_addr
            )
            if _handle_unauthorized(response):
                return redirect(url_for("main.login"))
            if response.status_code == 204:
                flash(f"{entity.label} actualizado correctamente.", "success")
                return redirect(url_for(f"admin_{entity.key}.listar"))
            _flash_error(response)
            row = {**payload, entity.pk: row_id}
            return render_template(
                "pages/admin/form.html", entity=entity, row=row, options=_options_for_form(), accion="editar", form=form
            )

        response = backend_client.get(f"/api/{entity.resource}/{row_id}", token=get_token())
        if _handle_unauthorized(response):
            return redirect(url_for("main.login"))
        if response.status_code != 200:
            flash("No se encontró el registro.", "error")
            return redirect(url_for(f"admin_{entity.key}.listar"))
        return render_template(
            "pages/admin/form.html", entity=entity, row=response.json(), options=_options_for_form(), accion="editar", form=form
        )

    @bp.route("/<int:row_id>/eliminar", methods=["POST"])
    def eliminar(row_id):
        redirect_resp = _require_login()
        if redirect_resp:
            return redirect_resp
        form = FlaskForm()
        if not form.validate_on_submit():
            flash("Token de seguridad inválido, intenta de nuevo.", "error")
            return redirect(url_for(f"admin_{entity.key}.listar"))
        response = backend_client.delete(
            f"/api/{entity.resource}/{row_id}", token=get_token(), client_ip=request.remote_addr
        )
        if _handle_unauthorized(response):
            return redirect(url_for("main.login"))
        if response.status_code == 204:
            flash(f"{entity.label} eliminado correctamente.", "success")
        else:
            _flash_error(response)
        return redirect(url_for(f"admin_{entity.key}.listar"))

    if entity.key == "facturas":

        @bp.route("/exportar")
        def exportar():
            redirect_resp = _require_login()
            if redirect_resp:
                return redirect_resp
            filtros = _filtros_factura_desde_query()
            response = backend_client.get(
                "/api/facturas/consultar",
                token=get_token(),
                params={k: v for k, v in filtros.items() if v is not None},
            )
            if _handle_unauthorized(response):
                return redirect(url_for("main.login"))
            if response.status_code != 200:
                flash("No se pudo generar el archivo de Excel.", "error")
                return redirect(url_for("admin_facturas.listar"))
            buffer = facturas_a_excel(response.json())
            return send_file(
                buffer,
                as_attachment=True,
                download_name=nombre_archivo("facturas"),
                mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )

        @bp.route("/riesgo-cliente")
        def riesgo_cliente_ajax():
            """Consulta AJAX desde el formulario de factura: al elegir el
            cliente, muestra su segmento de riesgo y clasificación vigentes
            (con sus Descripcion de catálogo) como mensaje informativo —
            nunca bloquea la creación de la factura."""
            if not is_authenticated():
                return jsonify(error="No autenticado"), 401
            cliente_id = (request.args.get("ClienteId") or "").strip()
            if not cliente_id:
                return jsonify(error="Debe seleccionar un cliente."), 400
            response = backend_client.get(
                "/api/clientes/riesgo-actual", token=get_token(), params={"ClienteId": cliente_id}
            )
            if response.status_code == 401:
                return jsonify(error="Tu sesión expiró, inicia sesión nuevamente."), 401
            body = response.json() if response.status_code != 204 else {}
            if response.status_code != 200:
                return jsonify(error=body.get("error", "No se pudo consultar el riesgo del cliente.")), response.status_code
            return jsonify(body)

    if entity.key == "abonos":

        @bp.route("/estado-cuenta")
        def estado_cuenta_ajax():
            """Consulta AJAX desde el formulario de nuevo abono: al elegir
            la factura, trae su SaldoActual (sp_EstadoCuentaFactura) para
            mostrarlo en un label y validar el valor abonado en el cliente."""
            if not is_authenticated():
                return jsonify(error="No autenticado"), 401
            numero_factura = (request.args.get("NumeroFactura") or "").strip()
            if not numero_factura:
                return jsonify(error="Debe seleccionar una factura."), 400
            params = {"NumeroFactura": numero_factura}
            vendedor_id = request.args.get("VendedorId")
            if vendedor_id:
                params["VendedorId"] = vendedor_id
            response = backend_client.get("/api/abonos/estado-cuenta", token=get_token(), params=params)
            if response.status_code == 401:
                return jsonify(error="Tu sesión expiró, inicia sesión nuevamente."), 401
            body = response.json() if response.status_code != 204 else {}
            if response.status_code != 200:
                return jsonify(error=body.get("error", "No se pudo consultar el saldo.")), response.status_code
            return jsonify(body)

    if entity.key == "clientes":

        @bp.route("/<int:row_id>/historial-riesgo")
        def historial_riesgo_ajax(row_id):
            """Consulta AJAX desde el nombre del cliente en el listado: se
            muestra como panel emergente dentro de la misma pantalla (sin
            navegar a una página nueva), con su historial de recalificación
            de riesgo (dbo.sp_ConsultarHistorialRiesgo)."""
            if not is_authenticated():
                return jsonify(error="No autenticado"), 401
            response = backend_client.get(
                "/api/clientes/historial-riesgo", token=get_token(), params={"ClienteId": row_id}
            )
            if response.status_code == 401:
                return jsonify(error="Tu sesión expiró, inicia sesión nuevamente."), 401
            if response.status_code != 200:
                body = response.json() if response.status_code != 204 else {}
                return jsonify(error=body.get("error", "No se pudo consultar el historial de riesgo.")), response.status_code
            return jsonify(response.json())

    return bp
