from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_wtf import FlaskForm

from src.services import backend_client
from src.services.lookup_client import fetch_options
from src.store.session_store import get_token, is_authenticated, logout_user

seguridad_bp = Blueprint("seguridad", __name__, url_prefix="/seguridad")


def _require_autorizado():
    if not is_authenticated():
        return redirect(url_for("main.login"))
    return None


def _handle_unauthorized(response) -> bool:
    if response.status_code == 401:
        logout_user(request.remote_addr)
        flash("Tu sesión expiró, inicia sesión nuevamente.", "error")
        return True
    return False


def _handle_forbidden(response) -> bool:
    if response.status_code == 403:
        flash("No tienes permiso para acceder a Seguridad.", "error")
        return True
    return False


def _flash_error(response) -> None:
    try:
        body = response.json()
    except ValueError:
        body = {}
    if "errores" in body:
        for mensaje in body["errores"].values():
            flash(mensaje, "error")
    elif "error" in body:
        flash(body["error"], "error")
    else:
        flash("Ocurrió un error al procesar la solicitud.", "error")


def _roles_disponibles() -> list[dict]:
    response = backend_client.get("/api/seguridad/roles", token=get_token())
    return response.json() if response.status_code == 200 else []


def _datos_usuario_desde_form(form) -> dict:
    return {
        "NombreUsuario": form.get("NombreUsuario", "").strip(),
        "Correo": form.get("Correo", "").strip(),
        "NombresCompletos": form.get("NombresCompletos", "").strip(),
        "VendedorId": form.get("VendedorId") or None,
        "Activo": "Activo" in form,
        "Roles": [int(r) for r in form.getlist("Roles")],
    }


@seguridad_bp.route("/")
def index():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    return render_template("pages/seguridad/index.html")


@seguridad_bp.route("/usuarios")
def usuarios():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    response = backend_client.get("/api/seguridad/usuarios", token=get_token())
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if _handle_forbidden(response):
        return redirect(url_for("main.dashboard"))
    if response.status_code != 200:
        flash("No se pudo consultar los usuarios.", "error")
        return redirect(url_for("seguridad.index"))
    return render_template("pages/seguridad/usuarios.html", usuarios=response.json(), form=FlaskForm())


@seguridad_bp.route("/usuarios/nuevo", methods=["GET", "POST"])
def usuario_nuevo():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    form = FlaskForm()
    if request.method == "POST" and form.validate_on_submit():
        payload = _datos_usuario_desde_form(request.form)
        payload["Clave"] = request.form.get("Clave", "")
        response = backend_client.post(
            "/api/seguridad/usuarios", token=get_token(), json=payload, client_ip=request.remote_addr
        )
        if _handle_unauthorized(response):
            return redirect(url_for("main.login"))
        if _handle_forbidden(response):
            return redirect(url_for("seguridad.usuarios"))
        if response.status_code == 201:
            flash("Usuario creado correctamente.", "success")
            return redirect(url_for("seguridad.usuarios"))
        _flash_error(response)
        return render_template(
            "pages/seguridad/usuario_form.html",
            usuario=payload,
            roles_disponibles=_roles_disponibles(),
            roles_asignados=set(payload["Roles"]),
            vendedor_opciones=fetch_options("vendedores"),
            accion="nuevo",
            form=form,
        )

    return render_template(
        "pages/seguridad/usuario_form.html",
        usuario={"Activo": True},
        roles_disponibles=_roles_disponibles(),
        roles_asignados=set(),
        vendedor_opciones=fetch_options("vendedores"),
        accion="nuevo",
        form=form,
    )


@seguridad_bp.route("/usuarios/<int:usuario_id>/editar", methods=["GET", "POST"])
def usuario_editar(usuario_id):
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    form = FlaskForm()
    if request.method == "POST" and form.validate_on_submit():
        payload = _datos_usuario_desde_form(request.form)
        response = backend_client.put(
            f"/api/seguridad/usuarios/{usuario_id}", token=get_token(), json=payload, client_ip=request.remote_addr
        )
        if _handle_unauthorized(response):
            return redirect(url_for("main.login"))
        if _handle_forbidden(response):
            return redirect(url_for("seguridad.usuarios"))
        if response.status_code == 204:
            flash("Usuario actualizado correctamente.", "success")
            return redirect(url_for("seguridad.usuarios"))
        _flash_error(response)
        return render_template(
            "pages/seguridad/usuario_form.html",
            usuario={**payload, "UsuarioId": usuario_id},
            roles_disponibles=_roles_disponibles(),
            roles_asignados=set(payload["Roles"]),
            vendedor_opciones=fetch_options("vendedores"),
            accion="editar",
            form=form,
        )

    response = backend_client.get(f"/api/seguridad/usuarios/{usuario_id}", token=get_token())
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if response.status_code != 200:
        flash("No se encontró el usuario.", "error")
        return redirect(url_for("seguridad.usuarios"))
    usuario = response.json()
    return render_template(
        "pages/seguridad/usuario_form.html",
        usuario=usuario,
        roles_disponibles=_roles_disponibles(),
        roles_asignados=set(usuario.get("Roles", [])),
        vendedor_opciones=fetch_options("vendedores"),
        accion="editar",
        form=form,
    )


@seguridad_bp.route("/usuarios/<int:usuario_id>/clave", methods=["GET", "POST"])
def usuario_clave(usuario_id):
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    form = FlaskForm()
    if request.method == "POST" and form.validate_on_submit():
        clave = request.form.get("Clave", "")
        confirmar = request.form.get("ConfirmarClave", "")
        if clave != confirmar:
            flash("Las contraseñas no coinciden.", "error")
            return render_template("pages/seguridad/usuario_clave.html", usuario_id=usuario_id, form=form)

        response = backend_client.put(
            f"/api/seguridad/usuarios/{usuario_id}/clave",
            token=get_token(),
            json={"Clave": clave},
            client_ip=request.remote_addr,
        )
        if _handle_unauthorized(response):
            return redirect(url_for("main.login"))
        if _handle_forbidden(response):
            return redirect(url_for("seguridad.usuarios"))
        if response.status_code == 204:
            flash("Contraseña actualizada correctamente. El usuario deberá cambiarla en su próximo inicio de sesión.", "success")
            return redirect(url_for("seguridad.usuarios"))
        _flash_error(response)

    return render_template("pages/seguridad/usuario_clave.html", usuario_id=usuario_id, form=form)


@seguridad_bp.route("/usuarios/<int:usuario_id>/estado", methods=["POST"])
def cambiar_estado_usuario(usuario_id):
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    form = FlaskForm()
    if not form.validate_on_submit():
        flash("No se pudo validar la solicitud, intenta de nuevo.", "error")
        return redirect(url_for("seguridad.usuarios"))

    activo = request.form.get("activo") == "1"
    response = backend_client.put(
        f"/api/seguridad/usuarios/{usuario_id}/estado",
        token=get_token(),
        json={"activo": activo},
        client_ip=request.remote_addr,
    )
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if _handle_forbidden(response):
        return redirect(url_for("seguridad.usuarios"))
    if response.status_code not in (200, 204):
        flash("No se pudo actualizar el estado del usuario.", "error")
    return redirect(url_for("seguridad.usuarios"))


@seguridad_bp.route("/matriz-permisos")
def matriz_permisos():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    response = backend_client.get("/api/seguridad/matriz-permisos", token=get_token())
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if _handle_forbidden(response):
        return redirect(url_for("main.dashboard"))
    if response.status_code != 200:
        flash("No se pudo consultar la matriz de permisos.", "error")
        return redirect(url_for("seguridad.index"))

    datos = response.json()
    asignados = {(a["RolId"], a["PermisoId"]) for a in datos["asignaciones"]}

    modulos = {}
    for p in datos["permisos"]:
        modulo = modulos.setdefault(
            p["ModuloCodigo"], {"nombre": p["ModuloNombre"], "solo_administrador": p["SoloAdministrador"], "permisos": []}
        )
        modulo["permisos"].append(p)

    return render_template(
        "pages/seguridad/matriz_permisos.html",
        roles=datos["roles"],
        modulos=modulos,
        asignados=asignados,
        form=FlaskForm(),
    )


@seguridad_bp.route("/matriz-permisos/cambiar", methods=["POST"])
def cambiar_permiso():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    form = FlaskForm()
    if not form.validate_on_submit():
        flash("No se pudo validar la solicitud, intenta de nuevo.", "error")
        return redirect(url_for("seguridad.matriz_permisos"))

    response = backend_client.post(
        "/api/seguridad/matriz-permisos",
        token=get_token(),
        json={
            "rol_id": request.form.get("rol_id", type=int),
            "permiso_id": request.form.get("permiso_id", type=int),
            "asignar": request.form.get("asignar") == "1",
        },
        client_ip=request.remote_addr,
    )
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if _handle_forbidden(response):
        return redirect(url_for("seguridad.matriz_permisos"))
    if response.status_code == 409:
        flash((response.json() or {}).get("error", "No se pudo aplicar el cambio."), "error")
    elif response.status_code not in (200, 204):
        flash("No se pudo aplicar el cambio de permiso.", "error")
    return redirect(url_for("seguridad.matriz_permisos"))


@seguridad_bp.route("/auditoria")
def auditoria():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    response = backend_client.get("/api/seguridad/auditoria", token=get_token())
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if _handle_forbidden(response):
        return redirect(url_for("main.dashboard"))
    if response.status_code != 200:
        flash("No se pudo consultar la auditoría.", "error")
        return redirect(url_for("seguridad.index"))
    return render_template("pages/seguridad/auditoria.html", filas=response.json())


@seguridad_bp.route("/bitacora-autorizacion")
def bitacora_autorizacion():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    response = backend_client.get("/api/seguridad/bitacora-autorizacion", token=get_token())
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if _handle_forbidden(response):
        return redirect(url_for("main.dashboard"))
    if response.status_code != 200:
        flash("No se pudo consultar la bitácora de autorización.", "error")
        return redirect(url_for("seguridad.index"))
    return render_template("pages/seguridad/bitacora_autorizacion.html", lineas=response.json())
