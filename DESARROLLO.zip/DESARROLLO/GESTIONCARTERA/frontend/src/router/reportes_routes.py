from flask import Blueprint, flash, redirect, render_template, request, url_for

from src.services import backend_client
from src.services.lookup_client import fetch_filter_options
from src.store.session_store import get_current_permisos, get_token, is_authenticated, logout_user
from src.utils.pagination import paginar

reportes_bp = Blueprint("reportes", __name__, url_prefix="/reportes")

REPORTES_DISPONIBLES = [
    {"key": "cartera-por-cobrar", "titulo": "Cartera por Cobrar", "permiso": "REPORTES.CARTERA_VENCIDA"},
]


def _require_login():
    if not is_authenticated():
        return redirect(url_for("main.login"))
    return None


def _handle_unauthorized(response) -> bool:
    if response.status_code == 401:
        logout_user(request.remote_addr)
        flash("Tu sesión expiró, inicia sesión nuevamente.", "error")
        return True
    return False


def _filtros_cartera_desde_query() -> dict:
    return {
        "NumeroFactura": request.args.get("NumeroFactura") or None,
        "FechaEmision": request.args.get("FechaEmision") or None,
        "VendedorId": request.args.get("VendedorId") or None,
        "ClienteId": request.args.get("ClienteId") or None,
        "Dias": request.args.get("Dias") or None,
    }


@reportes_bp.route("/")
def index():
    redirect_resp = _require_login()
    if redirect_resp:
        return redirect_resp

    permisos = set(get_current_permisos())
    reportes = [r for r in REPORTES_DISPONIBLES if r["permiso"] in permisos]
    return render_template("pages/reportes/index.html", reportes=reportes)


@reportes_bp.route("/cartera-por-cobrar")
def cartera_por_cobrar():
    redirect_resp = _require_login()
    if redirect_resp:
        return redirect_resp

    filtros = _filtros_cartera_desde_query()
    response = backend_client.get(
        "/api/reportes/cartera-por-cobrar",
        token=get_token(),
        params={k: v for k, v in filtros.items() if v is not None},
    )
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if response.status_code == 403:
        flash("No tienes permiso para ver este reporte.", "error")
        return redirect(url_for("reportes.index"))

    todas = response.json() if response.status_code == 200 else []
    filas, pagina, total_paginas, total = paginar(todas)
    return render_template(
        "pages/reportes/cartera_por_cobrar.html",
        filas=filas,
        filtros=filtros,
        vendedor_opciones=fetch_filter_options("vendedores"),
        cliente_opciones=fetch_filter_options("clientes"),
        pagina=pagina,
        total_paginas=total_paginas,
        total=total,
    )
