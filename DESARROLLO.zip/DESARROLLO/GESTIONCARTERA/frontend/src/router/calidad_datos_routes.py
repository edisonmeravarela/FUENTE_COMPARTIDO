from flask import Blueprint, abort, flash, redirect, render_template, request, url_for
from flask_wtf import FlaskForm

from src.services import backend_client
from src.store.session_store import get_current_roles, get_token, is_authenticated, logout_user

calidad_datos_bp = Blueprint("calidad_datos", __name__, url_prefix="/scoring-morosidad/calidad-datos")

ROLES_AUTORIZADOS = {"ADMINISTRADOR", "SUPERVISOR DE CARTERA"}

# Las dos primeras ejecutan dbo.sp_ValidarCalidadDatos (insertan sus 21
# hallazgos en dbo.ValidacionCalidadDatos) y por eso piden confirmación,
# igual que las acciones de scoring.py; las de solo lectura
# (ultima_validacion/evolucion) tienen su propia ruta GET sin pasar por
# esta lista, porque no necesitan confirmación.
ACCIONES = {
    "ejecucion-completa": {
        "titulo": "Ejecución completa (detalle + veredicto)",
        "descripcion": "Corre los 21 controles de integridad, consistencia, completitud y representatividad, y muestra el detalle junto con el veredicto final.",
        "endpoint_backend": "/api/calidad-datos/ejecucion-completa",
    },
    "solo-veredicto": {
        "titulo": "Solo el veredicto",
        "descripcion": "La misma validación, pero solo devuelve el resultado final — es la compuerta rápida que usa el pipeline antes de entrenar.",
        "endpoint_backend": "/api/calidad-datos/solo-veredicto",
    },
}


def _require_autorizado():
    if not is_authenticated():
        return redirect(url_for("main.login"))
    if not ROLES_AUTORIZADOS & set(get_current_roles()):
        flash("No tienes permiso para acceder a Validación de calidad de datos.", "error")
        return redirect(url_for("scoring.index"))
    return None


def _handle_unauthorized(response) -> bool:
    if response.status_code == 401:
        logout_user(request.remote_addr)
        flash("Tu sesión expiró, inicia sesión nuevamente.", "error")
        return True
    return False


@calidad_datos_bp.route("/")
def index():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    return render_template("pages/scoring/calidad_datos_index.html", acciones=ACCIONES)


@calidad_datos_bp.route("/ultima-validacion")
def ultima_validacion():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    response = backend_client.get("/api/calidad-datos/ultima-validacion", token=get_token())
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if response.status_code != 200:
        flash("No se pudo consultar la última validación.", "error")
        return redirect(url_for("calidad_datos.index"))
    return render_template(
        "pages/scoring/calidad_datos_detalle.html",
        titulo="Última validación (dbo.vw_UltimaValidacion)",
        filas=response.json(),
    )


@calidad_datos_bp.route("/evolucion")
def evolucion():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    response = backend_client.get("/api/calidad-datos/evolucion", token=get_token())
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if response.status_code != 200:
        flash("No se pudo consultar la evolución de la calidad.", "error")
        return redirect(url_for("calidad_datos.index"))
    return render_template("pages/scoring/calidad_datos_evolucion.html", filas=response.json())


@calidad_datos_bp.route("/<clave>")
def confirmar(clave):
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    if clave not in ACCIONES:
        abort(404)
    return render_template("pages/scoring/calidad_datos_confirmar.html", clave=clave, accion=ACCIONES[clave], form=FlaskForm())


@calidad_datos_bp.route("/<clave>/ejecutar", methods=["POST"])
def ejecutar(clave):
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    if clave not in ACCIONES:
        abort(404)

    form = FlaskForm()
    if not form.validate_on_submit():
        flash("No se pudo validar la solicitud, intenta de nuevo.", "error")
        return redirect(url_for("calidad_datos.confirmar", clave=clave))

    response = backend_client.post(
        ACCIONES[clave]["endpoint_backend"], token=get_token(), client_ip=request.remote_addr
    )
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if response.status_code == 403:
        flash("No tienes permiso para ejecutar esta acción.", "error")
        return redirect(url_for("calidad_datos.index"))
    if response.status_code != 200:
        flash("No se pudo ejecutar la validación.", "error")
        return redirect(url_for("calidad_datos.confirmar", clave=clave))

    return render_template(
        "pages/scoring/calidad_datos_resultado.html",
        clave=clave,
        accion=ACCIONES[clave],
        resultado=response.json(),
    )
