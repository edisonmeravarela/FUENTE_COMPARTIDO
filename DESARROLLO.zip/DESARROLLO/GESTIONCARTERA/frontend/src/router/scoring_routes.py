from flask import Blueprint, abort, flash, redirect, render_template, request, url_for
from flask_wtf import FlaskForm

from src.services import backend_client
from src.store.session_store import get_current_roles, get_token, is_authenticated, logout_user

scoring_bp = Blueprint("scoring", __name__, url_prefix="/scoring-morosidad")

ROLES_AUTORIZADOS = {"ADMINISTRADOR", "SUPERVISOR DE CARTERA"}

# Espejo de src.services.scoring_runner.COMANDOS en el backend (paso
# 8.10 de scoring-morosidad): describe cada botón del submenú. La lista
# blanca real que decide qué se ejecuta vive en el backend; aquí solo
# se usa para armar el menú y dar una confirmación clara antes de POST.
ACCIONES = {
    "entrenar": {
        "titulo": "Entrenar modelo",
        "descripcion": "Extrae el historial de facturas, prepara las variables y entrena un nuevo modelo (pasos 2, 3 y 4).",
        "advertencia": "Si el nuevo modelo cumple los criterios de aceptación (KS y AUC), reemplaza al modelo actual en producción.",
    },
    "scorear-dry-run": {
        "titulo": "Scorear (simulación)",
        "descripcion": "Calcula el score y las reglas de negocio de cada cliente y muestra los cambios propuestos, sin escribir en la base de datos.",
        "advertencia": None,
    },
    "scorear": {
        "titulo": "Scorear (ejecución real)",
        "descripcion": "Calcula el score de cada cliente y actualiza su segmento de riesgo, clasificación y plazo de pago en la base de datos.",
        "advertencia": "Esta acción modifica datos reales de los clientes. Ejecuta primero la simulación para revisar los cambios propuestos.",
    },
    "monitorear": {
        "titulo": "Monitorear modelo",
        "descripcion": "Evalúa el desempeño del modelo frente a la mora observada y detecta desviación de datos (drift) en producción.",
        "advertencia": None,
    },
}


def _require_autorizado():
    if not is_authenticated():
        return redirect(url_for("main.login"))
    if not ROLES_AUTORIZADOS & set(get_current_roles()):
        flash("No tienes permiso para acceder a Scoring de Morosidad.", "error")
        return redirect(url_for("main.dashboard"))
    return None


def _handle_unauthorized(response) -> bool:
    if response.status_code == 401:
        logout_user(request.remote_addr)
        flash("Tu sesión expiró, inicia sesión nuevamente.", "error")
        return True
    return False


@scoring_bp.route("/")
def index():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    return render_template("pages/scoring/index.html", acciones=ACCIONES)


@scoring_bp.route("/<clave>")
def confirmar(clave):
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    if clave not in ACCIONES:
        abort(404)
    return render_template("pages/scoring/confirmar.html", clave=clave, accion=ACCIONES[clave], form=FlaskForm())


@scoring_bp.route("/<clave>/ejecutar", methods=["POST"])
def ejecutar(clave):
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    if clave not in ACCIONES:
        abort(404)

    form = FlaskForm()
    if not form.validate_on_submit():
        flash("No se pudo validar la solicitud, intenta de nuevo.", "error")
        return redirect(url_for("scoring.confirmar", clave=clave))

    try:
        response = backend_client.post(
            "/api/scoring-morosidad/ejecutar",
            token=get_token(),
            json={"comando": clave},
            client_ip=request.remote_addr,
            timeout=600,
        )
    except backend_client.BackendNoDisponible:
        # Con procesos que pueden tardar minutos, un tiempo de espera
        # agotado es un caso esperable, no un bug — se muestra como tal
        # en vez de dejar propagar un 500 genérico.
        flash("El backend no respondió a tiempo. La operación puede seguir en curso; revisa logs/main.log en scoring-morosidad.", "error")
        return redirect(url_for("scoring.confirmar", clave=clave))

    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if response.status_code == 403:
        flash("No tienes permiso para ejecutar esta acción.", "error")
        return redirect(url_for("scoring.index"))
    if response.status_code != 200:
        flash("No se pudo ejecutar el comando: " + str(response.json().get("error", "error desconocido")), "error")
        return redirect(url_for("scoring.confirmar", clave=clave))

    resultado = response.json()
    return render_template(
        "pages/scoring/resultado.html",
        clave=clave,
        accion=ACCIONES[clave],
        resultado=resultado,
    )
