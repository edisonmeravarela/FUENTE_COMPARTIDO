from flask import Blueprint, flash, redirect, render_template, request, url_for

from src.services import backend_client
from src.services.lookup_client import fetch_filter_options
from src.store.session_store import get_token, is_authenticated, logout_user

abonos_detalle_bp = Blueprint("abonos_detalle", __name__, url_prefix="/admin/abonos/detalle")


def _require_login():
    if not is_authenticated():
        return redirect(url_for("main.login"))
    return None


def _handle_unauthorized(response) -> bool:
    if response.status_code == 401:
        logout_user(request.remote_addr)
        flash("Tu sesión expiró, inicia sesión nuevamente.", "error")
        return True
    return False


@abonos_detalle_bp.route("/")
def index():
    redirect_resp = _require_login()
    if redirect_resp:
        return redirect_resp

    numero_factura = request.args.get("NumeroFactura", "").strip()
    vendedor_id = request.args.get("VendedorId") or ""
    filas = []
    factura_info = None

    if numero_factura:
        params = {"NumeroFactura": numero_factura}
        if vendedor_id:
            params["VendedorId"] = vendedor_id
        response = backend_client.get("/api/abonos/detalle-factura", token=get_token(), params=params)
        if _handle_unauthorized(response):
            return redirect(url_for("main.login"))
        if response.status_code == 200:
            filas = response.json()
            # sp_DetalleAbonosFactura no devuelve ValorTotal/FechaEmision;
            # se obtienen de sp_ConsultarFacturas (ya expuesto) para el encabezado.
            factura_response = backend_client.get("/api/facturas/consultar", token=get_token(), params=params)
            if factura_response.status_code == 200 and factura_response.json():
                factura_info = factura_response.json()[0]
        else:
            body = response.json() if response.status_code != 204 else {}
            flash(body.get("error", "No se pudo generar el detalle."), "error")

    return render_template(
        "pages/admin/abonos_detalle.html",
        filas=filas,
        numero_factura=numero_factura,
        vendedor_id=vendedor_id,
        vendedor_opciones=fetch_filter_options("vendedores"),
        factura_info=factura_info,
    )
