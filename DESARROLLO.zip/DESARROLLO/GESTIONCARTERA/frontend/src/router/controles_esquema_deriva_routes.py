from flask import Blueprint, abort, flash, redirect, render_template, request, url_for
from flask_wtf import FlaskForm

from src.services import backend_client
from src.store.session_store import get_current_roles, get_token, is_authenticated, logout_user

controles_esquema_deriva_bp = Blueprint(
    "controles_esquema_deriva", __name__, url_prefix="/scoring-morosidad/controles-esquema-deriva"
)

ROLES_AUTORIZADOS = {"ADMINISTRADOR", "SUPERVISOR DE CARTERA"}

# Las dos primeras ejecutan un control real contra la base (sp_ValidarEsquema
# no inserta nada, pero sp_CalcularDriftCategorico sí registra la medición
# en dbo.DriftMedicion/dbo.DriftDetalleTramo) y por eso piden confirmación,
# igual que el resto del módulo de calidad de datos.
ACCIONES = {
    "validar-esquema": {
        "titulo": "Validar esquema",
        "descripcion": "Compara el catálogo real de la base contra dbo.ContratoEsquema (Control 1: siempre bloquea ante un hallazgo crítico, antes incluso de validar la calidad de los datos).",
        "endpoint_backend": "/api/controles-esquema-deriva/validar-esquema",
    },
    "medir-deriva": {
        "titulo": "Medir deriva (CiudadId)",
        "descripcion": "Calcula el PSI de CiudadId contra el baseline más reciente registrado por el pipeline de entrenamiento (Control 3: nunca bloquea, es solo informativo).",
        "endpoint_backend": "/api/controles-esquema-deriva/medir-deriva",
    },
}


def _require_autorizado():
    if not is_authenticated():
        return redirect(url_for("main.login"))
    if not ROLES_AUTORIZADOS & set(get_current_roles()):
        flash("No tienes permiso para acceder a Controles Esquema Calidad Deriva.", "error")
        return redirect(url_for("calidad_datos.index"))
    return None


def _handle_unauthorized(response) -> bool:
    if response.status_code == 401:
        logout_user(request.remote_addr)
        flash("Tu sesión expiró, inicia sesión nuevamente.", "error")
        return True
    return False


@controles_esquema_deriva_bp.route("/")
def index():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    return render_template("pages/scoring/controles_index.html", acciones=ACCIONES)


@controles_esquema_deriva_bp.route("/diagnostico-drift")
def diagnostico_drift():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    response = backend_client.get("/api/controles-esquema-deriva/diagnostico-drift", token=get_token())
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if response.status_code != 200:
        flash("No se pudo consultar el diagnóstico de deriva.", "error")
        return redirect(url_for("controles_esquema_deriva.index"))
    return render_template("pages/scoring/controles_diagnostico_drift.html", filas=response.json())


@controles_esquema_deriva_bp.route("/diagnostico-drift/<int:medicion_id>/desglose")
def desglose_drift(medicion_id):
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    response = backend_client.get(
        f"/api/controles-esquema-deriva/diagnostico-drift/{medicion_id}/desglose", token=get_token()
    )
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if response.status_code != 200:
        flash("No se pudo consultar el desglose por tramo.", "error")
        return redirect(url_for("controles_esquema_deriva.diagnostico_drift"))
    return render_template(
        "pages/scoring/controles_desglose_drift.html", medicion_id=medicion_id, filas=response.json()
    )


@controles_esquema_deriva_bp.route("/evolucion-drift")
def evolucion_drift():
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    response = backend_client.get("/api/controles-esquema-deriva/evolucion-drift", token=get_token())
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if response.status_code != 200:
        flash("No se pudo consultar la evolución de la deriva.", "error")
        return redirect(url_for("controles_esquema_deriva.index"))
    return render_template("pages/scoring/controles_evolucion_drift.html", filas=response.json())


@controles_esquema_deriva_bp.route("/<clave>")
def confirmar(clave):
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    if clave not in ACCIONES:
        abort(404)
    return render_template("pages/scoring/controles_confirmar.html", clave=clave, accion=ACCIONES[clave], form=FlaskForm())


@controles_esquema_deriva_bp.route("/<clave>/ejecutar", methods=["POST"])
def ejecutar(clave):
    redirect_resp = _require_autorizado()
    if redirect_resp:
        return redirect_resp
    if clave not in ACCIONES:
        abort(404)

    form = FlaskForm()
    if not form.validate_on_submit():
        flash("No se pudo validar la solicitud, intenta de nuevo.", "error")
        return redirect(url_for("controles_esquema_deriva.confirmar", clave=clave))

    response = backend_client.post(
        ACCIONES[clave]["endpoint_backend"], token=get_token(), client_ip=request.remote_addr
    )
    if _handle_unauthorized(response):
        return redirect(url_for("main.login"))
    if response.status_code == 403:
        flash("No tienes permiso para ejecutar esta acción.", "error")
        return redirect(url_for("controles_esquema_deriva.index"))
    if response.status_code != 200:
        flash("No se pudo ejecutar el control.", "error")
        return redirect(url_for("controles_esquema_deriva.confirmar", clave=clave))

    return render_template(
        "pages/scoring/controles_resultado.html",
        clave=clave,
        accion=ACCIONES[clave],
        resultado=response.json(),
    )
