from flask import Blueprint, flash, redirect, render_template, request, url_for

from src.entities import ENTITIES
from src.services.auth_service import authenticate
from src.store.session_store import (
    get_current_permisos,
    get_current_roles,
    get_current_user_display_name,
    is_authenticated,
    login_user,
    logout_user,
)
from src.utils.forms import LoginForm

main_bp = Blueprint("main", __name__)


@main_bp.route("/", methods=["GET", "POST"])
def login():
    if is_authenticated():
        return redirect(url_for("main.dashboard"))

    form = LoginForm()
    if form.validate_on_submit():
        result = authenticate(form.username.data, form.password.data, request.remote_addr)
        if result.exitoso:
            login_user(result)
            return redirect(url_for("main.dashboard"))
        flash(result.mensaje, "error")

    return render_template("pages/login.html", form=form)


@main_bp.route("/dashboard")
def dashboard():
    if not is_authenticated():
        return redirect(url_for("main.login"))

    roles = set(get_current_roles())
    permisos = set(get_current_permisos())
    modulos = [
        entity
        for entity in ENTITIES.values()
        if (entity.permiso_menu and entity.permiso_menu in permisos)
        or (entity.roles_menu and roles & set(entity.roles_menu))
    ]
    mostrar_reportes = any(p.startswith("REPORTES.") for p in permisos)
    # Migración a control por permiso (Migracion_Control_Por_Permiso.pdf,
    # paso 8): la tarjeta ya no depende del rol codificado, sino del
    # permiso — igual criterio que el backend exige en cada operación.
    mostrar_scoring = "SCORING.CONSULTAR" in permisos
    mostrar_seguridad = any(p.startswith("SEGURIDAD.") for p in permisos)

    return render_template(
        "pages/dashboard.html",
        username=get_current_user_display_name(),
        roles=get_current_roles(),
        modulos=modulos,
        mostrar_reportes=mostrar_reportes,
        mostrar_scoring=mostrar_scoring,
        mostrar_seguridad=mostrar_seguridad,
    )


@main_bp.route("/logout")
def logout():
    logout_user(request.remote_addr)
    return redirect(url_for("main.login"))
