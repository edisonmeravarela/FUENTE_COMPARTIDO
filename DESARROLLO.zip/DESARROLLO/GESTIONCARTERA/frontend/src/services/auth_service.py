from dataclasses import dataclass, field

from src.services import backend_client

MENSAJE_SIN_BACKEND = "No se pudo conectar con el servidor. Intenta más tarde."


@dataclass
class AuthResult:
    exitoso: bool
    mensaje: str = ""
    token: str | None = None
    usuario_id: int | None = None
    username: str | None = None
    nombres_completos: str | None = None
    roles: list[str] = field(default_factory=list)
    permisos: list[str] = field(default_factory=list)
    vendedor_id: int | None = None
    debe_cambiar_clave: bool = False


def authenticate(username: str, password: str, client_ip: str | None) -> AuthResult:
    try:
        response = backend_client.post(
            "/api/auth/login", json={"username": username, "password": password}, client_ip=client_ip
        )
    except backend_client.BackendNoDisponible:
        return AuthResult(exitoso=False, mensaje=MENSAJE_SIN_BACKEND)

    try:
        body = response.json()
    except ValueError:
        body = {}
    if response.status_code != 200:
        return AuthResult(exitoso=False, mensaje=body.get("mensaje", "Usuario o contraseña incorrectos."))

    usuario = body["usuario"]
    return AuthResult(
        exitoso=True,
        token=body["token"],
        usuario_id=usuario["id"],
        username=usuario["username"],
        nombres_completos=usuario["nombres_completos"],
        roles=usuario["roles"],
        permisos=usuario["permisos"],
        vendedor_id=usuario.get("vendedor_id"),
        debe_cambiar_clave=usuario["debe_cambiar_clave"],
    )


def logout(token: str, client_ip: str | None) -> None:
    try:
        backend_client.post("/api/auth/logout", token=token, client_ip=client_ip)
    except backend_client.BackendNoDisponible:
        pass
