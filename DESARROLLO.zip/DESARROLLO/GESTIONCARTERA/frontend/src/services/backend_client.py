import requests
from flask import current_app


class BackendNoDisponible(Exception):
    """El backend no respondió (caído, timeout, red)."""


def _url(path: str) -> str:
    return f"{current_app.config['BACKEND_API_URL']}{path}"


def _headers(token: str | None, client_ip: str | None) -> dict:
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    if client_ip:
        # IP real del navegador; sin esto el backend solo vería la IP del frontend.
        headers["X-Forwarded-For"] = client_ip
    return headers


def _request(
    method: str,
    path: str,
    token: str | None = None,
    json: dict | None = None,
    params: dict | None = None,
    client_ip: str | None = None,
    timeout: int = 5,
):
    try:
        return requests.request(
            method, _url(path), headers=_headers(token, client_ip), json=json, params=params, timeout=timeout
        )
    except requests.exceptions.RequestException as exc:
        raise BackendNoDisponible(str(exc)) from exc


def get(path: str, token: str | None = None, params: dict | None = None, timeout: int = 5):
    return _request("GET", path, token=token, params=params, timeout=timeout)


def post(path: str, token: str | None = None, json: dict | None = None, client_ip: str | None = None, timeout: int = 5):
    return _request("POST", path, token=token, json=json, client_ip=client_ip, timeout=timeout)


def put(path: str, token: str | None = None, json: dict | None = None, client_ip: str | None = None):
    return _request("PUT", path, token=token, json=json, client_ip=client_ip)


def delete(path: str, token: str | None = None, client_ip: str | None = None):
    return _request("DELETE", path, token=token, client_ip=client_ip)
