from datetime import datetime
from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

FACTURAS_COLUMNAS = [
    ("NumeroFactura", "Factura"),
    ("FechaEmision", "Fecha emisión"),
    ("NombreVendedor", "Vendedor"),
    ("NombreCliente", "Cliente"),
    ("ValorTotal", "Valor total"),
    ("TotalAbonado", "Total abonado"),
    ("SaldoPendiente", "Saldo pendiente"),
    ("FechaUltimoPago", "Fecha último pago"),
    ("PlazoPago", "Plazo de pago"),
    ("FechaVencimiento", "Fecha vencimiento"),
    ("Estado", "Estado"),
    ("Observaciones", "Observaciones"),
]


def filas_a_libro(columnas: list[tuple[str, str]], filas: list[dict], titulo_hoja: str) -> BytesIO:
    """Arma un .xlsx en memoria con una fila de encabezados en negrita y una
    fila por cada dict de `filas`, tomando las columnas en `columnas`
    (lista de (clave_del_dict, encabezado_visible))."""
    wb = Workbook()
    ws = wb.active
    ws.title = titulo_hoja

    for col_index, (_, encabezado) in enumerate(columnas, start=1):
        celda = ws.cell(row=1, column=col_index, value=encabezado)
        celda.font = Font(bold=True)

    for row_index, fila in enumerate(filas, start=2):
        for col_index, (clave, _) in enumerate(columnas, start=1):
            ws.cell(row=row_index, column=col_index, value=fila.get(clave))

    for col_index in range(1, len(columnas) + 1):
        ws.column_dimensions[get_column_letter(col_index)].width = 18

    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer


def facturas_a_excel(filas: list[dict]) -> BytesIO:
    return filas_a_libro(FACTURAS_COLUMNAS, filas, "Facturas")


def nombre_archivo(prefijo: str) -> str:
    return f"{prefijo}_{datetime.now():%Y%m%d_%H%M%S}.xlsx"
