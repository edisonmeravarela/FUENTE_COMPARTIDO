from src.services import backend_client
from src.store.session_store import get_token

# columnas (id, label) que arma cada catálogo/entidad usada como <select>
FK_LOOKUP_DISPLAY = {
    "vendedores": ("VendedorId", "Nombres"),
    "clientes": ("ClienteId", "NombreCompleto"),
    "facturas": ("FacturaId", "NumeroFactura"),
    "tipos-gasto": ("TipoGastoId", "Descripcion"),
    "ciudades": ("id", "label"),
    "formas-pago": ("id", "label"),
    "segmentos-riesgo": ("id", "label"),
    "clasificaciones-cliente": ("id", "label"),
    "plazos-pago": ("id", "label"),
    "estados-factura": ("id", "label"),
    "usuarios": ("id", "label"),
}

_SIN_PARAMS = (
    "ciudades",
    "formas-pago",
    "segmentos-riesgo",
    "clasificaciones-cliente",
    "plazos-pago",
    "estados-factura",
    "usuarios",
)


def fetch_options(lookup_key: str) -> list[dict]:
    token = get_token()
    params = None if lookup_key in _SIN_PARAMS else {"activo": "1"}
    response = backend_client.get(f"/api/{lookup_key}", token=token, params=params)
    if response.status_code != 200:
        return []
    pk_field, label_field = FK_LOOKUP_DISPLAY[lookup_key]
    # se conserva el resto de columnas del row original (p.ej. PlazoPagoId de
    # un cliente, o los días de un plazo de pago) para que las plantillas
    # puedan exponerlas como data-* sin una llamada aparte al backend.
    return [{**row, "id": row[pk_field], "label": row[label_field]} for row in response.json()]


def fetch_filter_options(lookup_key: str) -> list[dict]:
    """Igual que fetch_options pero con el código antepuesto al nombre,
    para los combos de filtro (código y nombre en el mismo texto)."""
    return [{"id": o["id"], "label": f"{o['id']} - {o['label']}"} for o in fetch_options(lookup_key)]
