from flask import session

from src.services import auth_service
from src.services.auth_service import AuthResult


def login_user(auth_result: AuthResult) -> None:
    session["token"] = auth_result.token
    session["usuario_id"] = auth_result.usuario_id
    session["username"] = auth_result.username
    session["nombres_completos"] = auth_result.nombres_completos
    session["roles"] = auth_result.roles
    session["permisos"] = auth_result.permisos
    session["vendedor_id"] = auth_result.vendedor_id
    session["debe_cambiar_clave"] = auth_result.debe_cambiar_clave


def logout_user(client_ip: str | None = None) -> None:
    token = session.get("token")
    if token:
        auth_service.logout(token, client_ip)
    session.clear()


def get_token() -> str | None:
    return session.get("token")


def get_current_user() -> str | None:
    return session.get("username")


def get_current_user_display_name() -> str | None:
    return session.get("nombres_completos") or session.get("username")


def get_current_roles() -> list[str]:
    return session.get("roles", [])


def get_current_permisos() -> list[str]:
    return session.get("permisos", [])


def is_authenticated() -> bool:
    return "usuario_id" in session
