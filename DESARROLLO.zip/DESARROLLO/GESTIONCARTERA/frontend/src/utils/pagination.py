from flask import request

REGISTROS_POR_PAGINA = 20


def paginar(todas: list) -> tuple[list, int, int, int]:
    """Corta una lista completa en la página actual (?pagina=, 20 por
    página). Devuelve (rows, pagina, total_paginas, total)."""
    total = len(todas)
    total_paginas = max(1, -(-total // REGISTROS_POR_PAGINA))  # techo de total/tamaño
    pagina = min(max(1, request.args.get("pagina", 1, type=int) or 1), total_paginas)
    inicio = (pagina - 1) * REGISTROS_POR_PAGINA
    rows = todas[inicio : inicio + REGISTROS_POR_PAGINA]
    return rows, pagina, total_paginas, total
