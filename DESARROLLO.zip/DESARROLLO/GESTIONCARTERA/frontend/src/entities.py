from dataclasses import dataclass


@dataclass
class FieldDef:
    column: str
    label: str
    type: str  # text | number | decimal | date | checkbox | select
    required: bool = False
    fk_lookup: str | None = None  # "vendedores" | "clientes" | "facturas" | "tipos-gasto" | "ciudades" | "formas-pago"
    editable: bool = True
    default: bool = False  # valor inicial para checkbox en un registro nuevo


@dataclass
class EntityDef:
    key: str
    resource: str  # ruta en el backend: /api/<resource>
    pk: str
    label: str
    plural: str
    fields: list[FieldDef]
    permiso_menu: str | None = None  # permiso que decide si se muestra en el menú
    roles_menu: list[str] | None = None  # alternativa a permiso_menu


ENTITIES: dict[str, EntityDef] = {
    "vendedores": EntityDef(
        key="vendedores",
        resource="vendedores",
        pk="VendedorId",
        label="Vendedor",
        plural="Vendedores",
        fields=[
            FieldDef("Nombres", "Nombres", "text", required=True),
            FieldDef("Telefono", "Teléfono", "text"),
            FieldDef("PorcComision", "% Comisión", "decimal"),
            FieldDef("Activo", "Activo", "checkbox", default=True),
        ],
        # Migración a control por permiso (Migracion_Control_Por_Permiso.pdf,
        # paso 8): la visibilidad del menú pasa de depender del rol a
        # depender del permiso — la autorización real ya la exige el
        # backend por permiso (ver backend/src/entities.py); esto es solo
        # la comodidad de presentación, no el control de acceso.
        permiso_menu="VENDEDORES.CONSULTAR",
    ),
    "clientes": EntityDef(
        key="clientes",
        resource="clientes",
        pk="ClienteId",
        label="Cliente",
        plural="Clientes",
        fields=[
            FieldDef("NombreCompleto", "Nombre completo", "text", required=True),
            FieldDef("Identificacion", "Identificación", "text"),
            FieldDef("Direccion", "Dirección", "text"),
            FieldDef("CiudadId", "Ciudad", "select", fk_lookup="ciudades"),
            FieldDef("Telefono", "Teléfono", "text"),
            FieldDef("SegmentoRiesgoId", "Segmento de riesgo", "select", fk_lookup="segmentos-riesgo"),
            FieldDef("ClasificacionId", "Clasificación", "select", fk_lookup="clasificaciones-cliente"),
            FieldDef("PlazoPagoId", "Plazo de pago", "select", fk_lookup="plazos-pago"),
            FieldDef("LimiteCreditoPersonal", "Límite de crédito personal", "decimal"),
            FieldDef("Activo", "Activo", "checkbox", default=True),
        ],
        permiso_menu="CLIENTES.CONSULTAR",
    ),
    "facturas": EntityDef(
        key="facturas",
        resource="facturas",
        pk="FacturaId",
        label="Factura",
        plural="Facturas",
        fields=[
            FieldDef("NumeroFactura", "Número de factura", "text", required=True),
            FieldDef("VendedorId", "Vendedor", "select", required=True, fk_lookup="vendedores"),
            FieldDef("ClienteId", "Cliente", "select", required=True, fk_lookup="clientes"),
            FieldDef("FechaEmision", "Fecha de emisión", "date", required=True),
            FieldDef("PlazoPagoId", "Plazo de pago", "select", fk_lookup="plazos-pago"),
            FieldDef("FechaVencimiento", "Fecha de vencimiento", "date"),
            FieldDef("ValorTotal", "Valor total", "decimal", required=True),
            FieldDef("Observaciones", "Observaciones", "text"),
            FieldDef("EstadoFacturaId", "Estado", "number", editable=False),
        ],
        permiso_menu="FACTURAS.CONSULTAR",
    ),
    "abonos": EntityDef(
        key="abonos",
        resource="abonos",
        pk="AbonoId",
        label="Abono",
        plural="Abonos",
        fields=[
            FieldDef("FacturaId", "Factura", "select", required=True, fk_lookup="facturas"),
            FieldDef("FechaAbono", "Fecha de abono", "date", required=True),
            FieldDef("ValorAbono", "Valor abonado", "decimal", required=True),
            FieldDef("ValorRetencion", "Valor retención", "decimal"),
            FieldDef("FormaPagoId", "Forma de pago", "select", fk_lookup="formas-pago"),
            FieldDef("Observacion", "Observación", "text"),
            FieldDef("UsuarioId", "Usuario", "number", editable=False),
        ],
        permiso_menu="COBRANZA.CONSULTAR",
    ),
    "tipos-gasto": EntityDef(
        key="tipos-gasto",
        resource="tipos-gasto",
        pk="TipoGastoId",
        label="Tipo de Gasto",
        plural="Tipos de Gasto",
        fields=[
            FieldDef("Descripcion", "Descripción", "text", required=True),
        ],
        # Sin permiso_menu/roles_menu a propósito: no aparece en el menú,
        # pero las rutas de administración (/admin/tipos-gasto/...) y la
        # API (/api/tipos-gasto) siguen activas sin cambios.
    ),
    "gastos-vendedor": EntityDef(
        key="gastos-vendedor",
        resource="gastos-vendedor",
        pk="GastoId",
        label="Gasto de Vendedor",
        plural="Gastos de Vendedor",
        fields=[
            FieldDef("VendedorId", "Vendedor", "select", required=True, fk_lookup="vendedores"),
            FieldDef("FechaGasto", "Fecha del gasto", "date", required=True),
            FieldDef("NumComprobante", "N.º comprobante", "text"),
            FieldDef("TipoGastoId", "Tipo de gasto", "select", fk_lookup="tipos-gasto"),
            FieldDef("Detalle", "Detalle", "text", required=True),
            FieldDef("Valor", "Valor", "decimal", required=True),
        ],
        # Sin permiso_menu a propósito: no aparece en el menú, pero las
        # rutas de administración (/admin/gastos-vendedor/...) y la API
        # (/api/gastos-vendedor) siguen activas sin cambios.
    ),
}
