from conftest import TEST_PASSWORD, TEST_USERNAME
from src.services import backend_client


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_dashboard_muestra_tarjeta_scoring(client):
    _login(client)
    response = client.get("/dashboard")
    assert response.status_code == 200
    assert "Scoring de Morosidad".encode() in response.data


def test_scoring_requiere_login(client):
    response = client.get("/scoring-morosidad/")
    assert response.status_code == 302


def test_scoring_index_lista_las_cuatro_acciones(client):
    _login(client)
    response = client.get("/scoring-morosidad/")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Entrenar modelo" in body
    assert "Scorear (simulación)" in body
    assert "Scorear (ejecución real)" in body
    assert "Monitorear modelo" in body


def test_scoring_confirmar_clave_desconocida_da_404(client):
    _login(client)
    response = client.get("/scoring-morosidad/no-existe")
    assert response.status_code == 404


def test_scoring_confirmar_muestra_advertencia_para_accion_real(client):
    _login(client)
    response = client.get("/scoring-morosidad/scorear")
    assert response.status_code == 200
    assert "modifica datos reales" in response.data.decode()


def test_scoring_confirmar_no_muestra_advertencia_para_dry_run(client):
    _login(client)
    response = client.get("/scoring-morosidad/scorear-dry-run")
    assert response.status_code == 200
    assert "flash-error" not in response.data.decode()


def test_scoring_ejecutar_dry_run_muestra_resultado(client):
    _login(client)
    response = client.post("/scoring-morosidad/scorear-dry-run/ejecutar", follow_redirects=True)
    assert response.status_code == 200
    body = response.data.decode()
    assert "Ejecución exitosa" in body
    assert "5 registros procesados" in body


def test_scoring_ejecutar_comando_rechazado_por_el_backend_muestra_flash(client, monkeypatch):
    from conftest import FakeResponse

    _login(client)
    monkeypatch.setattr(
        backend_client, "post", lambda *a, **k: FakeResponse(400, {"error": "Comando de scoring desconocido."})
    )

    response = client.post("/scoring-morosidad/monitorear/ejecutar", follow_redirects=True)
    assert response.status_code == 200
    assert "No se pudo ejecutar el comando" in response.data.decode()


def test_scoring_ejecutar_backend_no_disponible_muestra_flash(client, monkeypatch):
    _login(client)

    def _lanza_no_disponible(*args, **kwargs):
        raise backend_client.BackendNoDisponible("timeout")

    monkeypatch.setattr(backend_client, "post", _lanza_no_disponible)

    response = client.post("/scoring-morosidad/monitorear/ejecutar", follow_redirects=True)
    assert response.status_code == 200
    assert "no respondió a tiempo" in response.data.decode()
