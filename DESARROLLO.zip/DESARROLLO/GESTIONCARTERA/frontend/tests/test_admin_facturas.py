from io import BytesIO

from openpyxl import load_workbook

from conftest import TEST_PASSWORD, TEST_USERNAME


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_lista_facturas_muestra_filtros_y_resultados(client):
    _login(client)
    response = client.get("/admin/facturas/")
    assert response.status_code == 200
    body = response.data.decode()
    # los 5 controles pedidos por el usuario
    assert 'name="NumeroFactura"' in body
    assert 'name="FechaEmision"' in body and 'type="date"' in body
    assert 'name="VendedorId"' in body
    assert 'name="ClienteId"' in body
    assert 'name="EstadoFacturaId"' in body
    assert "1 - Vendedor Uno" in body
    assert "1 - Cliente Uno" in body
    assert "F-001" in body
    assert "F-002" in body


def test_filtrar_facturas_por_numero(client):
    _login(client)
    response = client.get("/admin/facturas/?NumeroFactura=F-001")
    assert response.status_code == 200
    body = response.data.decode()
    assert "F-001" in body
    assert "F-002" not in body


def test_filtrar_facturas_por_vendedor(client):
    _login(client)
    response = client.get("/admin/facturas/?VendedorId=2")
    body = response.data.decode()
    assert "F-002" in body
    assert "F-001" not in body


def test_filtrar_facturas_por_estado_factura(client):
    _login(client)
    response = client.get("/admin/facturas/?EstadoFacturaId=3")
    body = response.data.decode()
    assert "F-002" in body  # Anulada
    assert "F-001" not in body  # Pendiente

    response_pendientes = client.get("/admin/facturas/?EstadoFacturaId=1")
    body_pendientes = response_pendientes.data.decode()
    assert "F-001" in body_pendientes
    assert "F-002" not in body_pendientes


def test_lista_facturas_muestra_20_por_pagina(client):
    # self.facturas trae 23 registros en total (F-001..F-003 + 20 "P-XXX")
    _login(client)
    response = client.get("/admin/facturas/")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Página 1 de 2 (23 facturas)" in body
    assert "P-017" in body
    assert "P-018" not in body  # ya en la página 2


def test_lista_facturas_pagina_2_muestra_el_resto(client):
    _login(client)
    response = client.get("/admin/facturas/?pagina=2")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Página 2 de 2" in body
    assert "P-020" in body
    assert "P-001" not in body


def test_filtro_con_pocos_resultados_no_muestra_paginacion(client):
    _login(client)
    response = client.get("/admin/facturas/?NumeroFactura=F-001")
    body = response.data.decode()
    assert "Página" not in body


def test_lista_facturas_muestra_filtros_de_plazo_y_vencimiento(client):
    _login(client)
    response = client.get("/admin/facturas/")
    assert response.status_code == 200
    body = response.data.decode()
    assert 'name="PlazoPagoId"' in body
    assert 'name="FechaVencimiento"' in body
    assert "15 DÍAS" in body


def test_lista_facturas_muestra_columnas_plazo_y_vencimiento_sin_codigo_vendedor_cliente(client):
    _login(client)
    response = client.get("/admin/facturas/")
    body = response.data.decode()
    assert "Plazo de pago" in body
    assert "Fecha vencimiento" in body
    assert "CONTADO" in body
    assert "2026-08-01" in body
    # ya no se antepone el código numérico del vendedor/cliente en la fila
    # (sp_ConsultarFacturas dejó de devolver CodigoVendedor/CodigoCliente)
    assert "<td>1 - Vendedor Uno</td>" not in body
    assert "<td>1 - Cliente Uno</td>" not in body


def test_lista_facturas_muestra_combo_de_estado_asociado_a_estadofactura(client):
    _login(client)
    response = client.get("/admin/facturas/")
    body = response.data.decode()
    assert "PENDIENTE - Pendiente" in body
    assert "CANCELADA - Cancelada" in body
    assert "ANULADA - Anulada" in body


def test_lista_facturas_muestra_informacion_complementaria_del_sp(client):
    # Punto 4 del pedido: mostrar toda la información complementaria que
    # devuelve sp_ConsultarFacturas (total abonado, saldo pendiente, fecha
    # de último pago), no solo los campos que ya se mostraban antes.
    _login(client)
    response = client.get("/admin/facturas/")
    body = response.data.decode()
    assert "Total abonado" in body
    assert "Saldo pendiente" in body
    assert "Fecha último pago" in body
    assert "40.00" in body  # TotalAbonado de F-001
    assert "60.00" in body  # SaldoPendiente de F-001
    assert "2026-08-10" in body  # FechaUltimoPago de F-001
    assert "Pendiente" in body
    assert "Anulada" in body
    assert "Cancelada" in body


def test_filtrar_facturas_por_plazo_pago(client):
    _login(client)
    response = client.get("/admin/facturas/?PlazoPagoId=2")
    body = response.data.decode()
    assert "F-002" in body
    assert "F-001" not in body


def test_filtrar_facturas_por_fecha_vencimiento(client):
    _login(client)
    response = client.get("/admin/facturas/?FechaVencimiento=2026-08-20")
    body = response.data.decode()
    assert "F-002" in body
    assert "F-001" not in body


def test_nuevo_factura_incluye_plazo_pago_y_fecha_vencimiento(client):
    _login(client)
    response = client.get("/admin/facturas/nuevo")
    assert response.status_code == 200
    body = response.data.decode()
    assert 'name="PlazoPagoId"' in body
    assert 'name="FechaVencimiento"' in body
    assert "15 DÍAS" in body
    # el combo de plazos trae los días como data-* para el cálculo en JS
    assert 'data-dias="0"' in body
    assert 'data-dias="15"' in body
    # el combo de cliente trae su plazo por defecto como data-*
    assert 'data-plazo="2"' in body


def test_nuevo_factura_fecha_vencimiento_es_readonly_y_calculada_por_js(client):
    _login(client)
    response = client.get("/admin/facturas/nuevo")
    body = response.data.decode()
    assert 'id="FechaVencimiento"' in body
    assert body.count("readonly") == 1  # solo el input de FechaVencimiento lo tiene
    assert "autoSeleccionarPlazoDelCliente" in body
    assert "actualizarVencimiento" in body


def test_lista_facturas_incluye_boton_exportar(client):
    _login(client)
    response = client.get("/admin/facturas/")
    body = response.data.decode()
    assert "Exportar a Excel" in body
    assert 'href="/admin/facturas/exportar' in body


def test_exportar_requiere_login(client):
    response = client.get("/admin/facturas/exportar")
    assert response.status_code == 302


def test_exportar_devuelve_xlsx_con_encabezados_y_filas(client):
    _login(client)
    response = client.get("/admin/facturas/exportar")
    assert response.status_code == 200
    assert response.mimetype == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    assert response.headers["Content-Disposition"].startswith("attachment")
    assert ".xlsx" in response.headers["Content-Disposition"]

    libro = load_workbook(BytesIO(response.data))
    hoja = libro.active
    encabezados = [c.value for c in next(hoja.iter_rows(min_row=1, max_row=1))]
    assert encabezados == [
        "Factura",
        "Fecha emisión",
        "Vendedor",
        "Cliente",
        "Valor total",
        "Total abonado",
        "Saldo pendiente",
        "Fecha último pago",
        "Plazo de pago",
        "Fecha vencimiento",
        "Estado",
        "Observaciones",
    ]
    numeros_factura = [row[0].value for row in hoja.iter_rows(min_row=2)]
    assert "F-001" in numeros_factura
    assert "F-002" in numeros_factura
    # las 23 facturas de prueba (F-001..F-003 + 20 "P-XXX"), no solo la
    # página de 20 que se ve en pantalla: exporta todo el resultado filtrado
    assert len(numeros_factura) == 23


def test_exportar_respeta_los_filtros_aplicados(client):
    _login(client)
    response = client.get("/admin/facturas/exportar?NumeroFactura=F-001")
    assert response.status_code == 200

    libro = load_workbook(BytesIO(response.data))
    hoja = libro.active
    numeros_factura = [row[0].value for row in hoja.iter_rows(min_row=2)]
    assert numeros_factura == ["F-001"]
