from conftest import TEST_PASSWORD, TEST_USERNAME


def test_login_page_loads(client):
    response = client.get("/")
    assert response.status_code == 200
    assert b'name="username"' in response.data
    assert b'name="password"' in response.data


def test_login_with_invalid_credentials_shows_error(client):
    response = client.post(
        "/", data={"username": "wrong", "password": "wrong"}, follow_redirects=True
    )
    assert response.status_code == 200
    assert "incorrectos".encode() in response.data


def test_login_with_valid_credentials_redirects_to_dashboard(client):
    response = client.post(
        "/",
        data={"username": TEST_USERNAME, "password": TEST_PASSWORD},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert "Bienvenido".encode() in response.data
    assert "Clientes".encode() in response.data


def test_dashboard_requires_authentication(client):
    response = client.get("/dashboard")
    assert response.status_code == 302
    assert response.headers["Location"].endswith("/")


def test_logout_clears_session(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})
    client.get("/logout")
    response = client.get("/dashboard")
    assert response.status_code == 302
