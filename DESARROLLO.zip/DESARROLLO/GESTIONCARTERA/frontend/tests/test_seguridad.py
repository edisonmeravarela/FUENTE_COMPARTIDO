from conftest import TEST_PASSWORD, TEST_USERNAME


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_dashboard_enlaza_a_seguridad(client):
    _login(client)
    response = client.get("/dashboard")
    assert response.status_code == 200
    assert "Seguridad" in response.data.decode()


def test_seguridad_requiere_login(client):
    response = client.get("/seguridad/")
    assert response.status_code == 302


def test_seguridad_index_lista_las_cuatro_opciones(client):
    _login(client)
    response = client.get("/seguridad/")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Usuarios" in body
    assert "Roles y permisos" in body
    assert "Auditoría" in body
    assert "Bitácora de autorización" in body


def test_usuarios_muestra_la_tabla(client):
    _login(client)
    response = client.get("/seguridad/usuarios")
    assert response.status_code == 200
    body = response.data.decode()
    assert "admin_prueba" in body
    assert "vendedor_prueba" in body


def test_cambiar_estado_usuario_inactiva_y_vuelve_a_listar(client):
    _login(client)
    response = client.post("/seguridad/usuarios/2/estado", data={"activo": "0"}, follow_redirects=True)
    assert response.status_code == 200
    assert "INACTIVO" in response.data.decode()


def test_usuarios_enlaza_a_nuevo_editar_y_clave(client):
    _login(client)
    response = client.get("/seguridad/usuarios")
    body = response.data.decode()
    assert "/seguridad/usuarios/nuevo" in body
    assert "/seguridad/usuarios/2/editar" in body
    assert "/seguridad/usuarios/2/clave" in body


def test_usuario_nuevo_muestra_el_formulario_con_roles(client):
    _login(client)
    response = client.get("/seguridad/usuarios/nuevo")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Nuevo usuario" in body
    assert "ADMINISTRADOR" in body
    assert "VENDEDOR/COBRADOR" in body


def test_usuario_nuevo_crea_y_redirige_al_listado(client):
    _login(client)
    response = client.post(
        "/seguridad/usuarios/nuevo",
        data={
            "NombreUsuario": "usuario_nuevo",
            "Correo": "nuevo@test.com",
            "NombresCompletos": "Usuario Nuevo",
            "Clave": "ClaveNueva123",
            "Roles": ["3"],
        },
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert "usuario_nuevo" in response.data.decode()


def test_usuario_nuevo_con_datos_invalidos_muestra_error(client):
    _login(client)
    response = client.post(
        "/seguridad/usuarios/nuevo",
        data={"NombreUsuario": "sin_datos", "Clave": "ClaveNueva123"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert "obligatorio" in response.data.decode().lower()


def test_usuario_editar_muestra_los_datos_y_roles_actuales(client):
    _login(client)
    response = client.get("/seguridad/usuarios/2/editar")
    assert response.status_code == 200
    body = response.data.decode()
    assert 'value="vendedor_prueba"' in body
    assert 'value="3" checked' in body  # VENDEDOR/COBRADOR ya asignado


def test_usuario_editar_actualiza_datos_y_roles(client):
    _login(client)
    response = client.post(
        "/seguridad/usuarios/2/editar",
        data={
            "NombreUsuario": "vendedor_prueba",
            "Correo": "vendedor_editado@test.com",
            "NombresCompletos": "Vendedor Editado",
            "Roles": ["3", "4"],
        },
        follow_redirects=True,
    )
    assert response.status_code == 200
    body = response.data.decode()
    assert "actualizado correctamente" in body.lower()


def test_usuario_clave_muestra_el_formulario(client):
    _login(client)
    response = client.get("/seguridad/usuarios/2/clave")
    assert response.status_code == 200
    assert "Cambiar contraseña" in response.data.decode()


def test_usuario_clave_rechaza_confirmacion_distinta(client):
    _login(client)
    response = client.post(
        "/seguridad/usuarios/2/clave",
        data={"Clave": "ClaveNueva123", "ConfirmarClave": "OtraClave123"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert "no coinciden" in response.data.decode().lower()


def test_usuario_clave_actualiza_y_redirige_al_listado(client):
    _login(client)
    response = client.post(
        "/seguridad/usuarios/2/clave",
        data={"Clave": "ClaveNueva123", "ConfirmarClave": "ClaveNueva123"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert "actualizada correctamente" in response.data.decode().lower()


def test_matriz_permisos_muestra_los_modulos(client):
    _login(client)
    response = client.get("/seguridad/matriz-permisos")
    assert response.status_code == 200
    body = response.data.decode()
    assert "VENDEDORES.CONSULTAR" in body
    assert "RESTRINGIDO" in body  # el módulo SEGURIDAD está marcado SoloAdministrador


def test_cambiar_permiso_asigna_y_se_refleja_en_la_matriz(client):
    _login(client)
    # SUPERVISOR DE CARTERA (RolId=2) no tiene SCORING.EJECUTAR (PermisoId=2) al inicio.
    response = client.post(
        "/seguridad/matriz-permisos/cambiar",
        data={"rol_id": "2", "permiso_id": "2", "asignar": "1"},
        follow_redirects=True,
    )
    assert response.status_code == 200


def test_cambiar_permiso_restringido_muestra_error(client):
    _login(client)
    # PermisoId=3 (SEGURIDAD.USUARIOS) hacia un rol que no es ADMINISTRADOR: el doble simula el 409 real.
    response = client.post(
        "/seguridad/matriz-permisos/cambiar",
        data={"rol_id": "2", "permiso_id": "3", "asignar": "1"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert "restringido" in response.data.decode().lower()


def test_auditoria_muestra_los_registros(client):
    _login(client)
    response = client.get("/seguridad/auditoria")
    assert response.status_code == 200
    assert "LOGIN" in response.data.decode()


def test_bitacora_autorizacion_muestra_las_lineas(client):
    _login(client)
    response = client.get("/seguridad/bitacora-autorizacion")
    assert response.status_code == 200
    assert "PERMISO" in response.data.decode()
