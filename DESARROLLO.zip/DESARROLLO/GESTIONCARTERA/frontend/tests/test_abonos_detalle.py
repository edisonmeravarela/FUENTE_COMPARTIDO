from conftest import TEST_PASSWORD, TEST_USERNAME


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_detalle_requiere_login(client):
    response = client.get("/admin/abonos/detalle/")
    assert response.status_code == 302


def test_abonos_lista_muestra_link_a_detalle(client):
    _login(client)
    response = client.get("/admin/abonos/")
    assert response.status_code == 200
    assert "Detalle abonos".encode() in response.data


def test_detalle_sin_numero_muestra_solo_formulario(client):
    _login(client)
    response = client.get("/admin/abonos/detalle/")
    assert response.status_code == 200
    body = response.data.decode()
    assert 'name="NumeroFactura"' in body
    assert 'name="VendedorId"' in body
    assert "1 - Vendedor Uno" in body  # combo con código y nombre
    assert "No hay abonos para mostrar" not in body  # no se busca hasta que se envíe algo


def test_detalle_con_numero_muestra_filas_y_total(client):
    _login(client)
    response = client.get("/admin/abonos/detalle/?NumeroFactura=F-001")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Cliente Uno" in body
    assert "fila-total" in body
    assert "Saldo actual de la factura" in body


def test_detalle_factura_inexistente_muestra_error(client):
    _login(client)
    response = client.get("/admin/abonos/detalle/?NumeroFactura=NO-EXISTE")
    assert response.status_code == 200
    body = response.data.decode()
    assert "No existe una factura con el número NO-EXISTE".encode().decode() in body


def test_detalle_encabezado_muestra_valor_y_fecha_emision(client):
    _login(client)
    response = client.get("/admin/abonos/detalle/?NumeroFactura=F-001")
    body = response.data.decode()
    assert "Factura F-001" in body
    assert "Cliente Uno" in body
    assert "100.00" in body  # ValorTotal de la factura F-001
    assert "2026-08-01" in body  # FechaEmision de la factura F-001


def test_detalle_con_saldo_pendiente_muestra_etiqueta_en_rojo(client):
    # F-001: valor 100, abonado 40 -> queda saldo de 60
    _login(client)
    response = client.get("/admin/abonos/detalle/?NumeroFactura=F-001")
    body = response.data.decode()
    assert 'class="saldo-rojo"' in body
    assert "Saldo actual de la factura (valor 60.00)" in body


def test_detalle_factura_cancelada_muestra_saldo_cero_sin_rojo(client):
    # F-003: valor 105, abonado 100 + retención 5 = 105 -> saldo 0 (cancelada)
    _login(client)
    response = client.get("/admin/abonos/detalle/?NumeroFactura=F-003")
    body = response.data.decode()
    assert "Saldo actual de la factura (valor $0)" in body
    assert 'class="saldo-rojo"' not in body
