from conftest import TEST_PASSWORD, TEST_USERNAME


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_admin_requires_login(client):
    response = client.get("/admin/clientes/")
    assert response.status_code == 302


def test_lista_clientes_sin_coincidencias_muestra_mensaje(client):
    # La lista ahora sale de sp_ConsultarClientes (siempre con datos reales);
    # el estado "vacío" se prueba con un filtro que no coincide con nada.
    _login(client)
    response = client.get("/admin/clientes/?Nombre=ZZZ-NO-EXISTE")
    assert response.status_code == 200
    assert "No hay clientes para los filtros seleccionados".encode() in response.data


def test_crear_cliente(client, backend):
    _login(client)
    response = client.post(
        "/admin/clientes/nuevo",
        data={"NombreCompleto": "Juan Perez", "CiudadId": "1", "Activo": "on"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert "creado correctamente".encode() in response.data
    assert backend.clientes[1]["Activo"] is True

    # El listado paginado (25 clientes de prueba ya ocupan la página 1) no
    # necesariamente lo muestra de entrada, pero sí aparece al filtrar por su
    # nombre, igual que con datos reales de sp_ConsultarClientes.
    filtrado = client.get("/admin/clientes/?Nombre=Juan Perez")
    assert "Juan Perez".encode() in filtrado.data


def test_formulario_nuevo_cliente_incluye_segmento_clasificacion_plazo_y_limite(client):
    _login(client)
    response = client.get("/admin/clientes/nuevo")
    assert response.status_code == 200
    body = response.data.decode()
    assert 'name="SegmentoRiesgoId"' in body
    assert "BAJO - Riesgo bajo" in body
    assert 'name="ClasificacionId"' in body
    assert "A - Cliente preferencial" in body
    assert 'name="PlazoPagoId"' in body
    assert "CONTADO" in body
    assert 'name="LimiteCreditoPersonal"' in body


def test_crear_cliente_con_segmento_clasificacion_plazo_y_limite(client, backend):
    _login(client)
    response = client.post(
        "/admin/clientes/nuevo",
        data={
            "NombreCompleto": "Cliente Con Riesgo",
            "SegmentoRiesgoId": "1",
            "ClasificacionId": "1",
            "PlazoPagoId": "1",
            "LimiteCreditoPersonal": "1500.75",
        },
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert "creado correctamente".encode() in response.data
    creado = backend.clientes[1]
    assert creado["SegmentoRiesgoId"] == "1"
    assert creado["ClasificacionId"] == "1"
    assert creado["PlazoPagoId"] == "1"
    assert creado["LimiteCreditoPersonal"] == "1500.75"


def test_crear_cliente_sin_nombre_muestra_error(client):
    _login(client)
    response = client.post(
        "/admin/clientes/nuevo", data={"CiudadId": "1"}, follow_redirects=True
    )
    assert response.status_code == 200
    assert "obligatorio".encode() in response.data


def test_editar_cliente(client, backend):
    _login(client)
    client.post("/admin/clientes/nuevo", data={"NombreCompleto": "Original"})
    cliente_id = next(iter(backend.clientes))

    response = client.post(
        f"/admin/clientes/{cliente_id}/editar",
        data={"NombreCompleto": "Editado"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert "actualizado correctamente".encode() in response.data
    assert backend.clientes[cliente_id]["NombreCompleto"] == "Editado"


def test_eliminar_cliente(client, backend):
    _login(client)
    client.post("/admin/clientes/nuevo", data={"NombreCompleto": "A eliminar"})
    cliente_id = next(iter(backend.clientes))

    response = client.post(f"/admin/clientes/{cliente_id}/eliminar", follow_redirects=True)
    assert response.status_code == 200
    assert "eliminado correctamente".encode() in response.data
    assert backend.clientes[cliente_id]["Activo"] is False
