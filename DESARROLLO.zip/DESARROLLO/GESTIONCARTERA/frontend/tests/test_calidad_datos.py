from conftest import TEST_PASSWORD, TEST_USERNAME


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_scoring_index_enlaza_a_calidad_de_datos(client):
    _login(client)
    response = client.get("/scoring-morosidad/")
    assert response.status_code == 200
    assert "Validación de calidad de datos" in response.data.decode()


def test_calidad_datos_requiere_login(client):
    response = client.get("/scoring-morosidad/calidad-datos/")
    assert response.status_code == 302


def test_calidad_datos_index_lista_las_cuatro_opciones(client):
    _login(client)
    response = client.get("/scoring-morosidad/calidad-datos/")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Ejecución completa" in body
    assert "Solo el veredicto" in body
    assert "Revisar la última corrida" in body
    assert "Evolución de la calidad" in body


def test_confirmar_clave_desconocida_da_404(client):
    _login(client)
    response = client.get("/scoring-morosidad/calidad-datos/no-existe")
    assert response.status_code == 404


def test_ejecutar_ejecucion_completa_muestra_detalle_y_veredicto(client):
    _login(client)
    response = client.post("/scoring-morosidad/calidad-datos/ejecucion-completa/ejecutar", follow_redirects=True)
    assert response.status_code == 200
    body = response.data.decode()
    assert "NO APTO" in body
    assert "B1_ABONO_ANTERIOR" in body
    assert "A1_ABONOS_HUERFANOS" in body


def test_ejecutar_solo_veredicto_no_muestra_tabla_de_detalle(client):
    _login(client)
    response = client.post("/scoring-morosidad/calidad-datos/solo-veredicto/ejecutar", follow_redirects=True)
    assert response.status_code == 200
    body = response.data.decode()
    assert "APTO CON OBSERVACIONES" in body
    assert "B1_ABONO_ANTERIOR" not in body  # ese detalle solo viene de ejecucion-completa


def test_ultima_validacion_muestra_la_tabla(client):
    _login(client)
    response = client.get("/scoring-morosidad/calidad-datos/ultima-validacion")
    assert response.status_code == 200
    assert "B1_ABONO_ANTERIOR" in response.data.decode()


def test_evolucion_muestra_criticos_por_dimension(client):
    _login(client)
    response = client.get("/scoring-morosidad/calidad-datos/evolucion")
    assert response.status_code == 200
    body = response.data.decode()
    assert "CONSISTENCIA" in body
    assert "INTEGRIDAD" in body
