from conftest import TEST_PASSWORD, TEST_USERNAME


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_calidad_datos_index_enlaza_al_nuevo_menu(client):
    _login(client)
    response = client.get("/scoring-morosidad/calidad-datos/")
    assert response.status_code == 200
    assert "Métricas de evaluación del modelo" in response.data.decode()


def test_metricas_requiere_login(client):
    response = client.get("/scoring-morosidad/metricas-evaluacion/")
    assert response.status_code == 302


def test_metricas_index_lista_las_tres_opciones(client):
    _login(client)
    response = client.get("/scoring-morosidad/metricas-evaluacion/")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Matriz comparativa de alternativas" in body
    assert "Desempeño observado en producción" in body
    assert "Declarado vs. observado" in body


def test_comparativo_alternativas_muestra_ambas_filas(client):
    _login(client)
    response = client.get("/scoring-morosidad/metricas-evaluacion/comparativo-alternativas")
    assert response.status_code == 200
    body = response.data.decode()
    assert "REGRESION_LOGISTICA_WOE" in body
    assert "XGBOOST" in body


def test_desempeno_produccion_muestra_mensaje_sin_eventos(client):
    _login(client)
    response = client.get("/scoring-morosidad/metricas-evaluacion/desempeno-produccion")
    assert response.status_code == 200
    assert "Todav" in response.data.decode()


def test_declarado_vs_observado_muestra_el_veredicto(client):
    _login(client)
    response = client.get("/scoring-morosidad/metricas-evaluacion/declarado-vs-observado")
    assert response.status_code == 200
    assert "INSUFICIENTE" in response.data.decode()
