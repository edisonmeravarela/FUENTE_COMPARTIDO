from conftest import TEST_PASSWORD, TEST_USERNAME


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_lista_clientes_muestra_filtros_y_paginacion(client):
    _login(client)
    response = client.get("/admin/clientes/")
    assert response.status_code == 200
    body = response.data.decode()
    assert 'name="ClienteId"' in body
    assert 'name="Nombre"' in body
    assert 'name="Identificacion"' in body
    assert 'name="CiudadId"' in body
    assert 'name="SegmentoRiesgoId"' in body
    assert 'name="ClasificacionId"' in body
    assert 'name="PlazoPagoId"' in body
    # 25 clientes, 20 por página -> primera página muestra del 01 al 20
    assert "Cliente Numero 01" in body
    assert "Cliente Numero 20" in body
    assert "Cliente Numero 21" not in body
    assert "Página 1 de 2" in body
    assert "25 clientes" in body


def test_lista_clientes_pagina_2_muestra_el_resto(client):
    _login(client)
    response = client.get("/admin/clientes/?pagina=2")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Cliente Numero 21" in body
    assert "Cliente Numero 25" in body
    assert "Cliente Numero 01" not in body
    assert "Página 2 de 2" in body


def test_pagina_fuera_de_rango_se_limita_a_la_ultima(client):
    _login(client)
    response = client.get("/admin/clientes/?pagina=99")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Página 2 de 2" in body


def test_filtrar_clientes_por_nombre_busca_por_coincidencia(client):
    _login(client)
    response = client.get("/admin/clientes/?Nombre=Numero 0")
    body = response.data.decode()
    assert "Cliente Numero 01" in body
    assert "Cliente Numero 09" in body
    assert "Cliente Numero 21" not in body


def test_filtrar_clientes_por_codigo(client):
    _login(client)
    response = client.get("/admin/clientes/?ClienteId=5")
    body = response.data.decode()
    assert "Cliente Numero 05" in body
    assert "Cliente Numero 01" not in body
    assert "Página" not in body  # con un solo resultado no hay paginación


def test_filtrar_clientes_por_ciudad(client):
    _login(client)
    response = client.get("/admin/clientes/?CiudadId=1")
    body = response.data.decode()
    # solo clientes con Ciudad == "Quito" (índice par): 02, 04, ...
    assert "Cliente Numero 02" in body
    assert "Cliente Numero 01" not in body


def test_filtrar_clientes_por_segmento_riesgo(client):
    _login(client)
    response = client.get("/admin/clientes/?SegmentoRiesgoId=1")
    body = response.data.decode()
    # segmento "1" -> "Riesgo bajo" -> índice par: 02, 04, ...
    assert "Cliente Numero 02" in body
    assert "Cliente Numero 01" not in body


def test_filtrar_clientes_por_clasificacion(client):
    _login(client)
    response = client.get("/admin/clientes/?ClasificacionId=1")
    body = response.data.decode()
    # clasificación "1" -> "Cliente preferencial" -> solo el cliente 01
    assert "Cliente Numero 01" in body
    assert "Cliente Numero 02" not in body


def test_filtrar_clientes_por_plazo_pago(client):
    _login(client)
    response = client.get("/admin/clientes/?PlazoPagoId=1")
    body = response.data.decode()
    # plazo "1" -> "CONTADO", pero todos los clientes de prueba tienen "30 DÍAS"
    assert "No hay clientes para los filtros seleccionados" in body


def test_lista_clientes_muestra_columnas_de_riesgo(client):
    _login(client)
    response = client.get("/admin/clientes/")
    body = response.data.decode()
    assert "Segmento de riesgo" in body
    assert "Clasificación" in body
    assert "Plazo de pago" in body
    assert "Límite de crédito" in body
    assert "Riesgo bajo" in body
    assert "Cliente preferencial" in body
