from conftest import TEST_PASSWORD, TEST_USERNAME


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_calidad_datos_index_enlaza_al_nuevo_menu(client):
    _login(client)
    response = client.get("/scoring-morosidad/calidad-datos/")
    assert response.status_code == 200
    assert "Controles Esquema Calidad Deriva" in response.data.decode()


def test_controles_requiere_login(client):
    response = client.get("/scoring-morosidad/controles-esquema-deriva/")
    assert response.status_code == 302


def test_controles_index_lista_las_cuatro_opciones(client):
    _login(client)
    response = client.get("/scoring-morosidad/controles-esquema-deriva/")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Validar esquema" in body
    assert "Medir deriva" in body
    assert "Diagnóstico de deriva" in body
    assert "Evolución de la deriva" in body


def test_confirmar_clave_desconocida_da_404(client):
    _login(client)
    response = client.get("/scoring-morosidad/controles-esquema-deriva/no-existe")
    assert response.status_code == 404


def test_ejecutar_validar_esquema_muestra_el_veredicto(client):
    _login(client)
    response = client.post(
        "/scoring-morosidad/controles-esquema-deriva/validar-esquema/ejecutar", follow_redirects=True
    )
    assert response.status_code == 200
    body = response.data.decode()
    assert "NULABILIDAD DISTINTA" in body


def test_ejecutar_medir_deriva_muestra_el_psi_y_enlaza_al_desglose(client):
    _login(client)
    response = client.post(
        "/scoring-morosidad/controles-esquema-deriva/medir-deriva/ejecutar", follow_redirects=True
    )
    assert response.status_code == 200
    body = response.data.decode()
    assert "3.1900" in body
    assert "/scoring-morosidad/controles-esquema-deriva/diagnostico-drift/7/desglose" in body


def test_diagnostico_drift_muestra_la_tabla(client):
    _login(client)
    response = client.get("/scoring-morosidad/controles-esquema-deriva/diagnostico-drift")
    assert response.status_code == 200
    assert "CiudadId" in response.data.decode()


def test_desglose_drift_muestra_los_tramos(client):
    _login(client)
    response = client.get("/scoring-morosidad/controles-esquema-deriva/diagnostico-drift/7/desglose")
    assert response.status_code == 200
    assert "Guayaquil" in response.data.decode()


def test_evolucion_drift_muestra_la_tabla(client):
    _login(client)
    response = client.get("/scoring-morosidad/controles-esquema-deriva/evolucion-drift")
    assert response.status_code == 200
    assert "DERIVA SIGNIFICATIVA" in response.data.decode()
