from conftest import TEST_PASSWORD, TEST_USERNAME


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_lista_abonos_muestra_filtros_y_resultados(client):
    _login(client)
    response = client.get("/admin/abonos/")
    assert response.status_code == 200
    body = response.data.decode()
    # los 6 controles pedidos por el usuario
    assert 'name="FechaRegistro"' in body and 'type="date"' in body
    assert 'name="NumeroFactura"' in body
    assert 'name="AbonoId"' in body and 'type="number"' in body
    assert 'name="FechaAbono"' in body
    assert 'name="FormaPagoId"' in body
    assert 'name="ClienteId"' in body
    assert 'name="UsuarioId"' in body
    assert "1 - EFECTIVO" in body
    assert "1 - Cliente Uno" in body
    assert "F-001" in body
    assert "F-003" in body


def test_lista_abonos_muestra_columna_de_usuario(client):
    _login(client)
    response = client.get("/admin/abonos/")
    body = response.data.decode()
    assert "Usuario" in body
    assert "Admin de Prueba" in body
    assert "Vendedor de Prueba" in body


def test_filtrar_abonos_por_usuario(client):
    _login(client)
    response = client.get("/admin/abonos/?UsuarioId=2")
    body = response.data.decode()
    assert "F-003" in body
    assert "F-001" not in body


def test_filtrar_abonos_por_numero_factura(client):
    _login(client)
    response = client.get("/admin/abonos/?NumeroFactura=F-001")
    body = response.data.decode()
    assert "F-001" in body
    assert "F-003" not in body


def test_filtrar_abonos_por_abono_id(client):
    _login(client)
    response = client.get("/admin/abonos/?AbonoId=2")
    body = response.data.decode()
    assert "F-003" in body
    assert "F-001" not in body


def test_filtrar_abonos_por_forma_pago(client):
    _login(client)
    response = client.get("/admin/abonos/?FormaPagoId=2")
    body = response.data.decode()
    assert "F-003" in body
    assert "F-001" not in body


def test_filtrar_abonos_por_cliente(client):
    _login(client)
    response = client.get("/admin/abonos/?ClienteId=1")
    body = response.data.decode()
    assert "F-001" in body
    assert "F-003" not in body


def test_lista_abonos_muestra_20_por_pagina(client):
    # self.abonos trae 22 registros en total (F-001, F-003 + 20 "P-XXX")
    _login(client)
    response = client.get("/admin/abonos/")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Página 1 de 2 (22 abonos)" in body
    assert "P-018" in body
    assert "P-020" not in body  # ya en la página 2


def test_lista_abonos_pagina_2_muestra_el_resto(client):
    _login(client)
    response = client.get("/admin/abonos/?pagina=2")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Página 2 de 2" in body
    assert "P-020" in body
    assert "F-001" not in body


def test_filtro_de_abonos_con_pocos_resultados_no_muestra_paginacion(client):
    _login(client)
    response = client.get("/admin/abonos/?NumeroFactura=F-001")
    body = response.data.decode()
    assert "Página" not in body
