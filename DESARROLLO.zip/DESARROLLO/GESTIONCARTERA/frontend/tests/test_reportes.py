from conftest import TEST_PASSWORD, TEST_USERNAME


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_dashboard_muestra_tarjeta_reportes(client):
    _login(client)
    response = client.get("/dashboard")
    assert response.status_code == 200
    assert "Reportes".encode() in response.data


def test_reportes_requiere_login(client):
    response = client.get("/reportes/")
    assert response.status_code == 302


def test_reportes_index_lista_cartera_por_cobrar(client):
    _login(client)
    response = client.get("/reportes/")
    assert response.status_code == 200
    assert "Cartera por Cobrar".encode() in response.data


def test_reporte_cartera_por_cobrar_muestra_filtros_y_datos(client):
    _login(client)
    response = client.get("/reportes/cartera-por-cobrar")
    assert response.status_code == 200
    body = response.data.decode()
    # los 5 controles pedidos por el usuario
    assert 'name="NumeroFactura"' in body
    assert 'name="FechaEmision"' in body and 'type="date"' in body
    assert 'name="VendedorId"' in body
    assert 'name="ClienteId"' in body
    assert 'name="Dias"' in body and 'type="number"' in body
    assert "1 - Vendedor Uno" in body
    assert "F-001" in body
    assert "F-003" in body


def test_reporte_cartera_filtra_por_numero(client):
    _login(client)
    response = client.get("/reportes/cartera-por-cobrar?NumeroFactura=F-001")
    body = response.data.decode()
    assert "F-001" in body
    assert "F-003" not in body


def test_reporte_cartera_filtra_por_vendedor(client):
    _login(client)
    response = client.get("/reportes/cartera-por-cobrar?VendedorId=2")
    body = response.data.decode()
    assert "F-003" in body
    assert "F-001" not in body


def test_reporte_cartera_filtra_por_dias(client):
    _login(client)
    response = client.get("/reportes/cartera-por-cobrar?Dias=50")
    body = response.data.decode()
    assert "F-003" in body  # 111 días
    assert "F-001" not in body  # 19 días


def test_reporte_cartera_muestra_20_por_pagina(client):
    # self.cartera trae 22 registros en total (F-001, F-003 + 20 "P-XXX")
    _login(client)
    response = client.get("/reportes/cartera-por-cobrar")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Página 1 de 2 (22 facturas)" in body
    assert "P-018" in body
    assert "P-020" not in body  # ya en la página 2


def test_reporte_cartera_pagina_2_muestra_el_resto(client):
    _login(client)
    response = client.get("/reportes/cartera-por-cobrar?pagina=2")
    assert response.status_code == 200
    body = response.data.decode()
    assert "Página 2 de 2" in body
    assert "P-020" in body
    assert "F-001" not in body


def test_reporte_cartera_filtro_con_pocos_resultados_no_muestra_paginacion(client):
    _login(client)
    response = client.get("/reportes/cartera-por-cobrar?NumeroFactura=F-001")
    body = response.data.decode()
    assert "Página" not in body
