from conftest import TEST_PASSWORD, TEST_USERNAME


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_formulario_de_factura_incluye_el_panel_de_riesgo_y_su_script(client):
    _login(client)
    response = client.get("/admin/facturas/nuevo")
    assert response.status_code == 200
    body = response.data.decode()
    assert 'id="riesgo-cliente-panel"' in body
    assert "admin_facturas.riesgo_cliente_ajax" not in body  # ya resuelto a una URL
    assert "/admin/facturas/riesgo-cliente" in body


def test_riesgo_cliente_ajax_requiere_login(client):
    response = client.get("/admin/facturas/riesgo-cliente?ClienteId=1")
    assert response.status_code == 401


def test_riesgo_cliente_ajax_sin_cliente_devuelve_400(client):
    _login(client)
    response = client.get("/admin/facturas/riesgo-cliente")
    assert response.status_code == 400


def test_riesgo_cliente_ajax_devuelve_segmento_y_clasificacion(client):
    _login(client)
    response = client.get("/admin/facturas/riesgo-cliente?ClienteId=1")
    assert response.status_code == 200
    body = response.get_json()
    assert body["SegmentoRiesgoDescripcion"] == "Mora recurrente; crédito reducido y garantía requerida."
    assert body["ClasificacionDescripcion"] == "Compra recurrente con volumen medio."


def test_riesgo_cliente_ajax_cliente_inexistente(client):
    _login(client)
    response = client.get("/admin/facturas/riesgo-cliente?ClienteId=999999")
    assert response.status_code == 404
