from conftest import TEST_PASSWORD, TEST_USERNAME


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_listado_de_clientes_enlaza_el_nombre_al_endpoint_ajax(client):
    _login(client)
    response = client.get("/admin/clientes/")
    assert response.status_code == 200
    body = response.data.decode()
    assert "/admin/clientes/1/historial-riesgo" in body
    assert 'class="ver-historial-riesgo"' in body
    # ya no debe abrir una ventana/pantalla nueva
    assert "window.open" not in body
    # el modal y su script sí deben estar en la misma pantalla
    assert 'id="historial-riesgo-modal"' in body
    assert "fetch(enlace.href)" in body


def test_historial_riesgo_ajax_requiere_login(client):
    response = client.get("/admin/clientes/1/historial-riesgo")
    assert response.status_code == 401


def test_historial_riesgo_ajax_devuelve_json_con_los_cambios(client):
    _login(client)
    response = client.get("/admin/clientes/1/historial-riesgo")
    assert response.status_code == 200
    filas = response.get_json()
    assert filas[0]["TipoCambio"] == "AUMENTO DE RIESGO"
    assert filas[0]["SegmentoNuevo"] == "Riesgo alto"


def test_historial_riesgo_ajax_sin_cambios_devuelve_lista_vacia(client):
    _login(client)
    response = client.get("/admin/clientes/999/historial-riesgo")
    assert response.status_code == 200
    assert response.get_json() == []
