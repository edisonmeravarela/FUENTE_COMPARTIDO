from conftest import TEST_PASSWORD, TEST_USERNAME


def _login(client):
    client.post("/", data={"username": TEST_USERNAME, "password": TEST_PASSWORD})


def test_nuevo_abono_solo_lista_facturas_con_saldo(client):
    _login(client)
    response = client.get("/admin/abonos/nuevo")
    assert response.status_code == 200
    body = response.data.decode()
    # F-001 sí tiene saldo pendiente
    assert "F-001" in body
    assert 'data-numero="F-001"' in body
    assert 'data-vendedor="1"' in body
    # F-002 (anulada) y F-003 (cancelada) no deben ofrecerse para abonar
    assert "F-002" not in body
    assert "F-003" not in body


def test_nuevo_abono_muestra_panel_de_factura_y_script(client):
    _login(client)
    response = client.get("/admin/abonos/nuevo")
    body = response.data.decode()
    assert 'id="factura-info-panel"' in body
    assert "Selecciona una factura para ver su información." in body
    assert 'id="valor-abono-error"' in body
    assert "es mayor al saldo pendiente de la factura" in body  # mensaje de validación en el JS
    assert "admin_abonos.estado_cuenta_ajax" not in body  # ya debe estar resuelto a una URL
    assert "/admin/abonos/estado-cuenta" in body


def test_nuevo_abono_amplia_el_formulario_y_valida_retencion(client):
    # Punto 1 del pedido: el formulario de nuevo abono usa una tarjeta más
    # ancha para poder mostrar la información completa de la factura.
    _login(client)
    response = client.get("/admin/abonos/nuevo")
    body = response.data.decode()
    assert "auth-card--ancha" in body
    assert "factura-info-grid" in body  # el panel muestra varios campos, no solo el saldo
    # el cálculo de saldo disponible en JS considera abono + retención
    assert "retencionInput" in body


def test_editar_abono_no_incluye_el_panel_de_factura(client):
    # Editar un abono existente debe seguir usando el combo genérico de
    # facturas (todas las vigentes), no el de "con saldo".
    _login(client)
    response = client.get("/admin/abonos/99/editar")
    assert response.status_code == 200
    body = response.data.decode()
    assert 'id="factura-info-panel"' not in body


def test_estado_cuenta_ajax_requiere_login(client):
    response = client.get("/admin/abonos/estado-cuenta?NumeroFactura=F-001")
    assert response.status_code == 401


def test_estado_cuenta_ajax_devuelve_saldo_actual(client):
    _login(client)
    response = client.get("/admin/abonos/estado-cuenta?NumeroFactura=F-001&VendedorId=1")
    assert response.status_code == 200
    assert response.get_json()["SaldoActual"] == 60.0


def test_estado_cuenta_ajax_sin_numero_devuelve_400(client):
    _login(client)
    response = client.get("/admin/abonos/estado-cuenta")
    assert response.status_code == 400


def test_estado_cuenta_ajax_factura_inexistente(client):
    _login(client)
    response = client.get("/admin/abonos/estado-cuenta?NumeroFactura=NO-EXISTE")
    assert response.status_code == 400
    assert "No existe una factura" in response.get_json()["error"]
