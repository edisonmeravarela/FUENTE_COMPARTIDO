from flask import Blueprint, Flask

from config import Config
from src.entities import ENTITIES
from src.router.abonos_detalle_routes import abonos_detalle_bp
from src.router.admin_routes import make_admin_blueprint
from src.router.calidad_datos_routes import calidad_datos_bp
from src.router.controles_esquema_deriva_routes import controles_esquema_deriva_bp
from src.router.metricas_evaluacion_routes import metricas_evaluacion_bp
from src.router.reportes_routes import reportes_bp
from src.router.routes import main_bp
from src.router.scoring_routes import scoring_bp
from src.router.seguridad_routes import seguridad_bp


def create_app(config_class: type = Config) -> Flask:
    # template_folder="src" habilita las rutas relativas "pages/..." y
    # "components/..." usadas por {% extends %} / {% include %} en las plantillas.
    app = Flask(__name__, template_folder="src", static_folder=None)
    app.config.from_object(config_class)

    # Solo se sirven por HTTP las carpetas realmente estáticas (styles, assets);
    # el resto de "src" (router, services, store, utils) nunca queda expuesto.
    styles_bp = Blueprint("styles", __name__, static_folder="src/styles", static_url_path="/static/styles")
    assets_bp = Blueprint("assets", __name__, static_folder="src/assets", static_url_path="/static/assets")
    app.register_blueprint(styles_bp)
    app.register_blueprint(assets_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(reportes_bp)
    app.register_blueprint(scoring_bp)
    app.register_blueprint(calidad_datos_bp)
    app.register_blueprint(controles_esquema_deriva_bp)
    app.register_blueprint(metricas_evaluacion_bp)
    app.register_blueprint(seguridad_bp)
    app.register_blueprint(abonos_detalle_bp)
    for entity in ENTITIES.values():
        app.register_blueprint(make_admin_blueprint(entity))
    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True, port=5000)
