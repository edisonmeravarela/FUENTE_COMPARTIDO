import pytest

from app import create_app
from config import TestConfig
from src.services import backend_client

TEST_USERNAME = "usuario_prueba"
TEST_PASSWORD = "ClaveSegura123!"
TEST_TOKEN = "token-de-prueba"


class FakeResponse:
    def __init__(self, status_code: int, json_data=None):
        self.status_code = status_code
        self._json_data = json_data if json_data is not None else {}

    def json(self):
        return self._json_data


class FakeBackend:
    """Sustituye al backend real por HTTP: valida login y sirve un CRUD
    mínimo de Clientes en memoria, suficiente para probar el frontend
    de forma aislada."""

    def __init__(self):
        self.clientes: dict[int, dict] = {}
        self._next_id = 1
        self.facturas = [
            {
                "FacturaId": 1,
                "NumeroFactura": "F-001",
                "FechaEmision": "2026-08-01",
                "CodigoVendedor": 1,
                "NombreVendedor": "Vendedor Uno",
                "CodigoCliente": 1,
                "NombreCliente": "Cliente Uno",
                "ValorTotal": 100.0,
                "TotalAbonado": 40.0,
                "SaldoPendiente": 60.0,
                "FechaUltimoPago": "2026-08-10",
                "CodigoPlazoPago": 1,
                "PlazoPago": "CONTADO",
                "FechaVencimiento": "2026-08-01",
                "CodigoEstadoFactura": 1,
                "Estado": "Pendiente",
                "Observaciones": None,
            },
            {
                "FacturaId": 2,
                "NumeroFactura": "F-002",
                "FechaEmision": "2026-08-05",
                "CodigoVendedor": 2,
                "NombreVendedor": "Vendedor Dos",
                "CodigoCliente": 1,
                "NombreCliente": "Cliente Uno",
                "ValorTotal": 50.0,
                "TotalAbonado": 0.0,
                "SaldoPendiente": 50.0,
                "FechaUltimoPago": None,
                "CodigoPlazoPago": 2,
                "PlazoPago": "15 DÍAS",
                "FechaVencimiento": "2026-08-20",
                "CodigoEstadoFactura": 3,
                "Estado": "Anulada",
                "Observaciones": None,
            },
            {
                "FacturaId": 3,
                "NumeroFactura": "F-003",
                "FechaEmision": "2026-05-01",
                "CodigoVendedor": 2,
                "NombreVendedor": "Vendedor Dos",
                "CodigoCliente": 2,
                "NombreCliente": "Cliente Dos",
                "ValorTotal": 105.0,
                "TotalAbonado": 105.0,
                "SaldoPendiente": 0.0,
                "FechaUltimoPago": "2026-05-15",
                "CodigoPlazoPago": None,
                "PlazoPago": "SIN PLAZO",
                "FechaVencimiento": None,
                "CodigoEstadoFactura": 2,
                "Estado": "Cancelada",
                "Observaciones": None,
            },
        ] + [
            # 20 facturas neutras adicionales (mismo vendedor/cliente) solo
            # para poder probar la paginación de 20 en 20; no interfieren
            # con los filtros por NumeroFactura/VendedorId/EstadoFacturaId de arriba.
            {
                "FacturaId": 100 + i,
                "NumeroFactura": f"P-{i:03d}",
                "FechaEmision": "2026-01-01",
                "CodigoVendedor": 1,
                "NombreVendedor": "Vendedor Uno",
                "CodigoCliente": 1,
                "NombreCliente": "Cliente Uno",
                "ValorTotal": 10.0,
                "TotalAbonado": 0.0,
                "SaldoPendiente": 10.0,
                "FechaUltimoPago": None,
                "CodigoPlazoPago": 1,
                "PlazoPago": "CONTADO",
                "FechaVencimiento": "2026-01-01",
                "CodigoEstadoFactura": 1,
                "Estado": "Pendiente",
                "Observaciones": None,
            }
            for i in range(1, 21)
        ]
        self.cartera = [
            {
                "FacturaId": 1,
                "NumeroFactura": "F-001",
                "FechaEmision": "2026-08-01",
                "CodigoVendedor": 1,
                "NombreVendedor": "Vendedor Uno",
                "CodigoCliente": 1,
                "NombreCliente": "Cliente Uno",
                "ValorTotal": 100.0,
                "TotalPagado": 40.0,
                "SaldoPendiente": 60.0,
                "FechaUltimoAbono": "2026-08-10",
                "DiasDesdeEmision": 19,
                "DiasDesdeUltimoAbono": 10,
                "Observaciones": None,
            },
            {
                "FacturaId": 3,
                "NumeroFactura": "F-003",
                "FechaEmision": "2026-05-01",
                "CodigoVendedor": 2,
                "NombreVendedor": "Vendedor Dos",
                "CodigoCliente": 2,
                "NombreCliente": "Cliente Dos",
                "ValorTotal": 200.0,
                "TotalPagado": 0.0,
                "SaldoPendiente": 200.0,
                "FechaUltimoAbono": None,
                "DiasDesdeEmision": 111,
                "DiasDesdeUltimoAbono": None,
                "Observaciones": None,
            },
        ] + [
            # 20 facturas neutras adicionales solo para poder probar la
            # paginación de 20 en 20; DiasDesdeEmision bajo para no
            # interferir con el filtro por Dias de arriba.
            {
                "FacturaId": 200 + i,
                "NumeroFactura": f"P-{i:03d}",
                "FechaEmision": "2026-08-15",
                "CodigoVendedor": 1,
                "NombreVendedor": "Vendedor Uno",
                "CodigoCliente": 1,
                "NombreCliente": "Cliente Uno",
                "ValorTotal": 10.0,
                "TotalPagado": 0.0,
                "SaldoPendiente": 10.0,
                "FechaUltimoAbono": None,
                "DiasDesdeEmision": 5,
                "DiasDesdeUltimoAbono": None,
                "Observaciones": None,
            }
            for i in range(1, 21)
        ]

        # Módulo Seguridad: usuarios, roles/permisos y su matriz de
        # asignación, mutable para poder probar activar/inactivar y
        # asignar/revocar sin tocar la base de datos real.
        self.usuarios_seguridad = {
            1: {
                "UsuarioId": 1, "NombreUsuario": "admin_prueba", "Correo": "admin@test.com",
                "NombresCompletos": "Admin de Prueba", "VendedorId": None, "DebeCambiarClave": False,
                "Activo": True, "UltimoAcceso": "2026-09-10T08:00:00", "FechaCreacion": "2026-01-01T00:00:00",
                "Roles": "ADMINISTRADOR",
            },
            2: {
                "UsuarioId": 2, "NombreUsuario": "vendedor_prueba", "Correo": "vendedor@test.com",
                "NombresCompletos": "Vendedor de Prueba", "VendedorId": 1, "DebeCambiarClave": False,
                "Activo": True, "UltimoAcceso": "2026-09-09T10:00:00", "FechaCreacion": "2026-01-01T00:00:00",
                "Roles": "VENDEDOR/COBRADOR",
            },
        }
        self.roles_seguridad = [
            {"RolId": 1, "Nombre": "ADMINISTRADOR"},
            {"RolId": 2, "Nombre": "SUPERVISOR DE CARTERA"},
            {"RolId": 3, "Nombre": "VENDEDOR/COBRADOR"},
            {"RolId": 4, "Nombre": "CONSULTA"},
        ]
        self.roles_por_usuario = {1: [1], 2: [3]}
        self._siguiente_usuario_id = 3
        self.permisos_seguridad = [
            {"ModuloId": 1, "ModuloCodigo": "VENDEDORES", "ModuloNombre": "VENDEDORES", "SoloAdministrador": False,
             "PermisoId": 1, "Codigo": "VENDEDORES.CONSULTAR", "Nombre": "Consultar vendedores"},
            {"ModuloId": 2, "ModuloCodigo": "SCORING", "ModuloNombre": "SCORING MOROSIDAD", "SoloAdministrador": False,
             "PermisoId": 2, "Codigo": "SCORING.EJECUTAR", "Nombre": "Ejecutar scoring"},
            {"ModuloId": 3, "ModuloCodigo": "SEGURIDAD", "ModuloNombre": "SEGURIDAD", "SoloAdministrador": True,
             "PermisoId": 3, "Codigo": "SEGURIDAD.USUARIOS", "Nombre": "Administrar usuarios"},
        ]
        self.asignaciones_seguridad = {(1, 1), (1, 2), (1, 3)}  # todo asignado solo a ADMINISTRADOR
        self.bitacora_autorizacion_lineas = [
            "2026-09-10 08:00:00 INFO Autorizado POST /api/vendedores por PERMISO (usuario=admin_prueba).",
        ]
        self.auditoria_seguridad = [
            {"AuditoriaId": 1, "Fecha": "2026-09-10T08:00:00", "NombreUsuario": "admin_prueba", "Accion": "LOGIN",
             "Entidad": "Sesion", "EntidadId": "abc", "ValoresAnteriores": None, "ValoresNuevos": None, "DireccionIP": "127.0.0.1"},
        ]

        # Registro genérico (forma CRUD) para GET /api/abonos/<id>, usado por
        # editar(); distinto de self.abonos (forma de sp_ConsultarAbonos).
        self.abonos_crud = {
            99: {
                "AbonoId": 99,
                "FacturaId": 1,
                "FechaAbono": "2026-08-10",
                "ValorAbono": 10.0,
                "ValorRetencion": 0.0,
                "FormaPagoId": 1,
                "Observacion": None,
            }
        }

        # 25 clientes para poder probar paginación de 20 en 20 (2 páginas).
        self.clientes_consultar = [
            {
                "CodigoCliente": i,
                "NombreCompleto": f"Cliente Numero {i:02d}",
                "Identificacion": "0102030405" if i == 1 else None,
                "Direccion": None,
                "Ciudad": "Quito" if i % 2 == 0 else "Guayaquil",
                "Telefono": None,
                "SegmentoRiesgo": "Riesgo bajo" if i % 2 == 0 else "Riesgo alto",
                "Clasificacion": "Cliente preferencial" if i == 1 else "Cliente regular",
                "PlazoPago": "30 DÍAS",
                "LimiteCreditoPersonal": None,
                "LimiteCreditoVigente": 500.0,
                "Estado": "ACTIVO" if i != 5 else "INACTIVO",
                "FechaRegistro": "2026-01-01T00:00:00",
            }
            for i in range(1, 26)
        ]

        self.abonos = [
            {
                "AbonoId": 1,
                "NumeroFactura": "F-001",
                "CodigoCliente": 1,
                "NombreCliente": "Cliente Uno",
                "FechaAbono": "2026-08-10",
                "ValorAbono": 40.0,
                "ValorRetencion": 0.0,
                "TotalAplicado": 40.0,
                "CodigoFormaPago": 1,
                "FormaPago": "EFECTIVO",
                "FechaRegistro": "2026-08-10T09:00:00",
                "CodigoUsuario": 1,
                "UsuarioRegistro": "Admin de Prueba",
                "Observacion": None,
            },
            {
                "AbonoId": 2,
                "NumeroFactura": "F-003",
                "CodigoCliente": 2,
                "NombreCliente": "Cliente Dos",
                "FechaAbono": "2026-08-12",
                "ValorAbono": 100.0,
                "ValorRetencion": 5.0,
                "TotalAplicado": 105.0,
                "CodigoFormaPago": 2,
                "FormaPago": "TRANSFERENCIA",
                "FechaRegistro": "2026-08-12T14:30:00",
                "CodigoUsuario": 2,
                "UsuarioRegistro": "Vendedor de Prueba",
                "Observacion": "Pago parcial",
            },
        ] + [
            # 20 abonos neutros adicionales solo para poder probar la
            # paginación de 20 en 20; no interfieren con los filtros por
            # NumeroFactura/AbonoId/FormaPagoId/ClienteId/UsuarioId de arriba.
            {
                "AbonoId": 100 + i,
                "NumeroFactura": f"P-{i:03d}",
                "CodigoCliente": 1,
                "NombreCliente": "Cliente Uno",
                "FechaAbono": "2026-01-01",
                "ValorAbono": 5.0,
                "ValorRetencion": 0.0,
                "TotalAplicado": 5.0,
                "CodigoFormaPago": 1,
                "FormaPago": "EFECTIVO",
                "FechaRegistro": "2026-01-01T00:00:00",
                "CodigoUsuario": 1,
                "UsuarioRegistro": "Admin de Prueba",
                "Observacion": None,
            }
            for i in range(1, 21)
        ]

    def _check_token(self, token) -> bool:
        return token == TEST_TOKEN

    def _abonos_filtrados(self, params: dict) -> list[dict]:
        params = params or {}
        rows = list(self.abonos)
        if params.get("NumeroFactura"):
            rows = [r for r in rows if r["NumeroFactura"] == params["NumeroFactura"]]
        if params.get("AbonoId"):
            rows = [r for r in rows if str(r["AbonoId"]) == str(params["AbonoId"])]
        if params.get("FechaAbono"):
            rows = [r for r in rows if r["FechaAbono"] == params["FechaAbono"]]
        if params.get("FechaRegistro"):
            rows = [r for r in rows if r["FechaRegistro"].startswith(params["FechaRegistro"])]
        if params.get("FormaPagoId"):
            rows = [r for r in rows if str(r["CodigoFormaPago"]) == str(params["FormaPagoId"])]
        if params.get("ClienteId"):
            rows = [r for r in rows if str(r["CodigoCliente"]) == str(params["ClienteId"])]
        if params.get("UsuarioId"):
            rows = [r for r in rows if str(r["CodigoUsuario"]) == str(params["UsuarioId"])]
        return rows

    def _detalle_abonos(self, params: dict):
        params = params or {}
        numero_factura = params.get("NumeroFactura")
        if not numero_factura:
            return FakeResponse(400, {"error": "Debe ingresar el número de factura."})

        coincidencias = [a for a in self.abonos if a["NumeroFactura"] == numero_factura]
        if not coincidencias:
            return FakeResponse(400, {"error": f"No existe una factura con el número {numero_factura}."})

        # F-001: valor 100 con 40 abonado -> queda saldo. F-003: valor 105
        # con 105 aplicado (100 abono + 5 retención) -> queda cancelada.
        valor_total = {"F-001": 100.0, "F-003": 105.0}.get(numero_factura, 0.0)
        total_aplicado = sum(a["TotalAplicado"] for a in coincidencias)
        saldo_total = valor_total - total_aplicado

        filas = []
        for i, a in enumerate(coincidencias, start=1):
            filas.append(
                {
                    "Nro": str(i),
                    "NumeroFactura": a["NumeroFactura"],
                    "NombreCliente": a["NombreCliente"],
                    "AbonoId": a["AbonoId"],
                    "FechaAbono": a["FechaAbono"],
                    "FechaRegistro": a["FechaRegistro"],
                    "DiasDesdeAbonoAnterior": None,
                    "ValorAbono": a["ValorAbono"],
                    "ValorRetencion": a["ValorRetencion"],
                    "TotalAplicado": a["TotalAplicado"],
                    "SaldoDespuesDelAbono": 0.0,
                    "FormaPago": a["FormaPago"],
                    "Observacion": a["Observacion"],
                }
            )
        filas.append(
            {
                "Nro": "TOTAL",
                "NumeroFactura": numero_factura,
                "NombreCliente": coincidencias[0]["NombreCliente"],
                "AbonoId": None,
                "FechaAbono": None,
                "FechaRegistro": None,
                "DiasDesdeAbonoAnterior": None,
                "ValorAbono": sum(a["ValorAbono"] for a in coincidencias),
                "ValorRetencion": sum(a["ValorRetencion"] for a in coincidencias),
                "TotalAplicado": total_aplicado,
                "SaldoDespuesDelAbono": saldo_total,
                "FormaPago": None,
                "Observacion": f"Saldo actual de la factura (valor {valor_total:.2f})",
            }
        )
        return FakeResponse(200, filas)

    def _clientes_filtrados(self, params: dict) -> list[dict]:
        params = params or {}
        # sp_ConsultarClientes lee de la misma tabla dbo.Cliente que el CRUD
        # genérico; en el doble, unimos los 25 clientes fijos con los que
        # se hayan creado vía POST /api/clientes para reflejar eso.
        creados = [
            {
                "CodigoCliente": c["ClienteId"],
                "NombreCompleto": c.get("NombreCompleto", ""),
                "Identificacion": c.get("Identificacion") or None,
                "Direccion": c.get("Direccion") or None,
                "Ciudad": None,
                "Telefono": c.get("Telefono") or None,
                "SegmentoRiesgo": None,
                "Clasificacion": None,
                "PlazoPago": None,
                "LimiteCreditoPersonal": c.get("LimiteCreditoPersonal") or None,
                "LimiteCreditoVigente": c.get("LimiteCreditoPersonal") or None,
                "Estado": "ACTIVO" if c.get("Activo", True) else "INACTIVO",
                "FechaRegistro": "2026-08-20T00:00:00",
            }
            for c in self.clientes.values()
        ]
        rows = list(self.clientes_consultar) + creados
        if params.get("ClienteId"):
            rows = [r for r in rows if str(r["CodigoCliente"]) == str(params["ClienteId"])]
        if params.get("Nombre"):
            needle = params["Nombre"].upper()
            rows = [r for r in rows if needle in r["NombreCompleto"].upper()]
        if params.get("Identificacion"):
            rows = [r for r in rows if r["Identificacion"] == params["Identificacion"]]
        if params.get("CiudadId"):
            ciudad = {"1": "Quito", "2": "Guayaquil"}.get(str(params["CiudadId"]))
            rows = [r for r in rows if r["Ciudad"] == ciudad]
        if params.get("SegmentoRiesgoId"):
            segmento = {"1": "Riesgo bajo", "2": "Riesgo alto"}.get(str(params["SegmentoRiesgoId"]))
            rows = [r for r in rows if r["SegmentoRiesgo"] == segmento]
        if params.get("ClasificacionId"):
            clasificacion = {"1": "Cliente preferencial", "2": "Cliente regular"}.get(str(params["ClasificacionId"]))
            rows = [r for r in rows if r["Clasificacion"] == clasificacion]
        if params.get("PlazoPagoId"):
            plazo = {"1": "CONTADO", "2": "30 DÍAS"}.get(str(params["PlazoPagoId"]))
            rows = [r for r in rows if r["PlazoPago"] == plazo]
        return rows

    def _cartera_filtrada(self, params: dict) -> list[dict]:
        params = params or {}
        rows = list(self.cartera)
        if params.get("NumeroFactura"):
            rows = [r for r in rows if r["NumeroFactura"] == params["NumeroFactura"]]
        if params.get("FechaEmision"):
            rows = [r for r in rows if r["FechaEmision"] == params["FechaEmision"]]
        if params.get("VendedorId"):
            rows = [r for r in rows if str(r["CodigoVendedor"]) == str(params["VendedorId"])]
        if params.get("ClienteId"):
            rows = [r for r in rows if str(r["CodigoCliente"]) == str(params["ClienteId"])]
        if params.get("Dias"):
            rows = [r for r in rows if r["DiasDesdeEmision"] > int(params["Dias"])]
        return rows

    def _facturas_filtradas(self, params: dict) -> list[dict]:
        params = params or {}
        rows = list(self.facturas)
        if params.get("NumeroFactura"):
            rows = [r for r in rows if r["NumeroFactura"] == params["NumeroFactura"]]
        if params.get("FechaEmision"):
            rows = [r for r in rows if r["FechaEmision"] == params["FechaEmision"]]
        if params.get("VendedorId"):
            rows = [r for r in rows if str(r["CodigoVendedor"]) == str(params["VendedorId"])]
        if params.get("ClienteId"):
            rows = [r for r in rows if str(r["CodigoCliente"]) == str(params["ClienteId"])]
        if params.get("EstadoFacturaId"):
            rows = [r for r in rows if str(r["CodigoEstadoFactura"]) == str(params["EstadoFacturaId"])]
        if params.get("PlazoPagoId"):
            rows = [r for r in rows if str(r["CodigoPlazoPago"]) == str(params["PlazoPagoId"])]
        if params.get("FechaVencimiento"):
            rows = [r for r in rows if r["FechaVencimiento"] == params["FechaVencimiento"]]
        return rows

    def get(self, path, token=None, params=None, **_kwargs):
        if not self._check_token(token):
            return FakeResponse(401, {"error": "No autenticado"})
        if path == "/api/clientes":
            if params and params.get("activo"):
                # usado como catálogo para combos (facturas, formularios), no como la lista CRUD
                return FakeResponse(
                    200, [{"ClienteId": 1, "NombreCompleto": "Cliente Uno", "PlazoPagoId": 2, "Activo": True}]
                )
            return FakeResponse(200, list(self.clientes.values()))
        if path == "/api/vendedores":
            return FakeResponse(
                200,
                [
                    {"VendedorId": 1, "Nombres": "Vendedor Uno", "Activo": True},
                    {"VendedorId": 2, "Nombres": "Vendedor Dos", "Activo": True},
                ],
            )
        if path == "/api/facturas/consultar":
            return FakeResponse(200, self._facturas_filtradas(params))
        if path == "/api/abonos/consultar":
            return FakeResponse(200, self._abonos_filtrados(params))
        if path == "/api/abonos/detalle-factura":
            return self._detalle_abonos(params)
        if path == "/api/abonos/facturas-con-saldo":
            # Solo F-001 tiene saldo pendiente (60.0); F-002 está anulada y
            # F-003 quedó cancelada (ver _detalle_abonos), así que no deben
            # aparecer aquí aunque sí existan en /api/facturas/consultar.
            return FakeResponse(
                200,
                [
                    {
                        "FacturaId": 1,
                        "VendedorId": 1,
                        "NumeroFactura": "F-001",
                        "Vendedor": "Vendedor Uno",
                        "Cliente": "Cliente Uno",
                        "FechaEmision": "2026-08-01",
                        "ValorTotal": 100.0,
                        "TotalPagado": 40.0,
                        "SaldoPendiente": 60.0,
                        "FechaUltimoAbono": "2026-08-10",
                    }
                ],
            )
        if path == "/api/abonos/estado-cuenta":
            numero = (params or {}).get("NumeroFactura")
            if not numero:
                return FakeResponse(400, {"error": "Debe seleccionar una factura."})
            if numero == "F-001":
                return FakeResponse(
                    200,
                    {
                        "FacturaId": 1,
                        "NumeroFactura": "F-001",
                        "Vendedor": "Vendedor Uno",
                        "CodigoCliente": 1,
                        "NombreCliente": "Cliente Uno",
                        "FechaEmision": "2026-08-01",
                        "ValorTotal": 100.0,
                        "TotalAbonado": 40.0,
                        "TotalRetenciones": 0.0,
                        "NumAbonos": 1,
                        "FechaUltimoAbono": "2026-08-10",
                        "SaldoActual": 60.0,
                        "Estado": "ABONO PARCIAL",
                    },
                )
            return FakeResponse(400, {"error": f"No existe una factura con el número {numero}."})
        if path == "/api/formas-pago":
            return FakeResponse(
                200,
                [
                    {"id": 1, "label": "EFECTIVO"},
                    {"id": 2, "label": "TRANSFERENCIA"},
                ],
            )
        if path == "/api/clientes/consultar":
            return FakeResponse(200, self._clientes_filtrados(params))
        if path == "/api/clientes/historial-riesgo":
            cliente_id = int(params["ClienteId"])
            if cliente_id == 1:
                return FakeResponse(
                    200,
                    [
                        {
                            "HistorialId": 1,
                            "FechaActualizacion": "2026-08-01T10:00:00",
                            "SegmentoAnterior": "Riesgo medio",
                            "SegmentoNuevo": "Riesgo alto",
                            "ClasificacionAnterior": "Cliente regular",
                            "ClasificacionNueva": "Cliente regular",
                            "TipoCambio": "AUMENTO DE RIESGO",
                            "Motivo": "Actualización automática por modelo de scoring (score: 415.00)",
                            "UsuarioResponsable": "PROCESO AUTOMÁTICO",
                        }
                    ],
                )
            return FakeResponse(200, [])
        if path == "/api/clientes/riesgo-actual":
            cliente_id = int(params["ClienteId"])
            if cliente_id == 999999:
                return FakeResponse(404, {"error": "No existe el cliente."})
            return FakeResponse(
                200,
                {
                    "ClienteId": cliente_id,
                    "CodigoSegmento": "ALTO",
                    "SegmentoRiesgo": "Riesgo alto",
                    "SegmentoRiesgoDescripcion": "Mora recurrente; crédito reducido y garantía requerida.",
                    "RequiereGarantia": True,
                    "BloqueaVentas": False,
                    "Clasificacion": "Cliente regular",
                    "ClasificacionDescripcion": "Compra recurrente con volumen medio.",
                },
            )
        if path == "/api/ciudades":
            return FakeResponse(200, [{"id": 1, "label": "Quito"}, {"id": 2, "label": "Guayaquil"}])
        if path == "/api/segmentos-riesgo":
            return FakeResponse(
                200,
                [
                    {"id": 1, "label": "BAJO - Riesgo bajo"},
                    {"id": 2, "label": "MEDIO - Riesgo medio"},
                ],
            )
        if path == "/api/clasificaciones-cliente":
            return FakeResponse(
                200,
                [
                    {"id": 1, "label": "A - Cliente preferencial"},
                    {"id": 2, "label": "B - Cliente regular"},
                ],
            )
        if path == "/api/plazos-pago":
            return FakeResponse(
                200,
                [
                    {"id": 1, "label": "CONTADO", "dias": 0},
                    {"id": 2, "label": "15 DÍAS", "dias": 15},
                ],
            )
        if path == "/api/estados-factura":
            return FakeResponse(
                200,
                [
                    {"id": 1, "label": "PENDIENTE - Pendiente"},
                    {"id": 2, "label": "CANCELADA - Cancelada"},
                    {"id": 3, "label": "ANULADA - Anulada"},
                ],
            )
        if path == "/api/usuarios":
            return FakeResponse(
                200,
                [
                    {"id": 1, "label": "admin - Admin de Prueba"},
                    {"id": 2, "label": "vendedor - Vendedor de Prueba"},
                ],
            )
        if path == "/api/reportes/cartera-por-cobrar":
            return FakeResponse(200, self._cartera_filtrada(params))
        if path == "/api/calidad-datos/ultima-validacion":
            return FakeResponse(
                200,
                [
                    {
                        "Fecha": "2026-08-27T20:34:47",
                        "Dimension": "CONSISTENCIA",
                        "Codigo": "B1_ABONO_ANTERIOR",
                        "Descripcion": "Abonos con fecha anterior a la emisión de la factura",
                        "RegistrosAfectados": 11,
                        "ValorObservado": "11",
                        "UmbralEsperado": "0",
                        "Severidad": "CRITICO",
                    },
                ],
            )
        if path == "/api/calidad-datos/evolucion":
            return FakeResponse(
                200,
                [
                    {"Fecha": "2026-08-27", "Dimension": "CONSISTENCIA", "Criticos": 7},
                    {"Fecha": "2026-08-27", "Dimension": "INTEGRIDAD", "Criticos": 0},
                ],
            )
        if path == "/api/controles-esquema-deriva/diagnostico-drift":
            return FakeResponse(
                200,
                [
                    {
                        "MedicionId": 7,
                        "Fecha": "2026-08-30",
                        "VersionModelo": "2026-08-30",
                        "Variable": "CiudadId",
                        "PSI": 3.19,
                        "PctFueraDeRango": 0.0,
                        "Interpretacion": "DERIVA SIGNIFICATIVA",
                        "TramoDominante": "Guayaquil",
                        "PctPSI_TramoDominante": 62.5,
                        "Diagnostico": "CONCENTRADO EN UN TRAMO — revisar la representación de esa categoría antes de reentrenar",
                    },
                ],
            )
        if path == "/api/controles-esquema-deriva/diagnostico-drift/7/desglose":
            return FakeResponse(
                200,
                [
                    {
                        "Tramo": "Guayaquil",
                        "PctBase": 12.0,
                        "PctActual": 40.0,
                        "Variacion": 28.0,
                        "AportePSI": 1.99,
                        "PctDelPSI": 62.5,
                        "Origen": "CONOCIDO",
                    },
                ],
            )
        if path == "/api/controles-esquema-deriva/evolucion-drift":
            return FakeResponse(
                200,
                [
                    {
                        "Variable": "CiudadId",
                        "VersionModelo": "2026-08-30",
                        "Fecha": "2026-08-30",
                        "PSI": 3.19,
                        "PctFueraDeRango": 0.0,
                        "Interpretacion": "DERIVA SIGNIFICATIVA",
                        "Origen": "SQL",
                        "PSI_Anterior": None,
                        "Variacion": None,
                    },
                ],
            )
        if path == "/api/metricas-evaluacion/comparativo-alternativas":
            return FakeResponse(
                200,
                [
                    {
                        "VersionModelo": "20260909_182225",
                        "Alternativa": "REGRESION_LOGISTICA_WOE",
                        "ModeloServido": "SÍ",
                        "KS": 0.5385,
                        "AUC": 0.7607,
                        "Sensibilidad": 0.2222,
                        "Precision": 0.6667,
                        "F1": 0.3333,
                        "F2": 0.2564,
                        "IncumplimientosDetectados": "2 de 9",
                        "NumParticiones": None,
                        "DesviacionF1": None,
                        "Resultado": "ACEPTADO",
                    },
                    {
                        "VersionModelo": "20260909_182225",
                        "Alternativa": "XGBOOST",
                        "ModeloServido": "NO",
                        "KS": 0.5128,
                        "AUC": 0.7692,
                        "Sensibilidad": 0.3333,
                        "Precision": 0.7500,
                        "F1": 0.4615,
                        "F2": 0.3750,
                        "IncumplimientosDetectados": "3 de 9",
                        "NumParticiones": None,
                        "DesviacionF1": None,
                        "Resultado": "ACEPTADO",
                    },
                ],
            )
        if path == "/api/metricas-evaluacion/desempeno-produccion":
            return FakeResponse(
                200,
                {
                    "EventosEvaluables": 0,
                    "VerdaderosPositivos": None,
                    "FalsosPositivos": None,
                    "FalsosNegativos": None,
                    "VerdaderosNegativos": None,
                    "PrecisionObservada": None,
                    "SensibilidadObservada": None,
                },
            )
        if path == "/api/metricas-evaluacion/declarado-vs-observado":
            return FakeResponse(
                200,
                [
                    {
                        "VersionModelo": "20260909_182225",
                        "SensibilidadDeclarada": 0.2222,
                        "SensibilidadObservada": None,
                        "BrechaSensibilidad": None,
                        "PrecisionDeclarada": 0.6667,
                        "PrecisionObservada": None,
                        "EventosEvaluables": 0,
                        "Veredicto": "INSUFICIENTE — muy pocos desenlaces observados",
                    },
                ],
            )
        if path == "/api/seguridad/usuarios":
            return FakeResponse(200, list(self.usuarios_seguridad.values()))
        if path == "/api/seguridad/roles":
            return FakeResponse(200, self.roles_seguridad)
        if path.startswith("/api/seguridad/usuarios/"):
            usuario_id = int(path.rsplit("/", 1)[-1])
            usuario = self.usuarios_seguridad.get(usuario_id)
            if usuario is None:
                return FakeResponse(404, {"error": "No encontrado"})
            return FakeResponse(
                200,
                {
                    "UsuarioId": usuario["UsuarioId"],
                    "NombreUsuario": usuario["NombreUsuario"],
                    "Correo": usuario["Correo"],
                    "NombresCompletos": usuario["NombresCompletos"],
                    "VendedorId": usuario["VendedorId"],
                    "Activo": usuario["Activo"],
                    "DebeCambiarClave": usuario["DebeCambiarClave"],
                    "Roles": self.roles_por_usuario.get(usuario_id, []),
                },
            )
        if path == "/api/seguridad/matriz-permisos":
            return FakeResponse(
                200,
                {
                    "roles": self.roles_seguridad,
                    "permisos": self.permisos_seguridad,
                    "asignaciones": [{"RolId": r, "PermisoId": p} for r, p in self.asignaciones_seguridad],
                },
            )
        if path == "/api/seguridad/auditoria":
            return FakeResponse(200, self.auditoria_seguridad)
        if path == "/api/seguridad/bitacora-autorizacion":
            return FakeResponse(200, self.bitacora_autorizacion_lineas)
        if path.startswith("/api/clientes/"):
            row_id = int(path.rsplit("/", 1)[-1])
            row = self.clientes.get(row_id)
            return FakeResponse(200, row) if row else FakeResponse(404, {"error": "No encontrado"})
        if path.startswith("/api/abonos/"):
            row_id = int(path.rsplit("/", 1)[-1])
            row = self.abonos_crud.get(row_id)
            return FakeResponse(200, row) if row else FakeResponse(404, {"error": "No encontrado"})
        return FakeResponse(200, [])

    def post(self, path, token=None, json=None, client_ip=None, **_kwargs):
        if path == "/api/auth/login":
            if json.get("username") == TEST_USERNAME and json.get("password") == TEST_PASSWORD:
                return FakeResponse(
                    200,
                    {
                        "token": TEST_TOKEN,
                        "usuario": {
                            "id": 1,
                            "username": TEST_USERNAME,
                            "nombres_completos": "Usuario de Prueba",
                            "roles": ["ADMINISTRADOR"],
                            "permisos": [
                                "CLIENTES.CONSULTAR", "CLIENTES.CREAR", "CLIENTES.EDITAR", "CLIENTES.INACTIVAR",
                                "FACTURAS.CONSULTAR", "FACTURAS.CREAR", "FACTURAS.EDITAR", "FACTURAS.ANULAR",
                                "COBRANZA.CONSULTAR", "COBRANZA.REGISTRAR_ABONO", "COBRANZA.EDITAR_ABONO",
                                "COBRANZA.ELIMINAR_ABONO",
                                "REPORTES.CARTERA_VENCIDA",
                                # Migración a control por permiso (Migracion_Control_Por_Permiso.pdf):
                                # Vendedores/Scoring/Seguridad ya se autorizan por permiso, no por rol.
                                "VENDEDORES.CONSULTAR", "VENDEDORES.CREAR", "VENDEDORES.EDITAR", "VENDEDORES.INACTIVAR",
                                "SCORING.CONSULTAR", "SCORING.EJECUTAR", "SCORING.SIMULAR", "SCORING.MONITOREAR", "SCORING.CALIDAD",
                                "SEGURIDAD.USUARIOS", "SEGURIDAD.ROLES", "SEGURIDAD.AUDITORIA",
                            ],
                            "vendedor_id": None,
                            "debe_cambiar_clave": False,
                        },
                    },
                )
            return FakeResponse(401, {"mensaje": "Usuario o contraseña incorrectos."})

        if path == "/api/auth/logout":
            return FakeResponse(204)

        if not self._check_token(token):
            return FakeResponse(401, {"error": "No autenticado"})

        if path == "/api/clientes":
            if not (json or {}).get("NombreCompleto"):
                return FakeResponse(400, {"errores": {"NombreCompleto": "Nombre completo es obligatorio."}})
            row_id = self._next_id
            self._next_id += 1
            row = {"ClienteId": row_id, **json}
            self.clientes[row_id] = row
            return FakeResponse(201, {"ClienteId": row_id})

        if path == "/api/scoring-morosidad/ejecutar":
            comando = (json or {}).get("comando")
            if comando not in {"entrenar", "scorear-dry-run", "scorear", "monitorear"}:
                return FakeResponse(400, {"error": f"Comando de scoring desconocido: {comando!r}."})
            return FakeResponse(
                200,
                {
                    "comando": comando,
                    "exit_code": 0,
                    "salida": "",
                    "errores": f"INICIO {comando}\nFIN {comando}: 5 registros procesados.",
                    "duracion_segundos": 1.2,
                    "agotado": False,
                },
            )

        if path == "/api/calidad-datos/ejecucion-completa":
            return FakeResponse(
                200,
                {
                    "detalle": [
                        {
                            "Dimension": "CONSISTENCIA",
                            "Codigo": "B1_ABONO_ANTERIOR",
                            "Descripcion": "Abonos con fecha anterior a la emisión de la factura",
                            "RegistrosAfectados": 11,
                            "ValorObservado": "11",
                            "UmbralEsperado": "0",
                            "Severidad": "CRITICO",
                        },
                        {
                            "Dimension": "INTEGRIDAD",
                            "Codigo": "A1_ABONOS_HUERFANOS",
                            "Descripcion": "Abonos que referencian una factura inexistente",
                            "RegistrosAfectados": 0,
                            "ValorObservado": "0",
                            "UmbralEsperado": "0",
                            "Severidad": "OK",
                        },
                    ],
                    "veredicto": {
                        "EjecucionId": "11111111-1111-1111-1111-111111111111",
                        "Criticos": 1,
                        "Advertencias": 0,
                        "Conformes": 20,
                        "Veredicto": "NO APTO — corregir los hallazgos críticos antes de entrenar o scorear",
                    },
                },
            )
        if path == "/api/calidad-datos/solo-veredicto":
            return FakeResponse(
                200,
                {
                    "EjecucionId": "11111111-1111-1111-1111-111111111111",
                    "Criticos": 0,
                    "Advertencias": 1,
                    "Conformes": 20,
                    "Veredicto": "APTO CON OBSERVACIONES — documentar las advertencias en el informe de trazabilidad",
                },
            )

        if path == "/api/controles-esquema-deriva/validar-esquema":
            return FakeResponse(
                200,
                {
                    "detalle": [
                        {
                            "Objeto": "Cliente",
                            "Columna": "CiudadId",
                            "Hallazgo": "NULABILIDAD DISTINTA",
                            "TipoDatoEsperado": "int",
                            "TipoDatoActual": "int",
                            "Severidad": "ADVERTENCIA",
                        },
                    ],
                    "veredicto": {"Criticos": 0, "Advertencias": 1},
                },
            )
        if path == "/api/controles-esquema-deriva/medir-deriva":
            return FakeResponse(
                200,
                {
                    "variable": "CiudadId",
                    "sin_baseline": False,
                    "diagnostico": {
                        "MedicionId": 7,
                        "PSI": 3.19,
                        "PctFueraDeRango": 0.0,
                        "Diagnostico": "CONCENTRADO EN UN TRAMO — revisar la representación de esa categoría antes de reentrenar",
                    },
                },
            )

        if path == "/api/seguridad/usuarios":
            datos = json or {}
            if not datos.get("Correo") or not datos.get("NombresCompletos") or not datos.get("NombreUsuario"):
                return FakeResponse(400, {"errores": {"Correo": "El correo es obligatorio."}})
            if not datos.get("Clave") or len(datos.get("Clave", "")) < 8:
                return FakeResponse(400, {"errores": {"Clave": "La contraseña debe tener al menos 8 caracteres."}})
            if any(u["NombreUsuario"] == datos["NombreUsuario"] for u in self.usuarios_seguridad.values()):
                return FakeResponse(409, {"error": "El nombre de usuario ya está en uso."})
            nuevo_id = self._siguiente_usuario_id
            self._siguiente_usuario_id += 1
            roles_ids = [int(r) for r in datos.get("Roles", [])]
            self.usuarios_seguridad[nuevo_id] = {
                "UsuarioId": nuevo_id,
                "NombreUsuario": datos["NombreUsuario"],
                "Correo": datos["Correo"],
                "NombresCompletos": datos["NombresCompletos"],
                "VendedorId": datos.get("VendedorId"),
                "DebeCambiarClave": True,
                "Activo": bool(datos.get("Activo", True)),
                "UltimoAcceso": None,
                "FechaCreacion": "2026-09-12T00:00:00",
                "Roles": ", ".join(r["Nombre"] for r in self.roles_seguridad if r["RolId"] in roles_ids),
            }
            self.roles_por_usuario[nuevo_id] = roles_ids
            return FakeResponse(201, {"UsuarioId": nuevo_id})

        if path == "/api/seguridad/matriz-permisos":
            rol_id, permiso_id, asignar = json.get("rol_id"), json.get("permiso_id"), json.get("asignar")
            if permiso_id == 3 and rol_id != 1:
                # Módulo SEGURIDAD (SoloAdministrador): el disparador real lo rechaza igual.
                return FakeResponse(409, {"error": "Los permisos de un módulo restringido solo pueden asignarse al rol ADMINISTRADOR."})
            if asignar:
                self.asignaciones_seguridad.add((rol_id, permiso_id))
            else:
                self.asignaciones_seguridad.discard((rol_id, permiso_id))
            return FakeResponse(204)

        return FakeResponse(404, {"error": "No encontrado"})

    def put(self, path, token=None, json=None, client_ip=None):
        if not self._check_token(token):
            return FakeResponse(401, {"error": "No autenticado"})
        if path.startswith("/api/seguridad/usuarios/"):
            partes = path.split("/")
            usuario_id = int(partes[4])
            if usuario_id not in self.usuarios_seguridad:
                return FakeResponse(404, {"error": "No encontrado"})
            sufijo = partes[5] if len(partes) > 5 else None

            if sufijo == "estado":
                self.usuarios_seguridad[usuario_id]["Activo"] = bool(json.get("activo"))
                return FakeResponse(204)

            if sufijo == "clave":
                clave = (json or {}).get("Clave", "")
                if len(clave) < 8:
                    return FakeResponse(400, {"errores": {"Clave": "La contraseña debe tener al menos 8 caracteres."}})
                self.usuarios_seguridad[usuario_id]["DebeCambiarClave"] = True
                return FakeResponse(204)

            # editar datos + roles
            datos = json or {}
            if not datos.get("Correo") or not datos.get("NombresCompletos") or not datos.get("NombreUsuario"):
                return FakeResponse(400, {"errores": {"Correo": "El correo es obligatorio."}})
            roles_ids = [int(r) for r in datos.get("Roles", [])]
            self.usuarios_seguridad[usuario_id].update(
                {
                    "NombreUsuario": datos["NombreUsuario"],
                    "Correo": datos["Correo"],
                    "NombresCompletos": datos["NombresCompletos"],
                    "VendedorId": datos.get("VendedorId"),
                    "Activo": bool(datos.get("Activo", True)),
                    "Roles": ", ".join(r["Nombre"] for r in self.roles_seguridad if r["RolId"] in roles_ids),
                }
            )
            self.roles_por_usuario[usuario_id] = roles_ids
            return FakeResponse(204)
        row_id = int(path.rsplit("/", 1)[-1])
        if row_id not in self.clientes:
            return FakeResponse(404, {"error": "No encontrado"})
        self.clientes[row_id].update(json or {})
        return FakeResponse(204)

    def delete(self, path, token=None, client_ip=None):
        if not self._check_token(token):
            return FakeResponse(401, {"error": "No autenticado"})
        row_id = int(path.rsplit("/", 1)[-1])
        if row_id not in self.clientes:
            return FakeResponse(404, {"error": "No encontrado"})
        self.clientes[row_id]["Activo"] = False
        return FakeResponse(204)


@pytest.fixture
def backend(monkeypatch):
    fake = FakeBackend()
    monkeypatch.setattr(backend_client, "get", fake.get)
    monkeypatch.setattr(backend_client, "post", fake.post)
    monkeypatch.setattr(backend_client, "put", fake.put)
    monkeypatch.setattr(backend_client, "delete", fake.delete)
    return fake


@pytest.fixture
def client(backend):
    app = create_app(TestConfig)
    with app.test_client() as test_client:
        yield test_client
