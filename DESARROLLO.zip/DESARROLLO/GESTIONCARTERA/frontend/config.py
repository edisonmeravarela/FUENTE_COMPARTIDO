import os

from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key")
    BACKEND_API_URL = os.environ.get("BACKEND_API_URL", "http://127.0.0.1:5001")


class TestConfig(Config):
    TESTING = True
    WTF_CSRF_ENABLED = False
    # Los tests reemplazan las llamadas HTTP al backend (ver conftest.py),
    # así que este valor nunca se usa realmente.
    BACKEND_API_URL = "http://backend-de-pruebas.invalid"
