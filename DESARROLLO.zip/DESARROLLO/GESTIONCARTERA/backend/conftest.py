import sqlite3
from datetime import date, datetime
from decimal import Decimal
from types import SimpleNamespace

import pytest

from app import create_app
from config import TestConfig
from src.services import db as db_service
from src.utils.security import hash_password

ADMIN_USERNAME = "admin_prueba"
ADMIN_PASSWORD = "ClaveAdmin123!"
ADMIN_USUARIO_ID = 1
VENDEDOR_USERNAME = "vendedor_prueba"
VENDEDOR_PASSWORD = "ClaveVendedor123!"
VENDEDOR_USUARIO_ID = 2
SUPERVISOR_USERNAME = "supervisor_prueba"
SUPERVISOR_PASSWORD = "ClaveSupervisor123!"
SUPERVISOR_USUARIO_ID = 3

VENDEDOR_ID_1 = 1
VENDEDOR_ID_2 = 2
CIUDAD_ID = 1
FORMA_PAGO_ID = 1
TIPO_GASTO_ID = 1
SEGMENTO_RIESGO_ID = 1
CLASIFICACION_ID = 1
PLAZO_PAGO_ID = 1
ESTADO_FACTURA_PENDIENTE = 1
ESTADO_FACTURA_CANCELADA = 2
ESTADO_FACTURA_ANULADA = 3

_SEG_SCHEMA = """
CREATE TABLE seg.Usuario (
    UsuarioId INTEGER PRIMARY KEY AUTOINCREMENT,
    NombreUsuario TEXT UNIQUE NOT NULL,
    Correo TEXT,
    NombresCompletos TEXT,
    ClaveHash BLOB,
    ClaveSalt BLOB,
    VendedorId INTEGER,
    DebeCambiarClave INTEGER DEFAULT 0,
    IntentosFallidos INTEGER DEFAULT 0,
    BloqueadoHasta TIMESTAMP,
    UltimoAcceso TIMESTAMP,
    Activo INTEGER DEFAULT 1,
    FechaCreacion TIMESTAMP,
    CreadoPor INTEGER
);
CREATE TABLE seg.Rol (
    RolId INTEGER PRIMARY KEY AUTOINCREMENT,
    Nombre TEXT,
    Descripcion TEXT,
    Activo INTEGER DEFAULT 1
);
CREATE TABLE seg.UsuarioRol (
    UsuarioId INTEGER,
    RolId INTEGER,
    FechaAsignacion TIMESTAMP,
    AsignadoPor INTEGER,
    PRIMARY KEY (UsuarioId, RolId)
);
CREATE TABLE seg.Modulo (
    ModuloId INTEGER PRIMARY KEY AUTOINCREMENT,
    Nombre TEXT,
    Icono TEXT,
    Orden INTEGER,
    Activo INTEGER DEFAULT 1
);
CREATE TABLE seg.Permiso (
    PermisoId INTEGER PRIMARY KEY AUTOINCREMENT,
    ModuloId INTEGER,
    Codigo TEXT,
    Nombre TEXT,
    Descripcion TEXT,
    Activo INTEGER DEFAULT 1
);
CREATE TABLE seg.RolPermiso (
    RolId INTEGER,
    PermisoId INTEGER,
    PRIMARY KEY (RolId, PermisoId)
);
CREATE TABLE seg.Sesion (
    SesionId TEXT PRIMARY KEY,
    UsuarioId INTEGER,
    TokenRefresco TEXT,
    DireccionIP TEXT,
    AgenteUsuario TEXT,
    FechaInicio TIMESTAMP,
    FechaExpiracion TIMESTAMP,
    FechaCierre TIMESTAMP,
    Activa INTEGER DEFAULT 1
);
CREATE TABLE seg.IntentoAcceso (
    IntentoId INTEGER PRIMARY KEY AUTOINCREMENT,
    NombreUsuario TEXT,
    UsuarioId INTEGER,
    Exitoso INTEGER,
    Motivo TEXT,
    DireccionIP TEXT,
    Fecha TIMESTAMP
);
CREATE TABLE seg.Auditoria (
    AuditoriaId INTEGER PRIMARY KEY AUTOINCREMENT,
    UsuarioId INTEGER,
    Fecha TIMESTAMP,
    Accion TEXT,
    Entidad TEXT,
    EntidadId TEXT,
    ValoresAnteriores TEXT,
    ValoresNuevos TEXT,
    DireccionIP TEXT
);
"""

_DBO_SCHEMA = """
CREATE TABLE dbo.Vendedor (
    VendedorId INTEGER PRIMARY KEY AUTOINCREMENT,
    Nombres TEXT NOT NULL,
    Telefono TEXT,
    PorcComision REAL DEFAULT 0,
    Activo INTEGER DEFAULT 1
);
CREATE TABLE dbo.Ciudad (
    CiudadId INTEGER PRIMARY KEY AUTOINCREMENT,
    Nombre TEXT NOT NULL,
    Provincia TEXT
);
CREATE TABLE dbo.Cliente (
    ClienteId INTEGER PRIMARY KEY AUTOINCREMENT,
    NombreCompleto TEXT NOT NULL,
    Identificacion TEXT,
    Direccion TEXT,
    CiudadId INTEGER REFERENCES Ciudad(CiudadId),
    Telefono TEXT,
    SegmentoRiesgoId INTEGER REFERENCES SegmentoRiesgo(SegmentoRiesgoId),
    ClasificacionId INTEGER REFERENCES ClasificacionCliente(ClasificacionId),
    PlazoPagoId INTEGER REFERENCES PlazoPago(PlazoPagoId),
    LimiteCreditoPersonal REAL,
    Activo INTEGER DEFAULT 1,
    FechaRegistro TIMESTAMP
);
CREATE TABLE dbo.SegmentoRiesgo (
    SegmentoRiesgoId INTEGER PRIMARY KEY AUTOINCREMENT,
    Codigo TEXT NOT NULL,
    Nombre TEXT NOT NULL,
    Orden INTEGER,
    Activo INTEGER DEFAULT 1
);
CREATE TABLE dbo.ClasificacionCliente (
    ClasificacionId INTEGER PRIMARY KEY AUTOINCREMENT,
    Codigo TEXT NOT NULL,
    Nombre TEXT NOT NULL,
    Orden INTEGER,
    Activo INTEGER DEFAULT 1
);
CREATE TABLE dbo.PlazoPago (
    PlazoPagoId INTEGER PRIMARY KEY AUTOINCREMENT,
    Nombre TEXT NOT NULL,
    Dias INTEGER,
    Activo INTEGER DEFAULT 1
);
CREATE TABLE dbo.FormaPago (
    FormaPagoId INTEGER PRIMARY KEY AUTOINCREMENT,
    Descripcion TEXT NOT NULL
);
CREATE TABLE dbo.TipoGasto (
    TipoGastoId INTEGER PRIMARY KEY AUTOINCREMENT,
    Descripcion TEXT NOT NULL
);
CREATE TABLE dbo.EstadoFactura (
    EstadoFacturaId INTEGER PRIMARY KEY AUTOINCREMENT,
    Codigo TEXT NOT NULL,
    Nombre TEXT NOT NULL,
    Activo INTEGER DEFAULT 1
);
CREATE TABLE dbo.Factura (
    FacturaId INTEGER PRIMARY KEY AUTOINCREMENT,
    NumeroFactura TEXT NOT NULL,
    VendedorId INTEGER NOT NULL REFERENCES Vendedor(VendedorId),
    ClienteId INTEGER NOT NULL REFERENCES Cliente(ClienteId),
    FechaEmision DATE NOT NULL,
    PlazoPagoId INTEGER REFERENCES PlazoPago(PlazoPagoId),
    FechaVencimiento DATE,
    ValorTotal REAL NOT NULL,
    Observaciones TEXT,
    TotalAbonado REAL NOT NULL DEFAULT 0,
    SaldoPendiente REAL,
    EstadoFacturaId INTEGER NOT NULL REFERENCES EstadoFactura(EstadoFacturaId),
    FechaRegistro TIMESTAMP
);
CREATE TABLE dbo.Abono (
    AbonoId INTEGER PRIMARY KEY AUTOINCREMENT,
    FacturaId INTEGER NOT NULL REFERENCES Factura(FacturaId),
    FechaAbono DATE NOT NULL,
    ValorAbono REAL NOT NULL,
    ValorRetencion REAL DEFAULT 0,
    FormaPagoId INTEGER REFERENCES FormaPago(FormaPagoId),
    Observacion TEXT,
    UsuarioId INTEGER,
    FechaRegistro TIMESTAMP
);
CREATE TABLE dbo.GastoVendedor (
    GastoId INTEGER PRIMARY KEY AUTOINCREMENT,
    VendedorId INTEGER NOT NULL REFERENCES Vendedor(VendedorId),
    FechaGasto DATE NOT NULL,
    NumComprobante TEXT,
    TipoGastoId INTEGER REFERENCES TipoGasto(TipoGastoId),
    Detalle TEXT NOT NULL,
    Valor REAL NOT NULL
);
"""

_PERMISOS = [
    ("CLIENTES", ["CLIENTES.CONSULTAR", "CLIENTES.CREAR", "CLIENTES.EDITAR", "CLIENTES.INACTIVAR"]),
    ("FACTURACIÓN", ["FACTURAS.CONSULTAR", "FACTURAS.CREAR", "FACTURAS.EDITAR", "FACTURAS.ANULAR"]),
    ("COBRANZA", ["COBRANZA.CONSULTAR", "COBRANZA.REGISTRAR_ABONO", "COBRANZA.EDITAR_ABONO", "COBRANZA.ELIMINAR_ABONO"]),
    ("GASTOS", ["GASTOS.CONSULTAR", "GASTOS.REGISTRAR"]),
    ("REPORTES", ["REPORTES.CARTERA_VENCIDA"]),
    # Migración a control por permiso (Migracion_Control_Por_Permiso.pdf):
    # antes solo se autorizaban por rol, ahora tienen permiso propio.
    ("VENDEDORES", ["VENDEDORES.CONSULTAR", "VENDEDORES.CREAR", "VENDEDORES.EDITAR", "VENDEDORES.INACTIVAR"]),
    ("TIPOS_GASTO", ["TIPOS_GASTO.CONSULTAR", "TIPOS_GASTO.CREAR", "TIPOS_GASTO.EDITAR", "TIPOS_GASTO.ELIMINAR"]),
    ("SCORING", ["SCORING.CONSULTAR", "SCORING.EJECUTAR", "SCORING.SIMULAR", "SCORING.MONITOREAR", "SCORING.CALIDAD"]),
    ("SEGURIDAD", ["SEGURIDAD.USUARIOS", "SEGURIDAD.ROLES", "SEGURIDAD.AUDITORIA"]),
]

_PERMISOS_VENDEDOR = {
    "CLIENTES.CONSULTAR", "FACTURAS.CONSULTAR", "COBRANZA.CONSULTAR",
    "COBRANZA.REGISTRAR_ABONO", "GASTOS.CONSULTAR", "GASTOS.REGISTRAR",
    "VENDEDORES.CONSULTAR", "SCORING.CONSULTAR",
}

# Único cambio de alcance de la migración (apartado 3 del documento):
# Supervisor de cartera conserva todo lo de Vendedores/Tipos de
# gasto/Scoring salvo la ejecución real del pipeline (SCORING.EJECUTAR),
# reservada al Administrador.
_PERMISOS_SUPERVISOR = {
    "CLIENTES.CONSULTAR", "CLIENTES.CREAR", "CLIENTES.EDITAR", "CLIENTES.INACTIVAR",
    "FACTURAS.CONSULTAR", "FACTURAS.CREAR", "FACTURAS.EDITAR", "FACTURAS.ANULAR",
    "COBRANZA.CONSULTAR", "COBRANZA.REGISTRAR_ABONO", "COBRANZA.EDITAR_ABONO", "COBRANZA.ELIMINAR_ABONO",
    "GASTOS.CONSULTAR", "GASTOS.REGISTRAR", "REPORTES.CARTERA_VENCIDA",
    "VENDEDORES.CONSULTAR", "VENDEDORES.CREAR", "VENDEDORES.EDITAR", "VENDEDORES.INACTIVAR",
    "TIPOS_GASTO.CONSULTAR", "TIPOS_GASTO.CREAR", "TIPOS_GASTO.EDITAR", "TIPOS_GASTO.ELIMINAR",
    "SCORING.CONSULTAR", "SCORING.SIMULAR", "SCORING.MONITOREAR", "SCORING.CALIDAD",
}


def _adapt_datetime(value: datetime) -> str:
    return value.isoformat(" ")


def _adapt_date(value: date) -> str:
    return value.isoformat()


def _convert_timestamp(value: bytes) -> datetime:
    return datetime.fromisoformat(value.decode())


def _convert_date(value: bytes) -> date:
    return date.fromisoformat(value.decode())


sqlite3.register_adapter(datetime, _adapt_datetime)
sqlite3.register_adapter(date, _adapt_date)
sqlite3.register_adapter(Decimal, float)
sqlite3.register_converter("TIMESTAMP", _convert_timestamp)
sqlite3.register_converter("DATE", _convert_date)


def _row_factory(cursor, row):
    columns = [c[0] for c in cursor.description]
    return SimpleNamespace(**dict(zip(columns, row)))


def _build_test_db() -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:", detect_types=sqlite3.PARSE_DECLTYPES)
    conn.row_factory = _row_factory
    conn.execute("ATTACH DATABASE ':memory:' AS seg")
    conn.execute("ATTACH DATABASE ':memory:' AS dbo")
    conn.executescript(_DBO_SCHEMA)
    conn.executescript(_SEG_SCHEMA)
    conn.execute("PRAGMA foreign_keys = ON")

    # --- catálogos ---
    conn.execute("INSERT INTO dbo.Vendedor (VendedorId, Nombres, Activo) VALUES (?, 'Vendedor Uno', 1)", (VENDEDOR_ID_1,))
    conn.execute("INSERT INTO dbo.Vendedor (VendedorId, Nombres, Activo) VALUES (?, 'Vendedor Dos', 1)", (VENDEDOR_ID_2,))
    conn.execute("INSERT INTO dbo.Ciudad (CiudadId, Nombre) VALUES (?, 'Quito')", (CIUDAD_ID,))
    conn.execute("INSERT INTO dbo.FormaPago (FormaPagoId, Descripcion) VALUES (?, 'EFECTIVO')", (FORMA_PAGO_ID,))
    conn.execute("INSERT INTO dbo.TipoGasto (TipoGastoId, Descripcion) VALUES (?, 'VIATICOS')", (TIPO_GASTO_ID,))
    conn.execute(
        "INSERT INTO dbo.SegmentoRiesgo (SegmentoRiesgoId, Codigo, Nombre, Orden, Activo) VALUES (?, 'BAJO', 'Riesgo bajo', 1, 1)",
        (SEGMENTO_RIESGO_ID,),
    )
    conn.execute(
        "INSERT INTO dbo.ClasificacionCliente (ClasificacionId, Codigo, Nombre, Orden, Activo) VALUES (?, 'A', 'Cliente preferencial', 1, 1)",
        (CLASIFICACION_ID,),
    )
    conn.execute(
        "INSERT INTO dbo.PlazoPago (PlazoPagoId, Nombre, Dias, Activo) VALUES (?, 'CONTADO', 0, 1)",
        (PLAZO_PAGO_ID,),
    )
    conn.execute("INSERT INTO dbo.EstadoFactura (EstadoFacturaId, Codigo, Nombre, Activo) VALUES (1, 'PENDIENTE', 'Pendiente', 1)")
    conn.execute("INSERT INTO dbo.EstadoFactura (EstadoFacturaId, Codigo, Nombre, Activo) VALUES (2, 'CANCELADA', 'Cancelada', 1)")
    conn.execute("INSERT INTO dbo.EstadoFactura (EstadoFacturaId, Codigo, Nombre, Activo) VALUES (3, 'ANULADA', 'Anulada', 1)")

    # --- seguridad: roles, módulos, permisos ---
    conn.execute("INSERT INTO seg.Rol (RolId, Nombre, Activo) VALUES (1, 'ADMINISTRADOR', 1)")
    conn.execute("INSERT INTO seg.Rol (RolId, Nombre, Activo) VALUES (2, 'VENDEDOR/COBRADOR', 1)")
    conn.execute("INSERT INTO seg.Rol (RolId, Nombre, Activo) VALUES (3, 'SUPERVISOR DE CARTERA', 1)")

    permiso_id = 1
    codigo_a_id = {}
    for modulo_id, (nombre_modulo, codigos) in enumerate(_PERMISOS, start=1):
        conn.execute("INSERT INTO seg.Modulo (ModuloId, Nombre, Activo) VALUES (?, ?, 1)", (modulo_id, nombre_modulo))
        for codigo in codigos:
            conn.execute(
                "INSERT INTO seg.Permiso (PermisoId, ModuloId, Codigo, Nombre, Activo) VALUES (?, ?, ?, ?, 1)",
                (permiso_id, modulo_id, codigo, codigo),
            )
            codigo_a_id[codigo] = permiso_id
            conn.execute("INSERT INTO seg.RolPermiso (RolId, PermisoId) VALUES (1, ?)", (permiso_id,))
            if codigo in _PERMISOS_VENDEDOR:
                conn.execute("INSERT INTO seg.RolPermiso (RolId, PermisoId) VALUES (2, ?)", (permiso_id,))
            if codigo in _PERMISOS_SUPERVISOR:
                conn.execute("INSERT INTO seg.RolPermiso (RolId, PermisoId) VALUES (3, ?)", (permiso_id,))
            permiso_id += 1

    # --- usuarios de prueba ---
    admin_hash, admin_salt = hash_password(ADMIN_PASSWORD)
    conn.execute(
        "INSERT INTO seg.Usuario (UsuarioId, NombreUsuario, Correo, NombresCompletos, ClaveHash, ClaveSalt, "
        "VendedorId, DebeCambiarClave, IntentosFallidos, Activo, FechaCreacion) "
        "VALUES (1, ?, 'admin@test.com', 'Admin de Prueba', ?, ?, NULL, 0, 0, 1, ?)",
        (ADMIN_USERNAME, admin_hash, admin_salt, datetime.now()),
    )
    conn.execute("INSERT INTO seg.UsuarioRol (UsuarioId, RolId, FechaAsignacion) VALUES (1, 1, ?)", (datetime.now(),))

    vendedor_hash, vendedor_salt = hash_password(VENDEDOR_PASSWORD)
    conn.execute(
        "INSERT INTO seg.Usuario (UsuarioId, NombreUsuario, Correo, NombresCompletos, ClaveHash, ClaveSalt, "
        "VendedorId, DebeCambiarClave, IntentosFallidos, Activo, FechaCreacion) "
        "VALUES (2, ?, 'vendedor@test.com', 'Vendedor de Prueba', ?, ?, ?, 0, 0, 1, ?)",
        (VENDEDOR_USERNAME, vendedor_hash, vendedor_salt, VENDEDOR_ID_1, datetime.now()),
    )
    conn.execute("INSERT INTO seg.UsuarioRol (UsuarioId, RolId, FechaAsignacion) VALUES (2, 2, ?)", (datetime.now(),))

    supervisor_hash, supervisor_salt = hash_password(SUPERVISOR_PASSWORD)
    conn.execute(
        "INSERT INTO seg.Usuario (UsuarioId, NombreUsuario, Correo, NombresCompletos, ClaveHash, ClaveSalt, "
        "VendedorId, DebeCambiarClave, IntentosFallidos, Activo, FechaCreacion) "
        "VALUES (3, ?, 'supervisor@test.com', 'Supervisor de Prueba', ?, ?, NULL, 0, 0, 1, ?)",
        (SUPERVISOR_USERNAME, supervisor_hash, supervisor_salt, datetime.now()),
    )
    conn.execute("INSERT INTO seg.UsuarioRol (UsuarioId, RolId, FechaAsignacion) VALUES (3, 3, ?)", (datetime.now(),))

    conn.commit()
    return conn


@pytest.fixture
def db_conn():
    conn = _build_test_db()
    yield conn
    conn.close()


@pytest.fixture
def client(db_conn, monkeypatch):
    monkeypatch.setattr(db_service, "get_db", lambda: db_conn)
    monkeypatch.setattr(db_service, "close_db", lambda e=None: None)

    app = create_app(TestConfig)
    with app.test_client() as test_client:
        yield test_client


def login(client, username: str, password: str) -> str:
    response = client.post("/api/auth/login", json={"username": username, "password": password})
    assert response.status_code == 200, response.get_json()
    return response.get_json()["token"]


def auth_headers(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}
