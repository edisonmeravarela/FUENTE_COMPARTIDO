import os

from dotenv import load_dotenv

load_dotenv()


class Config:
    DB_SERVER = os.environ.get("DB_SERVER", "localhost")
    DB_NAME = os.environ.get("DB_NAME", "GestionCartera")
    DB_USER = os.environ.get("DB_USER", "sa")
    DB_PASSWORD = os.environ.get("DB_PASSWORD", "")
    DB_DRIVER = os.environ.get("DB_DRIVER", "ODBC Driver 17 for SQL Server")

    # Enmascaramiento dinámico de datos por rol (ddm_gestioncartera_definitivo.sql):
    # un login SQL Server propio por rol de seg.Rol, cada uno miembro de su
    # rol de base de datos (rol_admin/rol_supervisor/rol_cobrador/rol_consulta).
    # Se usan ÚNICAMENTE para las lecturas de dbo.Cliente que pasan por
    # dbo.sp_ConsultarClienteCrud (ver src/services/db.get_db_enmascarado());
    # el resto de la aplicación sigue con DB_USER/DB_PASSWORD de siempre.
    DB_USER_ADMIN = os.environ.get("DB_USER_ADMIN", "app_cartera_admin")
    DB_PASSWORD_ADMIN = os.environ.get("DB_PASSWORD_ADMIN", "")
    DB_USER_SUPERVISOR = os.environ.get("DB_USER_SUPERVISOR", "app_cartera_supervisor")
    DB_PASSWORD_SUPERVISOR = os.environ.get("DB_PASSWORD_SUPERVISOR", "")
    DB_USER_COBRADOR = os.environ.get("DB_USER_COBRADOR", "app_cartera_cobrador")
    DB_PASSWORD_COBRADOR = os.environ.get("DB_PASSWORD_COBRADOR", "")
    DB_USER_CONSULTA = os.environ.get("DB_USER_CONSULTA", "app_cartera_consulta")
    DB_PASSWORD_CONSULTA = os.environ.get("DB_PASSWORD_CONSULTA", "")

    # Repositorio independiente del modelo de scoring de morosidad (paso
    # 8.10 de su propia especificación): se invoca su main.py como
    # subproceso, con el intérprete de SU PROPIO entorno virtual (tiene
    # dependencias distintas — scikit-learn, xgboost — que este backend
    # no necesita ni debe instalar).
    SCORING_MOROSIDAD_PATH = os.environ.get(
        "SCORING_MOROSIDAD_PATH",
        r"C:\Users\ADMIN\Desktop\MAESTRIA EN IA APLICADA\PROYECTO MIA\TESIS\DESARROLLO\scoring-morosidad",
    )
    SCORING_MOROSIDAD_PYTHON = os.environ.get(
        "SCORING_MOROSIDAD_PYTHON",
        r"C:\Users\ADMIN\Desktop\MAESTRIA EN IA APLICADA\PROYECTO MIA\TESIS\DESARROLLO\scoring-morosidad\.venv\Scripts\python.exe",
    )


class TestConfig(Config):
    TESTING = True
    # Los tests usan una base SQLite en memoria (ver tests/conftest.py) en
    # vez del SQL Server real.
