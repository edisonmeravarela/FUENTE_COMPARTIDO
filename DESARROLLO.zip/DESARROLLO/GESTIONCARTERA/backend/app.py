from flask import Flask

from config import Config
from src.api.abonos_routes import abonos_bp
from src.api.auth_routes import auth_bp
from src.api.calidad_datos_routes import calidad_datos_bp
from src.api.clientes_routes import clientes_bp
from src.api.controles_esquema_deriva_routes import controles_esquema_deriva_bp
from src.api.crud_routes import make_crud_blueprint
from src.api.facturas_routes import facturas_bp
from src.api.lookup_routes import lookup_bp
from src.api.metricas_evaluacion_routes import metricas_evaluacion_bp
from src.api.reportes_routes import reportes_bp
from src.api.scoring_routes import scoring_bp
from src.api.seguridad_routes import seguridad_bp
from src.entities import ENTITIES
from src.services import db


def create_app(config_class: type = Config) -> Flask:
    app = Flask(__name__)
    app.config.from_object(config_class)
    db.init_app(app)

    app.register_blueprint(auth_bp)
    app.register_blueprint(lookup_bp)
    app.register_blueprint(reportes_bp)
    app.register_blueprint(scoring_bp)
    app.register_blueprint(calidad_datos_bp)
    app.register_blueprint(controles_esquema_deriva_bp)
    app.register_blueprint(metricas_evaluacion_bp)
    app.register_blueprint(seguridad_bp)
    app.register_blueprint(facturas_bp)
    app.register_blueprint(abonos_bp)
    app.register_blueprint(clientes_bp)
    for entity in ENTITIES.values():
        app.register_blueprint(make_crud_blueprint(entity))

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True, port=5001)
