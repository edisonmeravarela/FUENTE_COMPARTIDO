"""Asigna contraseñas reales a los usuarios semilla de seg.Usuario.

Uso: python scripts/seed_demo_passwords.py
"""

import secrets
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pyodbc

from config import Config
from src.utils.security import hash_password

USUARIOS = ["admin", "jibarra", "freddy"]


def build_conn_str() -> str:
    return (
        f"DRIVER={{{Config.DB_DRIVER}}};"
        f"SERVER={Config.DB_SERVER};"
        f"DATABASE={Config.DB_NAME};"
        f"UID={Config.DB_USER};"
        f"PWD={Config.DB_PASSWORD};"
        "TrustServerCertificate=yes;"
    )


def main() -> None:
    conn = pyodbc.connect(build_conn_str(), timeout=5)
    cur = conn.cursor()
    resultados = []

    for username in USUARIOS:
        cur.execute("SELECT UsuarioId FROM seg.Usuario WHERE NombreUsuario = ?", (username,))
        row = cur.fetchone()
        if row is None:
            print(f"  (omitido) {username}: no existe en seg.Usuario")
            continue

        password = secrets.token_urlsafe(12)
        hashed, salt = hash_password(password)
        cur.execute(
            "UPDATE seg.Usuario SET ClaveHash = ?, ClaveSalt = ?, IntentosFallidos = 0, "
            "BloqueadoHasta = NULL WHERE UsuarioId = ?",
            hashed, salt, row.UsuarioId,
        )
        resultados.append((username, password))

    conn.commit()
    conn.close()

    print("\nContraseñas generadas (guárdalas ahora, no se repiten):")
    for username, password in resultados:
        print(f"  {username}: {password}")


if __name__ == "__main__":
    main()
