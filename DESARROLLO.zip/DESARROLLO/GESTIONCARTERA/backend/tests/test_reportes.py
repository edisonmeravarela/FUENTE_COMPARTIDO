from unittest.mock import patch

from conftest import ADMIN_PASSWORD, ADMIN_USERNAME, VENDEDOR_PASSWORD, VENDEDOR_USERNAME, auth_headers, login

# sp_ConsultarFacturasVencidas es un procedimiento T-SQL real (EXEC ...), no
# portable al doble SQLite; aquí se prueba la ruta (permiso, parseo de
# filtros) simulando src.services.reportes_service.cartera_por_cobrar. La
# llamada real al procedimiento se verificó a mano contra el SQL Server.


def test_cartera_por_cobrar_requiere_permiso(client):
    token = login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD)
    response = client.get("/api/reportes/cartera-por-cobrar", headers=auth_headers(token))
    assert response.status_code == 403


def test_cartera_por_cobrar_requiere_sesion(client):
    response = client.get("/api/reportes/cartera-por-cobrar")
    assert response.status_code == 401


def test_cartera_por_cobrar_parsea_filtros_y_delega_al_servicio(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.reportes_routes.reportes_service.cartera_por_cobrar") as mock_consultar:
        mock_consultar.return_value = [{"FacturaId": 1, "NumeroFactura": "F-001"}]
        response = client.get(
            "/api/reportes/cartera-por-cobrar",
            query_string={
                "NumeroFactura": "F-001",
                "FechaEmision": "2026-08-01",
                "VendedorId": "1",
                "ClienteId": "5",
                "Dias": "30",
            },
            headers=auth_headers(token),
        )

    assert response.status_code == 200
    assert response.get_json() == [{"FacturaId": 1, "NumeroFactura": "F-001"}]

    _, kwargs = mock_consultar.call_args
    assert kwargs["numero_factura"] == "F-001"
    assert kwargs["fecha_emision"].isoformat() == "2026-08-01"
    assert kwargs["vendedor_id"] == 1
    assert kwargs["cliente_id"] == 5
    assert kwargs["dias"] == 30


def test_cartera_por_cobrar_sin_filtros_pasa_todo_none(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.reportes_routes.reportes_service.cartera_por_cobrar") as mock_consultar:
        mock_consultar.return_value = []
        client.get("/api/reportes/cartera-por-cobrar", headers=auth_headers(token))

    _, kwargs = mock_consultar.call_args
    assert kwargs == {
        "numero_factura": None,
        "fecha_emision": None,
        "vendedor_id": None,
        "cliente_id": None,
        "dias": None,
    }
