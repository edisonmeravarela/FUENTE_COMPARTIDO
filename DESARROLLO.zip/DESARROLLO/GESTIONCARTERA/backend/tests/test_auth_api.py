from conftest import ADMIN_PASSWORD, ADMIN_USERNAME, auth_headers, login


def test_login_success_returns_token_and_permisos(client):
    response = client.post("/api/auth/login", json={"username": ADMIN_USERNAME, "password": ADMIN_PASSWORD})
    assert response.status_code == 200
    body = response.get_json()
    assert body["token"]
    assert "CLIENTES.CONSULTAR" in body["usuario"]["permisos"]
    assert "ADMINISTRADOR" in body["usuario"]["roles"]


def test_login_invalid_credentials(client):
    response = client.post("/api/auth/login", json={"username": ADMIN_USERNAME, "password": "incorrecta"})
    assert response.status_code == 401
    assert "incorrectos" in response.get_json()["mensaje"]


def test_login_locks_after_repeated_failures(client):
    for _ in range(5):
        client.post("/api/auth/login", json={"username": ADMIN_USERNAME, "password": "mala"})
    response = client.post("/api/auth/login", json={"username": ADMIN_USERNAME, "password": "mala"})
    assert response.status_code == 401
    assert "bloqueada" in response.get_json()["mensaje"]


def test_protected_endpoint_requires_token(client):
    response = client.get("/api/clientes")
    assert response.status_code == 401


def test_logout_invalidates_token(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.get("/api/clientes", headers=auth_headers(token))
    assert response.status_code == 200

    logout_response = client.post("/api/auth/logout", headers=auth_headers(token))
    assert logout_response.status_code == 204

    response_after = client.get("/api/clientes", headers=auth_headers(token))
    assert response_after.status_code == 401
