from unittest.mock import patch

from conftest import ADMIN_PASSWORD, ADMIN_USERNAME, VENDEDOR_PASSWORD, VENDEDOR_USERNAME, auth_headers, login

# dbo.vw_ComparativoAlternativas/vw_DesempenoProduccion/vw_DeclaradoVsObservado
# son vistas T-SQL reales (JOIN, OUTER APPLY, agregados sin GROUP BY) no
# portables al doble SQLite; aquí se prueba la ruta (rol, delegación al
# servicio) simulando src.services.metricas_evaluacion_service. La
# consulta real se verificó a mano contra el SQL Server (ver manual
# técnico, sección 7.7).

RUTAS_PROTEGIDAS = [
    ("get", "/api/metricas-evaluacion/comparativo-alternativas"),
    ("get", "/api/metricas-evaluacion/desempeno-produccion"),
    ("get", "/api/metricas-evaluacion/declarado-vs-observado"),
]


def _llamar(client, metodo, ruta, headers=None):
    return getattr(client, metodo)(ruta, headers=headers or {})


def test_todas_las_rutas_requieren_sesion(client):
    for metodo, ruta in RUTAS_PROTEGIDAS:
        response = _llamar(client, metodo, ruta)
        assert response.status_code == 401, ruta


def test_todas_las_rutas_requieren_rol_autorizado(client):
    token = login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD)
    for metodo, ruta in RUTAS_PROTEGIDAS:
        response = _llamar(client, metodo, ruta, headers=auth_headers(token))
        assert response.status_code == 403, ruta


def test_comparativo_alternativas_devuelve_lista(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.metricas_evaluacion_routes.service.comparativo_alternativas") as mock_fn:
        mock_fn.return_value = [
            {"VersionModelo": "v1", "Alternativa": "REGRESION_LOGISTICA_WOE", "ModeloServido": "SI", "KS": 0.4, "AUC": 0.75, "Resultado": "ACEPTADO"},
        ]
        response = client.get("/api/metricas-evaluacion/comparativo-alternativas", headers=auth_headers(token))
    assert response.status_code == 200
    assert response.get_json()[0]["Resultado"] == "ACEPTADO"


def test_desempeno_produccion_devuelve_un_objeto(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.metricas_evaluacion_routes.service.desempeno_produccion") as mock_fn:
        mock_fn.return_value = {"EventosEvaluables": 0, "VerdaderosPositivos": None}
        response = client.get("/api/metricas-evaluacion/desempeno-produccion", headers=auth_headers(token))
    assert response.status_code == 200
    assert response.get_json()["EventosEvaluables"] == 0


def test_declarado_vs_observado_devuelve_lista(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.metricas_evaluacion_routes.service.declarado_vs_observado") as mock_fn:
        mock_fn.return_value = [{"VersionModelo": "v1", "Veredicto": "INSUFICIENTE — muy pocos desenlaces observados"}]
        response = client.get("/api/metricas-evaluacion/declarado-vs-observado", headers=auth_headers(token))
    assert response.status_code == 200
    assert "INSUFICIENTE" in response.get_json()[0]["Veredicto"]
