"""Verificación en vivo de seguridad_service.crear_usuario/editar_usuario/
actualizar_clave contra el SQL Server real: la ruta ya está cubierta con el
servicio simulado en test_seguridad_api.py (mismo criterio que el resto del
módulo — STRING_AGG y el trigger de protección no son portables al doble
SQLite), así que aquí se ejercita el SQL real: inserción/actualización de
seg.Usuario, la restricción UNIQUE de NombreUsuario/Correo/VendedorId, y el
INSERT/DELETE incremental de seg.UsuarioRol. Todo sobre usuarios descartables
(`TEST_SEG_...`) creados y eliminados dentro de cada prueba."""

import os
import uuid
from datetime import datetime

import pyodbc
import pytest
from dotenv import load_dotenv

from src.services import seguridad_service
from src.services.crud_service import ConflictError, ValidationError
from src.utils.security import verify_password

load_dotenv()

pytestmark = pytest.mark.skipif(
    not os.environ.get("DB_SERVER") or not os.environ.get("DB_PASSWORD"),
    reason="Requiere SQL Server real y credenciales en backend/.env.",
)


def _conectar() -> pyodbc.Connection:
    driver = os.environ.get("DB_DRIVER", "ODBC Driver 17 for SQL Server")
    conn_str = (
        f"DRIVER={{{driver}}};SERVER={os.environ['DB_SERVER']};DATABASE={os.environ['DB_NAME']};"
        f"UID={os.environ['DB_USER']};PWD={os.environ['DB_PASSWORD']};TrustServerCertificate=yes;"
    )
    return pyodbc.connect(conn_str, timeout=5)


def _limpiar(conn, usuario_id: int) -> None:
    cur = conn.cursor()
    for tabla in ("seg.UsuarioRol", "seg.Sesion", "seg.IntentoAcceso", "seg.Auditoria"):
        cur.execute(f"DELETE FROM {tabla} WHERE UsuarioId = ?", (usuario_id,))
    cur.execute("DELETE FROM seg.Usuario WHERE UsuarioId = ?", (usuario_id,))
    conn.commit()


@pytest.fixture
def conexion():
    conn = _conectar()
    yield conn
    conn.close()


@pytest.fixture
def rol_cobrador_id(conexion) -> int:
    cur = conexion.cursor()
    cur.execute("SELECT RolId FROM seg.Rol WHERE Nombre = 'VENDEDOR/COBRADOR'")
    return cur.fetchval()


@pytest.fixture
def rol_consulta_id(conexion) -> int:
    cur = conexion.cursor()
    cur.execute("SELECT RolId FROM seg.Rol WHERE Nombre = 'CONSULTA'")
    return cur.fetchval()


def _datos_usuario_prueba(sufijo: str) -> dict:
    return {
        "NombreUsuario": f"TEST_SEG_{sufijo}",
        "Correo": f"test_seg_{sufijo}@test.local",
        "NombresCompletos": "Usuario De Prueba Seguridad",
    }


def test_crear_usuario_contra_la_base_real(conexion, rol_cobrador_id):
    sufijo = uuid.uuid4().hex[:8]
    datos = _datos_usuario_prueba(sufijo)
    usuario_id = None
    try:
        usuario_id = seguridad_service.crear_usuario(conexion, datos, "ClaveInicial123", [rol_cobrador_id], usuario_id_creador=1)
        assert isinstance(usuario_id, int)

        fila = seguridad_service.obtener_usuario(conexion, usuario_id)
        assert fila["NombreUsuario"] == datos["NombreUsuario"]
        assert fila["Roles"] == [rol_cobrador_id]
        assert fila["DebeCambiarClave"] is True

        cur = conexion.cursor()
        cur.execute("SELECT ClaveHash, ClaveSalt FROM seg.Usuario WHERE UsuarioId = ?", (usuario_id,))
        row = cur.fetchone()
        assert verify_password("ClaveInicial123", row.ClaveHash, row.ClaveSalt)
    finally:
        if usuario_id is not None:
            _limpiar(conexion, usuario_id)


def test_crear_usuario_con_nombre_duplicado_lanza_conflicterror(conexion, rol_cobrador_id):
    sufijo = uuid.uuid4().hex[:8]
    datos = _datos_usuario_prueba(sufijo)
    usuario_id = seguridad_service.crear_usuario(conexion, datos, "ClaveInicial123", [rol_cobrador_id], usuario_id_creador=1)
    try:
        with pytest.raises(ConflictError):
            seguridad_service.crear_usuario(
                conexion, {**datos, "Correo": f"otro_{sufijo}@test.local"}, "OtraClave123", [], usuario_id_creador=1
            )
    finally:
        _limpiar(conexion, usuario_id)


def test_crear_usuario_sin_correo_lanza_validationerror(conexion):
    with pytest.raises(ValidationError):
        seguridad_service.crear_usuario(
            conexion, {"NombreUsuario": "sin_correo", "NombresCompletos": "X"}, "ClaveInicial123", [], usuario_id_creador=1
        )


def test_crear_usuario_con_clave_corta_lanza_validationerror(conexion):
    sufijo = uuid.uuid4().hex[:8]
    with pytest.raises(ValidationError):
        seguridad_service.crear_usuario(conexion, _datos_usuario_prueba(sufijo), "corta", [], usuario_id_creador=1)


def test_editar_usuario_actualiza_datos_y_diferencia_roles(conexion, rol_cobrador_id, rol_consulta_id):
    sufijo = uuid.uuid4().hex[:8]
    datos = _datos_usuario_prueba(sufijo)
    usuario_id = seguridad_service.crear_usuario(conexion, datos, "ClaveInicial123", [rol_cobrador_id], usuario_id_creador=1)
    try:
        ok = seguridad_service.editar_usuario(
            conexion,
            usuario_id,
            {**datos, "NombresCompletos": "Nombre Editado", "Activo": False},
            [rol_consulta_id],  # reemplaza rol_cobrador_id por rol_consulta_id
            usuario_id_editor=1,
        )
        assert ok is True

        fila = seguridad_service.obtener_usuario(conexion, usuario_id)
        assert fila["NombresCompletos"] == "Nombre Editado"
        assert fila["Activo"] is False
        assert fila["Roles"] == [rol_consulta_id]
    finally:
        _limpiar(conexion, usuario_id)


def test_editar_usuario_inexistente_devuelve_false(conexion):
    ok = seguridad_service.editar_usuario(conexion, 9_999_999, {"Correo": "x@x.com", "NombresCompletos": "X", "NombreUsuario": "x"}, [], 1)
    assert ok is False


def test_actualizar_clave_reinicia_bloqueo_y_exige_cambio(conexion, rol_cobrador_id):
    sufijo = uuid.uuid4().hex[:8]
    datos = _datos_usuario_prueba(sufijo)
    usuario_id = seguridad_service.crear_usuario(conexion, datos, "ClaveInicial123", [rol_cobrador_id], usuario_id_creador=1)
    try:
        cur = conexion.cursor()
        cur.execute("UPDATE seg.Usuario SET IntentosFallidos = 5, DebeCambiarClave = 0 WHERE UsuarioId = ?", (usuario_id,))
        conexion.commit()

        ok = seguridad_service.actualizar_clave(conexion, usuario_id, "ClaveNueva456", usuario_id_editor=1)
        assert ok is True

        cur.execute(
            "SELECT ClaveHash, ClaveSalt, IntentosFallidos, DebeCambiarClave, BloqueadoHasta FROM seg.Usuario WHERE UsuarioId = ?",
            (usuario_id,),
        )
        row = cur.fetchone()
        assert verify_password("ClaveNueva456", row.ClaveHash, row.ClaveSalt)
        assert row.IntentosFallidos == 0
        assert bool(row.DebeCambiarClave) is True
        assert row.BloqueadoHasta is None
    finally:
        _limpiar(conexion, usuario_id)


def test_actualizar_clave_usuario_inexistente_devuelve_false(conexion):
    ok = seguridad_service.actualizar_clave(conexion, 9_999_999, "ClaveNueva456", usuario_id_editor=1)
    assert ok is False
