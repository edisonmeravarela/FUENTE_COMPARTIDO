"""Regresión del bug detectado en vivo: dbo.Abono tiene el trigger
TR_Abono_ActualizarFactura, y SQL Server rechaza "INSERT ... OUTPUT
INSERTED.<pk> ..." sin cláusula INTO contra una tabla con triggers
habilitados (error 334). El doble SQLite no lo detecta (no tiene ese
trigger ni esa restricción), así que aquí se verifica con un cursor falso
que create_row nunca vuelva a generar un OUTPUT en la rama de SQL Server,
usando SCOPE_IDENTITY() en su lugar. Se verificó también a mano contra el
SQL Server real: antes del fix, POST /api/abonos devolvía 500; después,
201."""

from decimal import Decimal

from src.entities import ENTITIES
from src.services import crud_service


class _FakeCursor:
    def __init__(self, scope_identity_value):
        self.description = None
        self.executed: list[tuple[str, tuple]] = []
        self._scope_identity_value = scope_identity_value
        self._pending_result = None

    def execute(self, sql, params=()):
        self.executed.append((sql, tuple(params)))
        if "SCOPE_IDENTITY" in sql:
            self.description = [("id",)]
            self._pending_result = [(self._scope_identity_value,)]
        else:
            self.description = None
            self._pending_result = None

    def nextset(self):
        return False

    def fetchval(self):
        return self._pending_result[0][0] if self._pending_result else None


class _FakeSqlServerConnection:
    """No es sqlite3.Connection a propósito: crud_service._is_sqlite(db)
    debe devolver False para que create_row tome la rama de SQL Server."""

    def __init__(self, scope_identity_value=Decimal("42")):
        self._cursor = _FakeCursor(scope_identity_value)
        self.committed = False

    def cursor(self):
        return self._cursor

    def commit(self):
        self.committed = True

    def rollback(self):
        pass


def test_create_row_no_usa_output_para_sql_server():
    db = _FakeSqlServerConnection()
    entity = ENTITIES["vendedores"]

    new_id = crud_service.create_row(db, entity, {"Nombres": "Prueba"}, usuario_id=1, ip_address="127.0.0.1")

    insert_sql = db._cursor.executed[0][0]
    assert "OUTPUT" not in insert_sql.upper()
    assert "SCOPE_IDENTITY" in insert_sql
    assert new_id == 42
    assert isinstance(new_id, int)  # no Decimal, aunque SCOPE_IDENTITY() lo devuelva así
    assert db.committed is True


def test_create_row_funciona_contra_tabla_con_trigger_simulado():
    # dbo.Abono es justo el caso que reveló el bug: tiene un trigger AFTER
    # INSERT. El doble no simula el trigger en sí (SQLite no lo necesita
    # para reproducir el error, que es puramente sintáctico en T-SQL), pero
    # confirma que el INSERT generado para esta entidad es igual de "seguro"
    # (sin OUTPUT) que para cualquier otra.
    db = _FakeSqlServerConnection(scope_identity_value=Decimal("501"))
    entity = ENTITIES["abonos"]

    new_id = crud_service.create_row(
        db,
        entity,
        {"FacturaId": 10, "FechaAbono": "2026-08-21", "ValorAbono": "50"},
        usuario_id=1,
        ip_address="127.0.0.1",
    )

    insert_sql = db._cursor.executed[0][0]
    assert "OUTPUT" not in insert_sql.upper()
    assert new_id == 501
