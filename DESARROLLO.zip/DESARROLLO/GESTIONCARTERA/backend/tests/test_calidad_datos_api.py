from unittest.mock import patch

from conftest import ADMIN_PASSWORD, ADMIN_USERNAME, VENDEDOR_PASSWORD, VENDEDOR_USERNAME, auth_headers, login

# dbo.sp_ValidarCalidadDatos/dbo.vw_UltimaValidacion/dbo.ValidacionCalidadDatos
# son objetos T-SQL reales (EXEC con múltiples result sets, CAST, GROUP BY),
# no portables al doble SQLite; aquí se prueba la ruta (rol, delegación al
# servicio) simulando src.services.calidad_datos_service. La llamada real
# se verificó a mano contra el SQL Server (ver manual técnico, sección 7).

RUTAS_PROTEGIDAS = [
    ("post", "/api/calidad-datos/ejecucion-completa"),
    ("post", "/api/calidad-datos/solo-veredicto"),
    ("get", "/api/calidad-datos/ultima-validacion"),
    ("get", "/api/calidad-datos/evolucion"),
]


def _llamar(client, metodo, ruta, headers=None):
    return getattr(client, metodo)(ruta, headers=headers or {})


def test_todas_las_rutas_requieren_sesion(client):
    for metodo, ruta in RUTAS_PROTEGIDAS:
        response = _llamar(client, metodo, ruta)
        assert response.status_code == 401, ruta


def test_todas_las_rutas_requieren_rol_autorizado(client):
    token = login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD)
    for metodo, ruta in RUTAS_PROTEGIDAS:
        response = _llamar(client, metodo, ruta, headers=auth_headers(token))
        assert response.status_code == 403, ruta


def test_ejecucion_completa_devuelve_detalle_y_veredicto(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.calidad_datos_routes.calidad_datos_service.ejecucion_completa") as mock_fn:
        mock_fn.return_value = {
            "detalle": [{"Dimension": "INTEGRIDAD", "Codigo": "A1_ABONOS_HUERFANOS", "Severidad": "OK"}],
            "veredicto": {"Criticos": 0, "Advertencias": 0, "Conformes": 21, "Veredicto": "APTO"},
        }
        response = client.post("/api/calidad-datos/ejecucion-completa", headers=auth_headers(token))
    assert response.status_code == 200
    body = response.get_json()
    assert body["veredicto"]["Veredicto"] == "APTO"
    assert body["detalle"][0]["Codigo"] == "A1_ABONOS_HUERFANOS"


def test_solo_veredicto_devuelve_un_unico_objeto(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.calidad_datos_routes.calidad_datos_service.solo_veredicto") as mock_fn:
        mock_fn.return_value = {"Criticos": 1, "Advertencias": 1, "Conformes": 21, "Veredicto": "NO APTO"}
        response = client.post("/api/calidad-datos/solo-veredicto", headers=auth_headers(token))
    assert response.status_code == 200
    assert response.get_json()["Criticos"] == 1


def test_ultima_validacion_devuelve_lista(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.calidad_datos_routes.calidad_datos_service.ultima_validacion") as mock_fn:
        mock_fn.return_value = [{"Dimension": "CONSISTENCIA", "Severidad": "CRITICO"}]
        response = client.get("/api/calidad-datos/ultima-validacion", headers=auth_headers(token))
    assert response.status_code == 200
    assert response.get_json() == [{"Dimension": "CONSISTENCIA", "Severidad": "CRITICO"}]


def test_evolucion_devuelve_lista(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.calidad_datos_routes.calidad_datos_service.evolucion") as mock_fn:
        mock_fn.return_value = [{"Fecha": "2026-08-27", "Dimension": "CONSISTENCIA", "Criticos": 1}]
        response = client.get("/api/calidad-datos/evolucion", headers=auth_headers(token))
    assert response.status_code == 200
    assert response.get_json()[0]["Criticos"] == 1
