from conftest import ADMIN_PASSWORD, ADMIN_USERNAME, CIUDAD_ID, VENDEDOR_ID_1, auth_headers, login


def _crear_factura(client, headers, numero: str, valor_total: float) -> int:
    factura = client.post(
        "/api/facturas",
        headers=headers,
        json={
            "NumeroFactura": numero,
            "VendedorId": VENDEDOR_ID_1,
            "ClienteId": _crear_cliente(client, headers),
            "FechaEmision": "2026-08-21",
            "ValorTotal": str(valor_total),
        },
    ).get_json()
    return factura["FacturaId"]


def _crear_cliente(client, headers) -> int:
    cliente = client.post(
        "/api/clientes", headers=headers, json={"NombreCompleto": "Cliente Saldo", "CiudadId": CIUDAD_ID}
    ).get_json()
    return cliente["ClienteId"]


def test_abono_mayor_al_saldo_pendiente_se_rechaza(client, db_conn):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    factura_id = _crear_factura(client, headers, "F-SALDO-001", 100.0)
    # El doble SQLite no computa SaldoPendiente automáticamente (es una
    # columna calculada persistida en el SQL Server real); se fija a mano
    # para simular el valor que mantiene TR_Abono_ActualizarFactura.
    db_conn.execute("UPDATE dbo.Factura SET SaldoPendiente = 100.0 WHERE FacturaId = ?", (factura_id,))
    db_conn.commit()

    respuesta = client.post(
        "/api/abonos",
        headers=headers,
        json={"FacturaId": factura_id, "FechaAbono": "2026-08-21", "ValorAbono": "150"},
    )
    assert respuesta.status_code == 400
    assert "mayor al saldo pendiente" in respuesta.get_json()["errores"]["ValorAbono"]


def test_abono_igual_al_saldo_pendiente_se_acepta(client, db_conn):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    factura_id = _crear_factura(client, headers, "F-SALDO-002", 100.0)
    db_conn.execute("UPDATE dbo.Factura SET SaldoPendiente = 100.0 WHERE FacturaId = ?", (factura_id,))
    db_conn.commit()

    respuesta = client.post(
        "/api/abonos",
        headers=headers,
        json={"FacturaId": factura_id, "FechaAbono": "2026-08-21", "ValorAbono": "100"},
    )
    assert respuesta.status_code == 201


def test_abono_mas_retencion_supera_saldo_se_rechaza(client, db_conn):
    # Aunque ValorAbono por sí solo no exceda el saldo, ValorAbono +
    # ValorRetencion es lo que realmente descuenta TR_Abono_ActualizarFactura
    # (TotalAbonado = SUM(ValorAbono + ValorRetencion)).
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    factura_id = _crear_factura(client, headers, "F-SALDO-003", 100.0)
    db_conn.execute("UPDATE dbo.Factura SET SaldoPendiente = 100.0 WHERE FacturaId = ?", (factura_id,))
    db_conn.commit()

    respuesta = client.post(
        "/api/abonos",
        headers=headers,
        json={"FacturaId": factura_id, "FechaAbono": "2026-08-21", "ValorAbono": "90", "ValorRetencion": "20"},
    )
    assert respuesta.status_code == 400
    assert "mayor al saldo pendiente" in respuesta.get_json()["errores"]["ValorAbono"]


def test_saldo_pendiente_nulo_no_bloquea(client, db_conn):
    # Sin dato de saldo (columna aún no poblada) no se bloquea; la validación
    # de negocio no debe impedir el flujo cuando no hay con qué comparar.
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    factura_id = _crear_factura(client, headers, "F-SALDO-004", 100.0)

    respuesta = client.post(
        "/api/abonos",
        headers=headers,
        json={"FacturaId": factura_id, "FechaAbono": "2026-08-21", "ValorAbono": "500"},
    )
    assert respuesta.status_code == 201
