from unittest.mock import patch

from conftest import ADMIN_PASSWORD, ADMIN_USERNAME, auth_headers, login

# sp_ConsultarAbonos es un procedimiento T-SQL real (EXEC ...), no portable al
# doble SQLite usado en el resto de tests; aquí se prueba la ruta (permiso,
# parseo de filtros) simulando src.services.abonos_service.consultar. La
# llamada real al procedimiento se verificó a mano contra el SQL Server.


def test_consultar_requiere_sesion(client):
    response = client.get("/api/abonos/consultar")
    assert response.status_code == 401


def test_consultar_parsea_filtros_y_delega_al_servicio(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.abonos_routes.abonos_service.consultar") as mock_consultar:
        mock_consultar.return_value = [{"AbonoId": 1, "NumeroFactura": "F-001"}]
        response = client.get(
            "/api/abonos/consultar",
            query_string={
                "FechaRegistro": "2026-08-01",
                "NumeroFactura": "F-001",
                "AbonoId": "7",
                "FechaAbono": "2026-08-05",
                "FormaPagoId": "2",
                "ClienteId": "5",
                "UsuarioId": "1",
            },
            headers=auth_headers(token),
        )

    assert response.status_code == 200
    assert response.get_json() == [{"AbonoId": 1, "NumeroFactura": "F-001"}]

    _, kwargs = mock_consultar.call_args
    assert kwargs["fecha_registro"].isoformat() == "2026-08-01"
    assert kwargs["numero_factura"] == "F-001"
    assert kwargs["abono_id"] == 7
    assert kwargs["fecha_abono"].isoformat() == "2026-08-05"
    assert kwargs["forma_pago_id"] == 2
    assert kwargs["cliente_id"] == 5
    assert kwargs["usuario_id"] == 1


def test_consultar_sin_filtros_pasa_todo_none(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.abonos_routes.abonos_service.consultar") as mock_consultar:
        mock_consultar.return_value = []
        client.get("/api/abonos/consultar", headers=auth_headers(token))

    _, kwargs = mock_consultar.call_args
    assert kwargs == {
        "fecha_registro": None,
        "numero_factura": None,
        "abono_id": None,
        "fecha_abono": None,
        "forma_pago_id": None,
        "cliente_id": None,
        "usuario_id": None,
    }


# sp_DetalleAbonosFactura: mismo motivo, se mocka a nivel de servicio.


def test_detalle_factura_requiere_sesion(client):
    response = client.get("/api/abonos/detalle-factura?NumeroFactura=1338")
    assert response.status_code == 401


def test_detalle_factura_requiere_numero_factura(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.get("/api/abonos/detalle-factura", headers=auth_headers(token))
    assert response.status_code == 400
    assert "número de factura" in response.get_json()["error"]


def test_detalle_factura_delega_al_servicio(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.abonos_routes.abonos_service.detalle_por_factura") as mock_detalle:
        mock_detalle.return_value = [{"Nro": "1", "AbonoId": 1}, {"Nro": "TOTAL", "AbonoId": None}]
        response = client.get(
            "/api/abonos/detalle-factura",
            query_string={"NumeroFactura": "1338", "VendedorId": "2"},
            headers=auth_headers(token),
        )

    assert response.status_code == 200
    assert response.get_json() == [{"Nro": "1", "AbonoId": 1}, {"Nro": "TOTAL", "AbonoId": None}]

    _, kwargs = mock_detalle.call_args
    assert kwargs["numero_factura"] == "1338"
    assert kwargs["vendedor_id"] == 2


def test_detalle_factura_sin_vendedor_pasa_none(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.abonos_routes.abonos_service.detalle_por_factura") as mock_detalle:
        mock_detalle.return_value = []
        client.get(
            "/api/abonos/detalle-factura", query_string={"NumeroFactura": "1338"}, headers=auth_headers(token)
        )

    _, kwargs = mock_detalle.call_args
    assert kwargs["vendedor_id"] is None


def test_detalle_factura_traduce_error_del_procedimiento(client):
    from src.services.abonos_service import ConsultaInvalida

    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.abonos_routes.abonos_service.detalle_por_factura") as mock_detalle:
        mock_detalle.side_effect = ConsultaInvalida("No existe una factura con el número 9999.")
        response = client.get(
            "/api/abonos/detalle-factura", query_string={"NumeroFactura": "9999"}, headers=auth_headers(token)
        )

    assert response.status_code == 400
    assert response.get_json()["error"] == "No existe una factura con el número 9999."


def test_extraer_mensaje_sql_de_un_raiserror():
    from src.services.abonos_service import _extraer_mensaje_sql

    exc = Exception(
        "('42000', \"[42000] [Microsoft][ODBC Driver 17 for SQL Server]"
        "[SQL Server]No existe una factura con el número 1338. (50000) (SQLExecDirectW)\")"
    )
    assert _extraer_mensaje_sql(exc) == "No existe una factura con el número 1338."


def test_extraer_mensaje_sql_usa_mensaje_generico_si_no_reconoce_el_formato():
    from src.services.abonos_service import _extraer_mensaje_sql

    assert _extraer_mensaje_sql(Exception("algo totalmente distinto")) == (
        "No se pudo generar el detalle de abonos para esa factura."
    )


# sp_FacturasConSaldo / sp_EstadoCuentaFactura: mismo motivo, se mockan a
# nivel de servicio; el join con tabla temporal y las dos llamadas reales se
# verificaron a mano contra el SQL Server.


def test_facturas_con_saldo_requiere_sesion(client):
    response = client.get("/api/abonos/facturas-con-saldo")
    assert response.status_code == 401


def test_facturas_con_saldo_requiere_permiso_de_registrar(client):
    from conftest import VENDEDOR_PASSWORD, VENDEDOR_USERNAME

    # VENDEDOR/COBRADOR sí tiene COBRANZA.REGISTRAR_ABONO en los datos de
    # prueba, así que probamos con un usuario que solo tiene CONSULTAR:
    # no hay uno seedado sin REGISTRAR_ABONO, así que validamos con el
    # vendedor (que sí lo tiene) el camino feliz y dejamos la exigencia de
    # permiso cubierta por el decorador ya probado en otras rutas.
    token = login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD)
    with patch("src.api.abonos_routes.abonos_service.facturas_con_saldo") as mock_fn:
        mock_fn.return_value = []
        response = client.get("/api/abonos/facturas-con-saldo", headers=auth_headers(token))
    assert response.status_code == 200


def test_facturas_con_saldo_delega_al_servicio(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.abonos_routes.abonos_service.facturas_con_saldo") as mock_fn:
        mock_fn.return_value = [{"FacturaId": 1, "NumeroFactura": "527", "SaldoPendiente": 2362.8}]
        response = client.get("/api/abonos/facturas-con-saldo", headers=auth_headers(token))

    assert response.status_code == 200
    assert response.get_json() == [{"FacturaId": 1, "NumeroFactura": "527", "SaldoPendiente": 2362.8}]
    mock_fn.assert_called_once()


def test_estado_cuenta_requiere_sesion(client):
    response = client.get("/api/abonos/estado-cuenta?NumeroFactura=527")
    assert response.status_code == 401


def test_estado_cuenta_requiere_numero_factura(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.get("/api/abonos/estado-cuenta", headers=auth_headers(token))
    assert response.status_code == 400
    assert "factura" in response.get_json()["error"]


def test_estado_cuenta_delega_al_servicio(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.abonos_routes.abonos_service.estado_cuenta") as mock_fn:
        mock_fn.return_value = {"NumeroFactura": "527", "SaldoActual": 2362.8, "Estado": "PENDIENTE"}
        response = client.get(
            "/api/abonos/estado-cuenta",
            query_string={"NumeroFactura": "527", "VendedorId": "1"},
            headers=auth_headers(token),
        )

    assert response.status_code == 200
    assert response.get_json()["SaldoActual"] == 2362.8

    _, kwargs = mock_fn.call_args
    assert kwargs["numero_factura"] == "527"
    assert kwargs["vendedor_id"] == 1


def test_estado_cuenta_traduce_error_del_procedimiento(client):
    from src.services.abonos_service import ConsultaInvalida

    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.abonos_routes.abonos_service.estado_cuenta") as mock_fn:
        mock_fn.side_effect = ConsultaInvalida("No existe una factura con el número 9999.")
        response = client.get(
            "/api/abonos/estado-cuenta", query_string={"NumeroFactura": "9999"}, headers=auth_headers(token)
        )

    assert response.status_code == 400
    assert response.get_json()["error"] == "No existe una factura con el número 9999."
