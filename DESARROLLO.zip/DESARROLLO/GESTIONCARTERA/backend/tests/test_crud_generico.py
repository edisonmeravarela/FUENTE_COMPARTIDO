from conftest import (
    ADMIN_PASSWORD,
    ADMIN_USERNAME,
    CIUDAD_ID,
    CLASIFICACION_ID,
    ESTADO_FACTURA_ANULADA,
    ESTADO_FACTURA_PENDIENTE,
    PLAZO_PAGO_ID,
    SEGMENTO_RIESGO_ID,
    VENDEDOR_ID_1,
    auth_headers,
    login,
)


def test_factura_crud_con_plazo_pago_y_fecha_vencimiento(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    cliente = client.post(
        "/api/clientes", headers=headers, json={"NombreCompleto": "Cliente Con Plazo Factura", "CiudadId": CIUDAD_ID}
    ).get_json()

    factura = client.post(
        "/api/facturas",
        headers=headers,
        json={
            "NumeroFactura": "F-PLAZO-001",
            "VendedorId": VENDEDOR_ID_1,
            "ClienteId": cliente["ClienteId"],
            "FechaEmision": "2026-08-20",
            "PlazoPagoId": PLAZO_PAGO_ID,
            "FechaVencimiento": "2026-08-20",
            "ValorTotal": "150.50",
        },
    )
    assert factura.status_code == 201
    factura_id = factura.get_json()["FacturaId"]

    obtenida = client.get(f"/api/facturas/{factura_id}", headers=headers).get_json()
    assert obtenida["PlazoPagoId"] == PLAZO_PAGO_ID
    assert obtenida["FechaVencimiento"] == "2026-08-20"


def test_factura_create_sin_plazo_pago_ni_vencimiento(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    cliente = client.post(
        "/api/clientes", headers=headers, json={"NombreCompleto": "Cliente Sin Plazo Factura", "CiudadId": CIUDAD_ID}
    ).get_json()

    factura = client.post(
        "/api/facturas",
        headers=headers,
        json={
            "NumeroFactura": "F-PLAZO-002",
            "VendedorId": VENDEDOR_ID_1,
            "ClienteId": cliente["ClienteId"],
            "FechaEmision": "2026-08-20",
            "ValorTotal": "50",
        },
    )
    assert factura.status_code == 201
    factura_id = factura.get_json()["FacturaId"]

    obtenida = client.get(f"/api/facturas/{factura_id}", headers=headers).get_json()
    assert obtenida["PlazoPagoId"] is None
    assert obtenida["FechaVencimiento"] is None


def test_cliente_crud_full(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    create = client.post(
        "/api/clientes",
        headers=headers,
        json={"NombreCompleto": "Juan Perez", "CiudadId": CIUDAD_ID, "Telefono": "0999999999"},
    )
    assert create.status_code == 201
    cliente_id = create.get_json()["ClienteId"]

    listado = client.get("/api/clientes", headers=headers)
    assert listado.status_code == 200
    assert any(c["ClienteId"] == cliente_id for c in listado.get_json())

    editar = client.put(
        f"/api/clientes/{cliente_id}",
        headers=headers,
        json={"NombreCompleto": "Juan Perez Actualizado", "CiudadId": CIUDAD_ID, "Activo": True},
    )
    assert editar.status_code == 204

    obtenido = client.get(f"/api/clientes/{cliente_id}", headers=headers)
    assert obtenido.get_json()["NombreCompleto"] == "Juan Perez Actualizado"

    eliminar = client.delete(f"/api/clientes/{cliente_id}", headers=headers)
    assert eliminar.status_code == 204

    tras_eliminar = client.get(f"/api/clientes/{cliente_id}", headers=headers)
    assert tras_eliminar.get_json()["Activo"] is False

    solo_activos = client.get("/api/clientes?activo=1", headers=headers)
    assert all(c["ClienteId"] != cliente_id for c in solo_activos.get_json())


def test_cliente_crud_con_segmento_clasificacion_plazo_y_limite(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    create = client.post(
        "/api/clientes",
        headers=headers,
        json={
            "NombreCompleto": "Cliente Con Riesgo",
            "CiudadId": CIUDAD_ID,
            "SegmentoRiesgoId": SEGMENTO_RIESGO_ID,
            "ClasificacionId": CLASIFICACION_ID,
            "PlazoPagoId": PLAZO_PAGO_ID,
            "LimiteCreditoPersonal": "1500.75",
        },
    )
    assert create.status_code == 201
    cliente_id = create.get_json()["ClienteId"]

    obtenido = client.get(f"/api/clientes/{cliente_id}", headers=headers).get_json()
    assert obtenido["SegmentoRiesgoId"] == SEGMENTO_RIESGO_ID
    assert obtenido["ClasificacionId"] == CLASIFICACION_ID
    assert obtenido["PlazoPagoId"] == PLAZO_PAGO_ID
    assert obtenido["LimiteCreditoPersonal"] == 1500.75

    editar = client.put(
        f"/api/clientes/{cliente_id}",
        headers=headers,
        json={
            "NombreCompleto": "Cliente Con Riesgo",
            "LimiteCreditoPersonal": "2000",
        },
    )
    assert editar.status_code == 204

    tras_editar = client.get(f"/api/clientes/{cliente_id}", headers=headers).get_json()
    assert tras_editar["LimiteCreditoPersonal"] == 2000.0
    assert tras_editar["SegmentoRiesgoId"] is None  # no se reenvió, se limpia como el resto de campos opcionales


def test_cliente_create_sin_campos_opcionales_de_riesgo(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    create = client.post(
        "/api/clientes",
        headers=headers,
        json={"NombreCompleto": "Cliente Sin Riesgo"},
    )
    assert create.status_code == 201
    cliente_id = create.get_json()["ClienteId"]

    obtenido = client.get(f"/api/clientes/{cliente_id}", headers=headers).get_json()
    assert obtenido["SegmentoRiesgoId"] is None
    assert obtenido["ClasificacionId"] is None
    assert obtenido["PlazoPagoId"] is None
    assert obtenido["LimiteCreditoPersonal"] is None


def test_cliente_create_missing_required_field(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.post("/api/clientes", headers=auth_headers(token), json={"CiudadId": CIUDAD_ID})
    assert response.status_code == 400
    assert "NombreCompleto" in response.get_json()["errores"]


def test_cliente_create_requires_permission(client):
    from conftest import VENDEDOR_PASSWORD, VENDEDOR_USERNAME

    token = login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD)
    response = client.post(
        "/api/clientes", headers=auth_headers(token), json={"NombreCompleto": "Sin permiso"}
    )
    assert response.status_code == 403


def test_factura_create_and_anular(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    cliente = client.post(
        "/api/clientes", headers=headers, json={"NombreCompleto": "Cliente Factura", "CiudadId": CIUDAD_ID}
    ).get_json()

    factura = client.post(
        "/api/facturas",
        headers=headers,
        json={
            "NumeroFactura": "F-001",
            "VendedorId": VENDEDOR_ID_1,
            "ClienteId": cliente["ClienteId"],
            "FechaEmision": "2026-08-20",
            "ValorTotal": "150.50",
        },
    )
    assert factura.status_code == 201
    factura_id = factura.get_json()["FacturaId"]

    recien_creada = client.get(f"/api/facturas/{factura_id}", headers=headers).get_json()
    assert recien_creada["EstadoFacturaId"] == ESTADO_FACTURA_PENDIENTE  # 1 = PENDIENTE al crear

    anular = client.delete(f"/api/facturas/{factura_id}", headers=headers)
    assert anular.status_code == 204

    revisada = client.get(f"/api/facturas/{factura_id}", headers=headers)
    body = revisada.get_json()
    assert body["EstadoFacturaId"] == ESTADO_FACTURA_ANULADA
    assert body["FacturaId"] == factura_id  # la fila sigue existiendo, no se borró


def test_factura_con_abono_no_se_puede_eliminar(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    cliente = client.post(
        "/api/clientes", headers=headers, json={"NombreCompleto": "Cliente Con Abono", "CiudadId": CIUDAD_ID}
    ).get_json()
    factura = client.post(
        "/api/facturas",
        headers=headers,
        json={
            "NumeroFactura": "F-002",
            "VendedorId": VENDEDOR_ID_1,
            "ClienteId": cliente["ClienteId"],
            "FechaEmision": "2026-08-20",
            "ValorTotal": "300",
        },
    ).get_json()
    factura_id = factura["FacturaId"]

    abono = client.post(
        "/api/abonos",
        headers=headers,
        json={"FacturaId": factura_id, "FechaAbono": "2026-08-20", "ValorAbono": "100"},
    )
    assert abono.status_code == 201

    eliminar = client.delete(f"/api/facturas/{factura_id}", headers=headers)
    assert eliminar.status_code == 409
    assert "abonos registrados" in eliminar.get_json()["error"]

    revisada = client.get(f"/api/facturas/{factura_id}", headers=headers)
    assert revisada.get_json()["EstadoFacturaId"] == ESTADO_FACTURA_PENDIENTE  # no quedó anulada tras el bloqueo
