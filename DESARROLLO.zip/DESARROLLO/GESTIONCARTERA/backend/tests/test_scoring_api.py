import subprocess
from unittest.mock import patch

from conftest import ADMIN_PASSWORD, ADMIN_USERNAME, VENDEDOR_PASSWORD, VENDEDOR_USERNAME, auth_headers, login

# subprocess.run nunca se ejecuta de verdad en estas pruebas: se
# reemplaza (ver src.services.scoring_runner) para no depender del
# entorno virtual del proyecto scoring-morosidad ni de su duración real.
# La invocación real ya se verificó a mano (`python main.py scorear --dry-run`).


def test_ejecutar_requiere_sesion(client):
    response = client.post("/api/scoring-morosidad/ejecutar", json={"comando": "monitorear"})
    assert response.status_code == 401


def test_ejecutar_requiere_rol_autorizado(client):
    token = login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD)
    response = client.post(
        "/api/scoring-morosidad/ejecutar", json={"comando": "monitorear"}, headers=auth_headers(token)
    )
    assert response.status_code == 403


def test_ejecutar_rechaza_comando_desconocido(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.post(
        "/api/scoring-morosidad/ejecutar", json={"comando": "borrar_todo"}, headers=auth_headers(token)
    )
    assert response.status_code == 400


def test_ejecutar_rechaza_sin_comando(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.post("/api/scoring-morosidad/ejecutar", json={}, headers=auth_headers(token))
    assert response.status_code == 400


def test_ejecutar_scorear_dry_run_arma_el_argv_correcto(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.services.scoring_runner.subprocess.run") as mock_run:
        mock_run.return_value = subprocess.CompletedProcess(args=[], returncode=0, stdout="FIN scorear --dry-run: 169 registros procesados.\n", stderr="")
        response = client.post(
            "/api/scoring-morosidad/ejecutar", json={"comando": "scorear-dry-run"}, headers=auth_headers(token)
        )

    assert response.status_code == 200
    body = response.get_json()
    assert body["exit_code"] == 0
    assert "169 registros procesados" in body["salida"]

    argv = mock_run.call_args.args[0]
    assert argv[1:] == ["main.py", "scorear", "--dry-run"]


def test_ejecutar_entrenar_devuelve_error_del_proceso_hijo_sin_lanzar(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.services.scoring_runner.subprocess.run") as mock_run:
        mock_run.return_value = subprocess.CompletedProcess(
            args=[], returncode=1, stdout="", stderr="ModeloRechazadoError: KS de validación insuficiente."
        )
        response = client.post("/api/scoring-morosidad/ejecutar", json={"comando": "entrenar"}, headers=auth_headers(token))

    # Un fallo del script hijo es un resultado válido (200), no un 500:
    # el cliente HTTP debe poder mostrarlo, no tratarlo como bug del backend.
    assert response.status_code == 200
    body = response.get_json()
    assert body["exit_code"] == 1
    assert "ModeloRechazadoError" in body["errores"]


def test_ejecutar_maneja_timeout_sin_lanzar(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.services.scoring_runner.subprocess.run") as mock_run:
        mock_run.side_effect = subprocess.TimeoutExpired(cmd=["main.py"], timeout=600)
        response = client.post("/api/scoring-morosidad/ejecutar", json={"comando": "monitorear"}, headers=auth_headers(token))

    assert response.status_code == 200
    body = response.get_json()
    assert body["agotado"] is True
    assert body["exit_code"] is None


def test_comandos_disponibles_requiere_rol(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.get("/api/scoring-morosidad/comandos", headers=auth_headers(token))
    assert response.status_code == 200
    assert response.get_json() == ["entrenar", "monitorear", "scorear", "scorear-dry-run"]
