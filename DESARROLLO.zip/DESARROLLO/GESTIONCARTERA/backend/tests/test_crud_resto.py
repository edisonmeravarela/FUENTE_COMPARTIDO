from conftest import (
    ADMIN_PASSWORD,
    ADMIN_USERNAME,
    CIUDAD_ID,
    TIPO_GASTO_ID,
    VENDEDOR_ID_1,
    VENDEDOR_ID_2,
    VENDEDOR_PASSWORD,
    VENDEDOR_USERNAME,
    auth_headers,
    login,
)


def test_vendedor_crud_smoke(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    crear = client.post("/api/vendedores", headers=headers, json={"Nombres": "Vendedor Nuevo", "PorcComision": "3.5"})
    assert crear.status_code == 201
    vendedor_id = crear.get_json()["VendedorId"]

    editar = client.put(
        f"/api/vendedores/{vendedor_id}", headers=headers, json={"Nombres": "Vendedor Editado", "PorcComision": "4"}
    )
    assert editar.status_code == 204

    eliminar = client.delete(f"/api/vendedores/{vendedor_id}", headers=headers)
    assert eliminar.status_code == 204
    assert client.get(f"/api/vendedores/{vendedor_id}", headers=headers).get_json()["Activo"] is False


def test_vendedor_requires_admin_or_supervisor_role(client):
    token = login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD)
    response = client.post("/api/vendedores", headers=auth_headers(token), json={"Nombres": "No autorizado"})
    assert response.status_code == 403


def test_tipogasto_crud_smoke(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    crear = client.post("/api/tipos-gasto", headers=headers, json={"Descripcion": "COMBUSTIBLE"})
    assert crear.status_code == 201
    tipo_id = crear.get_json()["TipoGastoId"]

    eliminar = client.delete(f"/api/tipos-gasto/{tipo_id}", headers=headers)
    assert eliminar.status_code == 204
    assert client.get(f"/api/tipos-gasto/{tipo_id}", headers=headers).status_code == 404


def test_tipogasto_delete_conflict_when_referenced(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    client.post(
        "/api/gastos-vendedor",
        headers=headers,
        json={
            "VendedorId": VENDEDOR_ID_1,
            "FechaGasto": "2026-08-20",
            "TipoGastoId": TIPO_GASTO_ID,
            "Detalle": "Viáticos viaje",
            "Valor": "25.00",
        },
    )

    response = client.delete(f"/api/tipos-gasto/{TIPO_GASTO_ID}", headers=headers)
    assert response.status_code == 409


def test_abono_crud_smoke(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    cliente = client.post(
        "/api/clientes", headers=headers, json={"NombreCompleto": "Cliente Abono", "CiudadId": CIUDAD_ID}
    ).get_json()
    factura = client.post(
        "/api/facturas",
        headers=headers,
        json={
            "NumeroFactura": "F-100",
            "VendedorId": VENDEDOR_ID_1,
            "ClienteId": cliente["ClienteId"],
            "FechaEmision": "2026-08-20",
            "ValorTotal": "500",
        },
    ).get_json()

    crear = client.post(
        "/api/abonos",
        headers=headers,
        json={
            "FacturaId": factura["FacturaId"],
            "FechaAbono": "2026-08-20",
            "ValorAbono": "200",
        },
    )
    assert crear.status_code == 201
    abono_id = crear.get_json()["AbonoId"]

    eliminar = client.delete(f"/api/abonos/{abono_id}", headers=headers)
    assert eliminar.status_code == 204
    assert client.get(f"/api/abonos/{abono_id}", headers=headers).status_code == 404


def test_gastovendedor_crud_smoke(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)

    crear = client.post(
        "/api/gastos-vendedor",
        headers=headers,
        json={
            "VendedorId": VENDEDOR_ID_1,
            "FechaGasto": "2026-08-20",
            "TipoGastoId": TIPO_GASTO_ID,
            "Detalle": "Hospedaje",
            "Valor": "40.00",
        },
    )
    assert crear.status_code == 201


def test_vendedor_scope_filters_facturas(client):
    admin_headers = auth_headers(login(client, ADMIN_USERNAME, ADMIN_PASSWORD))
    cliente = client.post(
        "/api/clientes", headers=admin_headers, json={"NombreCompleto": "Cliente Alcance", "CiudadId": CIUDAD_ID}
    ).get_json()

    for numero, vendedor_id in [("F-200", VENDEDOR_ID_1), ("F-201", VENDEDOR_ID_2)]:
        client.post(
            "/api/facturas",
            headers=admin_headers,
            json={
                "NumeroFactura": numero,
                "VendedorId": vendedor_id,
                "ClienteId": cliente["ClienteId"],
                "FechaEmision": "2026-08-20",
                "ValorTotal": "100",
            },
        )

    vendedor_headers = auth_headers(login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD))
    listado = client.get("/api/facturas", headers=vendedor_headers).get_json()
    assert all(f["VendedorId"] == VENDEDOR_ID_1 for f in listado)
    assert len(listado) == 1
