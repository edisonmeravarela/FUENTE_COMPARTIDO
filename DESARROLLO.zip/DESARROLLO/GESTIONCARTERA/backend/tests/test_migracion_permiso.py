import subprocess
from unittest.mock import patch

from conftest import (
    ADMIN_PASSWORD,
    ADMIN_USERNAME,
    SUPERVISOR_PASSWORD,
    SUPERVISOR_USERNAME,
    VENDEDOR_PASSWORD,
    VENDEDOR_USERNAME,
    auth_headers,
    login,
)

# Migracion_Control_Por_Permiso.pdf: Vendedores, Tipos de gasto y Scoring
# pasan de autorizarse por rol a autorizarse por permiso, con el rol como
# respaldo de transición (require_permiso_o_rol). Estas pruebas verifican
# la "equivalencia de accesos" del paso 3 del documento — nadie que hoy
# tiene acceso lo pierde, salvo la única exclusión aprobada en el
# apartado 3: Supervisor de cartera ya no puede ejecutar el pipeline real
# de scoring (entrenar/scorear), solo consultarlo, simularlo o monitorearlo.


def test_supervisor_puede_administrar_vendedores_por_permiso(client):
    """Antes de esta migración, Supervisor pasaba por require_rol; ahora
    debe pasar por VENDEDORES.* — comprueba que el permiso, no el rol
    codificado, es lo que efectivamente concede el acceso."""
    headers = auth_headers(login(client, SUPERVISOR_USERNAME, SUPERVISOR_PASSWORD))
    crear = client.post("/api/vendedores", headers=headers, json={"Nombres": "Vendedor de Supervisor"})
    assert crear.status_code == 201


def test_supervisor_puede_administrar_tipos_gasto_por_permiso(client):
    headers = auth_headers(login(client, SUPERVISOR_USERNAME, SUPERVISOR_PASSWORD))
    crear = client.post("/api/tipos-gasto", headers=headers, json={"Descripcion": "PEAJES"})
    assert crear.status_code == 201


def test_vendedor_sigue_sin_poder_crear_vendedores(client):
    """VENDEDOR/COBRADOR solo tiene VENDEDORES.CONSULTAR (ni permiso de
    creación ni rol de respaldo): la migración no debe ampliarle acceso."""
    headers = auth_headers(login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD))
    response = client.post("/api/vendedores", headers=headers, json={"Nombres": "No autorizado"})
    assert response.status_code == 403


def test_supervisor_puede_consultar_comandos_de_scoring(client):
    headers = auth_headers(login(client, SUPERVISOR_USERNAME, SUPERVISOR_PASSWORD))
    response = client.get("/api/scoring-morosidad/comandos", headers=headers)
    assert response.status_code == 200


def test_supervisor_puede_simular_scoring(client):
    headers = auth_headers(login(client, SUPERVISOR_USERNAME, SUPERVISOR_PASSWORD))
    with patch("src.services.scoring_runner.subprocess.run") as mock_run:
        mock_run.return_value = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")
        response = client.post(
            "/api/scoring-morosidad/ejecutar", json={"comando": "scorear-dry-run"}, headers=headers
        )
    assert response.status_code == 200


def test_supervisor_puede_monitorear(client):
    headers = auth_headers(login(client, SUPERVISOR_USERNAME, SUPERVISOR_PASSWORD))
    with patch("src.services.scoring_runner.subprocess.run") as mock_run:
        mock_run.return_value = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")
        response = client.post("/api/scoring-morosidad/ejecutar", json={"comando": "monitorear"}, headers=headers)
    assert response.status_code == 200


def test_supervisor_no_puede_entrenar_ni_scorear_de_verdad(client):
    """La única decisión que altera el alcance (apartado 3 del documento):
    reservar la ejecución real del pipeline al Administrador."""
    headers = auth_headers(login(client, SUPERVISOR_USERNAME, SUPERVISOR_PASSWORD))
    for comando in ("entrenar", "scorear"):
        response = client.post("/api/scoring-morosidad/ejecutar", json={"comando": comando}, headers=headers)
        assert response.status_code == 403, comando


def test_administrador_si_puede_entrenar_y_scorear(client):
    headers = auth_headers(login(client, ADMIN_USERNAME, ADMIN_PASSWORD))
    with patch("src.services.scoring_runner.subprocess.run") as mock_run:
        mock_run.return_value = subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")
        for comando in ("entrenar", "scorear"):
            response = client.post("/api/scoring-morosidad/ejecutar", json={"comando": comando}, headers=headers)
            assert response.status_code == 200, comando


def test_supervisor_puede_ejecutar_la_compuerta_de_calidad(client):
    headers = auth_headers(login(client, SUPERVISOR_USERNAME, SUPERVISOR_PASSWORD))
    with patch("src.api.calidad_datos_routes.calidad_datos_service.solo_veredicto") as mock_fn:
        mock_fn.return_value = {"Criticos": 0, "Advertencias": 0, "Conformes": 21, "Veredicto": "APTO"}
        response = client.post("/api/calidad-datos/solo-veredicto", headers=headers)
    assert response.status_code == 200


def test_vendedor_no_puede_ejecutar_la_compuerta_de_calidad(client):
    headers = auth_headers(login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD))
    response = client.post("/api/calidad-datos/solo-veredicto", headers=headers)
    assert response.status_code == 403


def test_supervisor_puede_consultar_deriva_y_metricas_de_evaluacion(client):
    headers = auth_headers(login(client, SUPERVISOR_USERNAME, SUPERVISOR_PASSWORD))
    with patch("src.api.controles_esquema_deriva_routes.service.diagnostico_drift") as mock_fn:
        mock_fn.return_value = []
        response = client.get("/api/controles-esquema-deriva/diagnostico-drift", headers=headers)
    assert response.status_code == 200
    with patch("src.api.metricas_evaluacion_routes.service.comparativo_alternativas") as mock_fn:
        mock_fn.return_value = []
        response = client.get("/api/metricas-evaluacion/comparativo-alternativas", headers=headers)
    assert response.status_code == 200
