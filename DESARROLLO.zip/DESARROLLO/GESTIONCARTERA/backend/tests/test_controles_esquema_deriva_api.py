from unittest.mock import patch

from conftest import ADMIN_PASSWORD, ADMIN_USERNAME, VENDEDOR_PASSWORD, VENDEDOR_USERNAME, auth_headers, login

# dbo.sp_ValidarEsquema/dbo.sp_CalcularDriftCategorico/dbo.vw_DiagnosticoDrift/
# dbo.vw_EvolucionDrift son objetos T-SQL reales (EXEC con múltiples result
# sets, CAST, OUTER APPLY, funciones de ventana), no portables al doble
# SQLite; aquí se prueba la ruta (rol, delegación al servicio) simulando
# src.services.controles_esquema_deriva_service. La llamada real se
# verificó a mano contra el SQL Server (ver manual técnico, sección 7).

RUTAS_PROTEGIDAS = [
    ("post", "/api/controles-esquema-deriva/validar-esquema"),
    ("post", "/api/controles-esquema-deriva/medir-deriva"),
    ("get", "/api/controles-esquema-deriva/diagnostico-drift"),
    ("get", "/api/controles-esquema-deriva/diagnostico-drift/1/desglose"),
    ("get", "/api/controles-esquema-deriva/evolucion-drift"),
]


def _llamar(client, metodo, ruta, headers=None):
    return getattr(client, metodo)(ruta, headers=headers or {})


def test_todas_las_rutas_requieren_sesion(client):
    for metodo, ruta in RUTAS_PROTEGIDAS:
        response = _llamar(client, metodo, ruta)
        assert response.status_code == 401, ruta


def test_todas_las_rutas_requieren_rol_autorizado(client):
    token = login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD)
    for metodo, ruta in RUTAS_PROTEGIDAS:
        response = _llamar(client, metodo, ruta, headers=auth_headers(token))
        assert response.status_code == 403, ruta


def test_validar_esquema_devuelve_detalle_y_veredicto(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.controles_esquema_deriva_routes.service.validar_esquema") as mock_fn:
        mock_fn.return_value = {
            "detalle": [{"Objeto": "Cliente", "Columna": "ClienteId", "Severidad": "OK"}],
            "veredicto": {"Criticos": 0, "Advertencias": 0},
        }
        response = client.post("/api/controles-esquema-deriva/validar-esquema", headers=auth_headers(token))
    assert response.status_code == 200
    body = response.get_json()
    assert body["veredicto"]["Criticos"] == 0
    assert body["detalle"][0]["Objeto"] == "Cliente"


def test_medir_deriva_sin_baseline_lo_indica_explicitamente(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.controles_esquema_deriva_routes.service.medir_deriva_categorica") as mock_fn:
        mock_fn.return_value = {"variable": "CiudadId", "sin_baseline": True, "diagnostico": None}
        response = client.post("/api/controles-esquema-deriva/medir-deriva", headers=auth_headers(token))
    assert response.status_code == 200
    assert response.get_json()["sin_baseline"] is True


def test_medir_deriva_devuelve_el_diagnostico(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.controles_esquema_deriva_routes.service.medir_deriva_categorica") as mock_fn:
        mock_fn.return_value = {
            "variable": "CiudadId",
            "sin_baseline": False,
            "diagnostico": {"PSI": 3.19, "Diagnostico": "COBERTURA INSUFICIENTE"},
        }
        response = client.post("/api/controles-esquema-deriva/medir-deriva", headers=auth_headers(token))
    assert response.status_code == 200
    assert response.get_json()["diagnostico"]["PSI"] == 3.19


def test_diagnostico_drift_devuelve_lista(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.controles_esquema_deriva_routes.service.diagnostico_drift") as mock_fn:
        mock_fn.return_value = [{"MedicionId": 1, "Variable": "CiudadId", "PSI": 3.19}]
        response = client.get("/api/controles-esquema-deriva/diagnostico-drift", headers=auth_headers(token))
    assert response.status_code == 200
    assert response.get_json()[0]["Variable"] == "CiudadId"


def test_desglose_por_medicion_devuelve_lista(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.controles_esquema_deriva_routes.service.desglose_por_medicion") as mock_fn:
        mock_fn.return_value = [{"Tramo": "Bogotá", "PctBase": 12.0, "PctActual": 40.0}]
        response = client.get(
            "/api/controles-esquema-deriva/diagnostico-drift/1/desglose", headers=auth_headers(token)
        )
    assert response.status_code == 200
    mock_fn.assert_called_once()
    assert mock_fn.call_args.args[1] == 1
    assert response.get_json()[0]["Tramo"] == "Bogotá"


def test_evolucion_drift_devuelve_lista(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.controles_esquema_deriva_routes.service.evolucion_drift") as mock_fn:
        mock_fn.return_value = [{"Variable": "CiudadId", "Fecha": "2026-08-30", "PSI": 3.19}]
        response = client.get("/api/controles-esquema-deriva/evolucion-drift", headers=auth_headers(token))
    assert response.status_code == 200
    assert response.get_json()[0]["PSI"] == 3.19
