from unittest.mock import patch

from conftest import ADMIN_PASSWORD, ADMIN_USERNAME, VENDEDOR_PASSWORD, VENDEDOR_USERNAME, auth_headers, login

# sp_ConsultarClientes es un procedimiento T-SQL real (EXEC ...), no portable
# al doble SQLite usado en el resto de tests; aquí se prueba la ruta (permiso,
# parseo de filtros) simulando src.services.clientes_service.consultar. La
# llamada real al procedimiento se verificó a mano contra el SQL Server.


def test_consultar_requiere_sesion(client):
    response = client.get("/api/clientes/consultar")
    assert response.status_code == 401


def test_consultar_requiere_permiso(client):
    # VENDEDOR/COBRADOR sí tiene CLIENTES.CONSULTAR en los datos de prueba;
    # el 403 por falta de permiso ya está cubierto por otras rutas que
    # comparten el mismo decorador require_permiso.
    token = login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD)
    with patch("src.api.clientes_routes.clientes_service.consultar") as mock_fn:
        mock_fn.return_value = []
        response = client.get("/api/clientes/consultar", headers=auth_headers(token))
    assert response.status_code == 200


def test_consultar_parsea_filtros_y_delega_al_servicio(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.clientes_routes.clientes_service.consultar") as mock_consultar:
        mock_consultar.return_value = [{"CodigoCliente": 1, "NombreCompleto": "Juan Perez"}]
        response = client.get(
            "/api/clientes/consultar",
            query_string={
                "ClienteId": "1",
                "Nombre": "Juan",
                "Identificacion": "0102030405",
                "CiudadId": "3",
                "SegmentoRiesgoId": "2",
                "ClasificacionId": "1",
                "PlazoPagoId": "3",
            },
            headers=auth_headers(token),
        )

    assert response.status_code == 200
    assert response.get_json() == [{"CodigoCliente": 1, "NombreCompleto": "Juan Perez"}]

    _, kwargs = mock_consultar.call_args
    assert kwargs["cliente_id"] == 1
    assert kwargs["nombre"] == "Juan"
    assert kwargs["identificacion"] == "0102030405"
    assert kwargs["ciudad_id"] == 3
    assert kwargs["segmento_riesgo_id"] == 2
    assert kwargs["clasificacion_id"] == 1
    assert kwargs["plazo_pago_id"] == 3


def test_consultar_sin_filtros_pasa_todo_none(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.clientes_routes.clientes_service.consultar") as mock_consultar:
        mock_consultar.return_value = []
        client.get("/api/clientes/consultar", headers=auth_headers(token))

    _, kwargs = mock_consultar.call_args
    assert kwargs == {
        "cliente_id": None,
        "nombre": None,
        "identificacion": None,
        "ciudad_id": None,
        "segmento_riesgo_id": None,
        "clasificacion_id": None,
        "plazo_pago_id": None,
    }


def test_historial_riesgo_requiere_sesion(client):
    response = client.get("/api/clientes/historial-riesgo", query_string={"ClienteId": "1"})
    assert response.status_code == 401


def test_historial_riesgo_requiere_cliente_id(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.get("/api/clientes/historial-riesgo", headers=auth_headers(token))
    assert response.status_code == 400


def test_historial_riesgo_delega_al_servicio_con_el_cliente_id(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.clientes_routes.clientes_service.historial_riesgo") as mock_fn:
        mock_fn.return_value = [{"HistorialId": 1, "TipoCambio": "AUMENTO DE RIESGO"}]
        response = client.get(
            "/api/clientes/historial-riesgo", query_string={"ClienteId": "5"}, headers=auth_headers(token)
        )

    assert response.status_code == 200
    assert response.get_json() == [{"HistorialId": 1, "TipoCambio": "AUMENTO DE RIESGO"}]
    args, _ = mock_fn.call_args
    assert args[1] == 5


def test_riesgo_actual_requiere_sesion(client):
    response = client.get("/api/clientes/riesgo-actual", query_string={"ClienteId": "1"})
    assert response.status_code == 401


def test_riesgo_actual_requiere_cliente_id(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.get("/api/clientes/riesgo-actual", headers=auth_headers(token))
    assert response.status_code == 400


def test_riesgo_actual_devuelve_404_si_no_existe_el_cliente(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.clientes_routes.clientes_service.riesgo_actual") as mock_fn:
        mock_fn.return_value = None
        response = client.get(
            "/api/clientes/riesgo-actual", query_string={"ClienteId": "999999"}, headers=auth_headers(token)
        )
    assert response.status_code == 404


def test_riesgo_actual_delega_al_servicio_con_el_cliente_id(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.clientes_routes.clientes_service.riesgo_actual") as mock_fn:
        mock_fn.return_value = {
            "CodigoSegmento": "ALTO",
            "SegmentoRiesgo": "Riesgo alto",
            "SegmentoRiesgoDescripcion": "Mora recurrente; crédito reducido y garantía requerida.",
            "Clasificacion": "Cliente regular",
            "ClasificacionDescripcion": "Compra recurrente con volumen medio.",
        }
        response = client.get(
            "/api/clientes/riesgo-actual", query_string={"ClienteId": "5"}, headers=auth_headers(token)
        )
    assert response.status_code == 200
    assert response.get_json()["SegmentoRiesgoDescripcion"] == "Mora recurrente; crédito reducido y garantía requerida."
    args, _ = mock_fn.call_args
    assert args[1] == 5
