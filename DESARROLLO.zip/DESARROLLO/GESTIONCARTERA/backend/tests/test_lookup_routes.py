from unittest.mock import patch

from conftest import ADMIN_PASSWORD, ADMIN_USERNAME, PLAZO_PAGO_ID, auth_headers, login

# segmentos-riesgo/clasificaciones-cliente usan concatenación T-SQL
# (Codigo + ' - ' + Nombre) para armar la etiqueta, no portable al doble
# SQLite; aquí se prueba la ruta (sesión, delegación a lookup_rows con los
# argumentos correctos) simulando crud_service.lookup_rows. La consulta real
# se verificó a mano contra el SQL Server.


def test_segmentos_riesgo_requiere_sesion(client):
    response = client.get("/api/segmentos-riesgo")
    assert response.status_code == 401


def test_clasificaciones_cliente_requiere_sesion(client):
    response = client.get("/api/clasificaciones-cliente")
    assert response.status_code == 401


def test_plazos_pago_requiere_sesion(client):
    response = client.get("/api/plazos-pago")
    assert response.status_code == 401


def test_estados_factura_requiere_sesion(client):
    response = client.get("/api/estados-factura")
    assert response.status_code == 401


def test_usuarios_requiere_sesion(client):
    response = client.get("/api/usuarios")
    assert response.status_code == 401


def test_segmentos_riesgo_delega_con_orden_y_solo_activos(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.lookup_routes.crud_service.lookup_rows") as mock_fn:
        mock_fn.return_value = [{"id": 1, "label": "BAJO - Riesgo bajo"}]
        response = client.get("/api/segmentos-riesgo", headers=auth_headers(token))

    assert response.status_code == 200
    assert response.get_json() == [{"id": 1, "label": "BAJO - Riesgo bajo"}]

    args, kwargs = mock_fn.call_args
    assert args[1] == "dbo.SegmentoRiesgo"
    assert args[2] == "SegmentoRiesgoId"
    assert kwargs["order_by"] == "Orden"
    assert kwargs["solo_activos"] is True


def test_clasificaciones_cliente_delega_con_orden_y_solo_activos(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.lookup_routes.crud_service.lookup_rows") as mock_fn:
        mock_fn.return_value = [{"id": 1, "label": "A - Cliente preferencial"}]
        response = client.get("/api/clasificaciones-cliente", headers=auth_headers(token))

    assert response.status_code == 200
    assert response.get_json() == [{"id": 1, "label": "A - Cliente preferencial"}]

    args, kwargs = mock_fn.call_args
    assert args[1] == "dbo.ClasificacionCliente"
    assert args[2] == "ClasificacionId"
    assert kwargs["order_by"] == "Orden"
    assert kwargs["solo_activos"] is True


def test_plazos_pago_delega_con_dias_y_solo_activos(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.lookup_routes.crud_service.lookup_rows") as mock_fn:
        mock_fn.return_value = [{"id": 1, "label": "CONTADO"}]
        response = client.get("/api/plazos-pago", headers=auth_headers(token))

    assert response.status_code == 200
    assert response.get_json() == [{"id": 1, "label": "CONTADO"}]

    args, kwargs = mock_fn.call_args
    assert args[1] == "dbo.PlazoPago"
    assert args[2] == "PlazoPagoId"
    assert kwargs["order_by"] == "Dias"
    assert kwargs["solo_activos"] is True
    assert kwargs["extra_column"] == "Dias"
    assert kwargs["extra_alias"] == "dias"


def test_estados_factura_delega_con_orden_y_solo_activos(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.lookup_routes.crud_service.lookup_rows") as mock_fn:
        mock_fn.return_value = [{"id": 1, "label": "PENDIENTE - Pendiente"}]
        response = client.get("/api/estados-factura", headers=auth_headers(token))

    assert response.status_code == 200
    assert response.get_json() == [{"id": 1, "label": "PENDIENTE - Pendiente"}]

    args, kwargs = mock_fn.call_args
    assert args[1] == "dbo.EstadoFactura"
    assert args[2] == "EstadoFacturaId"
    assert kwargs["order_by"] == "EstadoFacturaId"
    assert kwargs["solo_activos"] is True


def test_usuarios_delega_con_orden_y_solo_activos(client):
    # NombreUsuario + ' - ' + NombresCompletos también es concatenación
    # T-SQL, no portable al doble SQLite.
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.lookup_routes.crud_service.lookup_rows") as mock_fn:
        mock_fn.return_value = [{"id": 1, "label": "admin - Admin de Prueba"}]
        response = client.get("/api/usuarios", headers=auth_headers(token))

    assert response.status_code == 200
    assert response.get_json() == [{"id": 1, "label": "admin - Admin de Prueba"}]

    args, kwargs = mock_fn.call_args
    assert args[1] == "seg.Usuario"
    assert args[2] == "UsuarioId"
    assert kwargs["order_by"] == "NombresCompletos"
    assert kwargs["solo_activos"] is True


def test_plazos_pago_real_incluye_dias(client):
    # A diferencia de segmentos-riesgo/clasificaciones-cliente, esta consulta
    # no usa concatenación T-SQL, así que corre tal cual contra el doble
    # SQLite (datos sembrados en conftest.py: PlazoPagoId=1 'CONTADO', 0 días).
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.get("/api/plazos-pago", headers=auth_headers(token))
    assert response.status_code == 200
    body = response.get_json()
    assert {"id": PLAZO_PAGO_ID, "label": "CONTADO", "dias": 0} in body
