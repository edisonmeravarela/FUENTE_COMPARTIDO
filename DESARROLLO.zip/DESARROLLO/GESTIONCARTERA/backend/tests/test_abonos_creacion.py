from conftest import (
    ADMIN_PASSWORD,
    ADMIN_USERNAME,
    ADMIN_USUARIO_ID,
    CIUDAD_ID,
    FORMA_PAGO_ID,
    VENDEDOR_ID_1,
    VENDEDOR_USUARIO_ID,
    auth_headers,
    login,
)


def _crear_cliente(client, headers) -> int:
    return client.post(
        "/api/clientes", headers=headers, json={"NombreCompleto": "Cliente Abono", "CiudadId": CIUDAD_ID}
    ).get_json()["ClienteId"]


def _crear_factura(client, headers, numero: str, valor_total: float) -> int:
    cliente_id = _crear_cliente(client, headers)
    return client.post(
        "/api/facturas",
        headers=headers,
        json={
            "NumeroFactura": numero,
            "VendedorId": VENDEDOR_ID_1,
            "ClienteId": cliente_id,
            "FechaEmision": "2026-08-21",
            "ValorTotal": str(valor_total),
        },
    ).get_json()["FacturaId"]


def test_registrar_abono_completo(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)
    factura_id = _crear_factura(client, headers, "F-ABO-001", 200.0)

    response = client.post(
        "/api/abonos",
        headers=headers,
        json={
            "FacturaId": factura_id,
            "FechaAbono": "2026-08-21",
            "ValorAbono": "75.50",
            "ValorRetencion": "4.50",
            "FormaPagoId": FORMA_PAGO_ID,
            "Observacion": "Pago parcial en efectivo",
        },
    )
    assert response.status_code == 201
    abono_id = response.get_json()["AbonoId"]

    obtenido = client.get(f"/api/abonos/{abono_id}", headers=headers).get_json()
    assert obtenido["FacturaId"] == factura_id
    assert obtenido["ValorAbono"] == 75.5
    assert obtenido["ValorRetencion"] == 4.5
    assert obtenido["FormaPagoId"] == FORMA_PAGO_ID
    assert obtenido["Observacion"] == "Pago parcial en efectivo"
    assert obtenido["UsuarioId"] == ADMIN_USUARIO_ID


def test_registrar_abono_graba_el_usuario_logueado_no_uno_enviado_por_el_cliente(client):
    from conftest import VENDEDOR_PASSWORD, VENDEDOR_USERNAME

    admin_token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    factura_id = _crear_factura(client, auth_headers(admin_token), "F-ABO-007", 100.0)

    # el vendedor registra el abono; aunque el payload intente suplantar a
    # otro usuario, UsuarioId debe quedar en quien está logueado de verdad.
    vendedor_token = login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD)
    response = client.post(
        "/api/abonos",
        headers=auth_headers(vendedor_token),
        json={
            "FacturaId": factura_id,
            "FechaAbono": "2026-08-21",
            "ValorAbono": "10",
            "UsuarioId": ADMIN_USUARIO_ID,
        },
    )
    assert response.status_code == 201
    abono_id = response.get_json()["AbonoId"]

    obtenido = client.get(f"/api/abonos/{abono_id}", headers=auth_headers(admin_token)).get_json()
    assert obtenido["UsuarioId"] == VENDEDOR_USUARIO_ID


def test_registrar_abono_sin_retencion_ni_forma_pago_no_falla(client):
    # Regresión: ValorRetencion es NOT NULL con default 0 en la base real;
    # antes del fix, dejarlo vacío insertaba NULL explícito y SQL Server
    # rechazaba el INSERT (409 "valor duplicado o referencia inválida").
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)
    factura_id = _crear_factura(client, headers, "F-ABO-002", 100.0)

    response = client.post(
        "/api/abonos",
        headers=headers,
        json={"FacturaId": factura_id, "FechaAbono": "2026-08-21", "ValorAbono": "40"},
    )
    assert response.status_code == 201
    abono_id = response.get_json()["AbonoId"]

    obtenido = client.get(f"/api/abonos/{abono_id}", headers=headers).get_json()
    assert obtenido["ValorRetencion"] == 0
    assert obtenido["FormaPagoId"] is None
    assert obtenido["Observacion"] is None


def test_registrar_abono_falta_factura_id(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.post(
        "/api/abonos",
        headers=auth_headers(token),
        json={"FechaAbono": "2026-08-21", "ValorAbono": "40"},
    )
    assert response.status_code == 400
    assert "FacturaId" in response.get_json()["errores"]


def test_registrar_abono_falta_fecha(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)
    factura_id = _crear_factura(client, headers, "F-ABO-003", 100.0)

    response = client.post(
        "/api/abonos", headers=headers, json={"FacturaId": factura_id, "ValorAbono": "40"}
    )
    assert response.status_code == 400
    assert "FechaAbono" in response.get_json()["errores"]


def test_registrar_abono_falta_valor(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)
    factura_id = _crear_factura(client, headers, "F-ABO-004", 100.0)

    response = client.post(
        "/api/abonos", headers=headers, json={"FacturaId": factura_id, "FechaAbono": "2026-08-21"}
    )
    assert response.status_code == 400
    assert "ValorAbono" in response.get_json()["errores"]


def test_registrar_abono_factura_inexistente(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.post(
        "/api/abonos",
        headers=auth_headers(token),
        json={"FacturaId": 999999, "FechaAbono": "2026-08-21", "ValorAbono": "40"},
    )
    assert response.status_code == 409


def test_registrar_abono_requiere_permiso(client):
    from conftest import VENDEDOR_PASSWORD, VENDEDOR_USERNAME

    admin_token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    factura_id = _crear_factura(client, auth_headers(admin_token), "F-ABO-005", 100.0)

    # VENDEDOR/COBRADOR sí tiene COBRANZA.REGISTRAR_ABONO en los datos de prueba
    vendedor_token = login(client, VENDEDOR_USERNAME, VENDEDOR_PASSWORD)
    response = client.post(
        "/api/abonos",
        headers=auth_headers(vendedor_token),
        json={"FacturaId": factura_id, "FechaAbono": "2026-08-21", "ValorAbono": "10"},
    )
    assert response.status_code == 201


def test_registrar_varios_abonos_sobre_la_misma_factura_se_listan(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    headers = auth_headers(token)
    factura_id = _crear_factura(client, headers, "F-ABO-006", 300.0)

    for valor in ("50", "30", "20"):
        r = client.post(
            "/api/abonos",
            headers=headers,
            json={"FacturaId": factura_id, "FechaAbono": "2026-08-21", "ValorAbono": valor},
        )
        assert r.status_code == 201

    listado = client.get("/api/abonos", headers=headers).get_json()
    abonos_de_la_factura = [a for a in listado if a["FacturaId"] == factura_id]
    assert len(abonos_de_la_factura) == 3
    assert sorted(a["ValorAbono"] for a in abonos_de_la_factura) == [20.0, 30.0, 50.0]
