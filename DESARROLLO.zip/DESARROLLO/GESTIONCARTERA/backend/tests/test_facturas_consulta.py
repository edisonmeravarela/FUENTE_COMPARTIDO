from unittest.mock import patch

from conftest import ADMIN_PASSWORD, ADMIN_USERNAME, auth_headers, login

# sp_ConsultarFacturas es un procedimiento T-SQL real (EXEC ...), no portable
# al doble SQLite usado en el resto de tests; aquí se prueba la ruta (permiso,
# parseo de filtros) simulando src.services.facturas_service.consultar. La
# llamada real al procedimiento se verificó a mano contra el SQL Server.


def test_consultar_requiere_sesion(client):
    response = client.get("/api/facturas/consultar")
    assert response.status_code == 401


def test_consultar_parsea_filtros_y_delega_al_servicio(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.facturas_routes.facturas_service.consultar") as mock_consultar:
        mock_consultar.return_value = [{"FacturaId": 1, "NumeroFactura": "F-001"}]
        response = client.get(
            "/api/facturas/consultar",
            query_string={
                "NumeroFactura": "F-001",
                "FechaEmision": "2026-08-20",
                "VendedorId": "1",
                "ClienteId": "5",
                "EstadoFacturaId": "2",
                "PlazoPagoId": "3",
                "FechaVencimiento": "2026-09-19",
            },
            headers=auth_headers(token),
        )

    assert response.status_code == 200
    assert response.get_json() == [{"FacturaId": 1, "NumeroFactura": "F-001"}]

    _, kwargs = mock_consultar.call_args
    assert kwargs["numero_factura"] == "F-001"
    assert kwargs["fecha_emision"].isoformat() == "2026-08-20"
    assert kwargs["vendedor_id"] == 1
    assert kwargs["cliente_id"] == 5
    assert kwargs["estado_factura_id"] == 2
    assert kwargs["plazo_pago_id"] == 3
    assert kwargs["fecha_vencimiento"].isoformat() == "2026-09-19"


def test_consultar_sin_filtros_pasa_todo_none(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)

    with patch("src.api.facturas_routes.facturas_service.consultar") as mock_consultar:
        mock_consultar.return_value = []
        client.get("/api/facturas/consultar", headers=auth_headers(token))

    _, kwargs = mock_consultar.call_args
    assert kwargs == {
        "numero_factura": None,
        "fecha_emision": None,
        "vendedor_id": None,
        "cliente_id": None,
        "estado_factura_id": None,
        "plazo_pago_id": None,
        "fecha_vencimiento": None,
    }
