"""Enmascaramiento dinámico de datos por rol (ddm_gestioncartera_definitivo.sql)
sobre dbo.Cliente/ClienteTelefono. Cubre dos niveles:

  - Unitario (con un doble de conexión, no SQLite): `crud_service.list_rows`/
    `get_row` para la entidad `clientes` deben llamar a
    `dbo.sp_ConsultarClienteCrud` en vez de construir el SELECT dinámico
    habitual, y deben usar la conexión de `db_service.get_db_enmascarado()`
    cuando exista una para el rol en sesión.
  - En vivo, contra el SQL Server y la app Flask reales: dos usuarios
    descartables (uno ADMINISTRADOR, otro VENDEDOR/COBRADOR) inician sesión
    de verdad y consultan `GET /api/clientes` — el enmascaramiento debe
    diferir según el rol, tal como lo aplica el motor de base de datos, no
    un valor fijo en el código.
"""

import os
import uuid
from datetime import datetime
from types import SimpleNamespace
from unittest.mock import patch

import pyodbc
import pytest
from dotenv import load_dotenv

from src.entities import ENTITIES
from src.services import clientes_service, crud_service
from src.utils.security import hash_password

load_dotenv()


class _FakeCursor:
    def __init__(self, filas, columnas):
        self.description = [(c,) for c in columnas]
        self.executed: list[tuple[str, tuple]] = []
        self._filas = filas

    def execute(self, sql, params=()):
        self.executed.append((sql, tuple(params)))

    def fetchall(self):
        return self._filas


class _FakeSqlServerConnection:
    """No es sqlite3.Connection a propósito: crud_service._is_sqlite(db)
    debe devolver False para que list_rows/get_row tomen la rama del
    procedimiento en vez del SELECT dinámico."""

    def __init__(self, filas, columnas):
        self._cursor = _FakeCursor(filas, columnas)

    def cursor(self):
        return self._cursor


_COLUMNAS_CLIENTE_CRUD = [
    "ClienteId", "NombreCompleto", "Identificacion", "Direccion", "CiudadId",
    "Telefono", "SegmentoRiesgoId", "ClasificacionId", "PlazoPagoId",
    "LimiteCreditoPersonal", "Activo",
]


def _fila_cliente_falsa(cliente_id=1, identificacion="99XXXXXXX99"):
    # SimpleNamespace, no una tupla: pyodbc.Row (y _row_to_dict) acceden a
    # las columnas por atributo (getattr(row, "ClienteId")), no por índice.
    valores = (cliente_id, "Cliente Prueba", identificacion, "Calle Falsa 123", 1, "099XXXX44", 1, 1, 1, 500.0, True)
    return SimpleNamespace(**dict(zip(_COLUMNAS_CLIENTE_CRUD, valores)))


def test_list_rows_usa_el_procedimiento_para_clientes():
    entity = ENTITIES["clientes"]
    db = _FakeSqlServerConnection([_fila_cliente_falsa()], _COLUMNAS_CLIENTE_CRUD)

    with patch("src.services.db.get_db_enmascarado", return_value=None):
        filas = crud_service.list_rows(db, entity, solo_activos=True)

    sql, params = db._cursor.executed[0]
    assert sql == "EXEC dbo.sp_ConsultarClienteCrud @Id = ?, @SoloActivos = ?"
    assert params == (None, 1)
    assert filas[0]["Identificacion"] == "99XXXXXXX99"


def test_get_row_usa_el_procedimiento_para_clientes():
    entity = ENTITIES["clientes"]
    db = _FakeSqlServerConnection([_fila_cliente_falsa(cliente_id=42)], _COLUMNAS_CLIENTE_CRUD)

    with patch("src.services.db.get_db_enmascarado", return_value=None):
        fila = crud_service.get_row(db, entity, 42)

    sql, params = db._cursor.executed[0]
    assert params == (42, 0)
    assert fila["ClienteId"] == 42


def test_get_row_usa_la_conexion_de_enmascaramiento_si_existe():
    entity = ENTITIES["clientes"]
    db_servicio = _FakeSqlServerConnection([], _COLUMNAS_CLIENTE_CRUD)  # no debe usarse
    db_enmascarado = _FakeSqlServerConnection([_fila_cliente_falsa(identificacion="99XXXXXXX99")], _COLUMNAS_CLIENTE_CRUD)

    with patch("src.services.db.get_db_enmascarado", return_value=db_enmascarado):
        fila = crud_service.get_row(db_servicio, entity, 1)

    assert db_servicio._cursor.executed == []  # la conexión de servicio nunca se tocó
    assert fila["Identificacion"] == "99XXXXXXX99"


def test_get_row_recurre_a_la_conexion_pasada_si_no_hay_rol_de_enmascaramiento():
    entity = ENTITIES["clientes"]
    db = _FakeSqlServerConnection([_fila_cliente_falsa()], _COLUMNAS_CLIENTE_CRUD)

    with patch("src.services.db.get_db_enmascarado", return_value=None):
        fila = crud_service.get_row(db, entity, 1)

    assert fila is not None
    assert len(db._cursor.executed) == 1


_COLUMNAS_CONSULTAR_CLIENTES = [
    "CodigoCliente", "NombreCompleto", "Identificacion", "Direccion", "Ciudad",
    "Telefono", "SegmentoRiesgo", "Clasificacion", "PlazoPago",
    "LimiteCreditoPersonal", "LimiteCreditoVigente", "Estado", "FechaRegistro",
]


def _fila_consultar_clientes_falsa(identificacion="99XXXXXXX99"):
    # Tupla, no SimpleNamespace: a diferencia de crud_service (que arma el
    # dict por atributo, como pyodbc.Row), clientes_service.consultar() hace
    # zip(columns, row) posicional, igual que consumiría un pyodbc.Row real
    # (que también es iterable por posición).
    return (
        175, "YULITZA SAMANIEGO", identificacion, "xxxx", "HUAQUILLAS",
        "099XXXX75", "Riesgo medio", "Cliente regular", "30 DÍAS", 0.1, 0.1, "ACTIVO", "2026-01-01",
    )


def test_consultar_clientes_usa_la_conexion_de_enmascaramiento_si_existe():
    """clientes_service.consultar() (pantalla "Clientes", sp_ConsultarClientes)
    — mismo criterio que crud_service.get_row para la entidad clientes,
    pero sin ningún procedimiento nuevo: sp_ConsultarClientes ya funciona
    con los logins de solo EXECUTE por encadenamiento de propiedad."""
    db_servicio = _FakeSqlServerConnection([], _COLUMNAS_CONSULTAR_CLIENTES)  # no debe usarse
    db_enmascarado = _FakeSqlServerConnection([_fila_consultar_clientes_falsa()], _COLUMNAS_CONSULTAR_CLIENTES)

    with patch("src.services.db.get_db_enmascarado", return_value=db_enmascarado):
        filas = clientes_service.consultar(db_servicio, cliente_id=175)

    assert db_servicio._cursor.executed == []  # la conexión de servicio nunca se tocó
    assert filas[0]["Identificacion"] == "99XXXXXXX99"


def test_consultar_clientes_recurre_a_la_conexion_pasada_si_no_hay_rol_de_enmascaramiento():
    db = _FakeSqlServerConnection(
        [_fila_consultar_clientes_falsa(identificacion="9999999999")], _COLUMNAS_CONSULTAR_CLIENTES
    )

    with patch("src.services.db.get_db_enmascarado", return_value=None):
        filas = clientes_service.consultar(db, cliente_id=175)

    assert len(db._cursor.executed) == 1
    assert filas[0]["Identificacion"] == "9999999999"


def test_otras_entidades_no_usan_el_procedimiento():
    """vendedores no declara read_procedure: debe seguir con SQL dinámico
    (esta prueba usa un doble SQLite real, no el falso de arriba, porque
    _is_sqlite(db) también decide la rama para el resto de la suite)."""
    import sqlite3
    from types import SimpleNamespace

    def _row_factory(cursor, row):
        columnas = [c[0] for c in cursor.description]
        return SimpleNamespace(**dict(zip(columnas, row)))

    conn = sqlite3.connect(":memory:")
    conn.row_factory = _row_factory
    conn.execute("CREATE TABLE Vendedor (VendedorId INTEGER PRIMARY KEY, Nombres TEXT, Telefono TEXT, PorcComision REAL, Activo INTEGER)")
    conn.execute("INSERT INTO Vendedor (Nombres, Telefono, PorcComision, Activo) VALUES ('Uno', NULL, 0, 1)")
    conn.commit()

    entity = ENTITIES["vendedores"]
    entity_ajustada = entity.__class__(**{**entity.__dict__, "table": "Vendedor"})
    filas = crud_service.list_rows(conn, entity_ajustada)
    assert filas[0]["Nombres"] == "Uno"


# ---------------------------------------------------------------------------
# Verificación en vivo contra el SQL Server y la app Flask reales.
# ---------------------------------------------------------------------------

pytestmark_vivo = pytest.mark.skipif(
    not os.environ.get("DB_SERVER") or not os.environ.get("DB_PASSWORD"),
    reason="Requiere SQL Server real y credenciales en backend/.env.",
)


def _conectar_servicio() -> pyodbc.Connection:
    driver = os.environ.get("DB_DRIVER", "ODBC Driver 17 for SQL Server")
    conn_str = (
        f"DRIVER={{{driver}}};SERVER={os.environ['DB_SERVER']};DATABASE={os.environ['DB_NAME']};"
        f"UID={os.environ['DB_USER']};PWD={os.environ['DB_PASSWORD']};TrustServerCertificate=yes;"
    )
    return pyodbc.connect(conn_str, timeout=5)


def _crear_usuario_descartable(conn: pyodbc.Connection, nombre_usuario: str, nombre_rol: str, clave: str) -> int:
    cur = conn.cursor()
    clave_hash, clave_salt = hash_password(clave)
    cur.execute(
        "INSERT INTO seg.Usuario (NombreUsuario, Correo, NombresCompletos, ClaveHash, ClaveSalt, Activo, FechaCreacion) "
        "VALUES (?, ?, ?, ?, ?, 1, ?); SELECT SCOPE_IDENTITY() AS id;",
        (nombre_usuario, f"{nombre_usuario}@test.local", "Usuario Descartable DDM", clave_hash, clave_salt, datetime.now()),
    )
    while cur.description is None:
        if not cur.nextset():
            break
    usuario_id = int(cur.fetchval())
    cur.execute("SELECT RolId FROM seg.Rol WHERE Nombre = ?", (nombre_rol,))
    rol_id = cur.fetchval()
    cur.execute(
        "INSERT INTO seg.UsuarioRol (UsuarioId, RolId, FechaAsignacion) VALUES (?, ?, ?)",
        (usuario_id, rol_id, datetime.now()),
    )
    conn.commit()
    return usuario_id


def _borrar_usuario_descartable(conn: pyodbc.Connection, usuario_id: int) -> None:
    cur = conn.cursor()
    for tabla in ("seg.UsuarioRol", "seg.Sesion", "seg.IntentoAcceso", "seg.Auditoria"):
        cur.execute(f"DELETE FROM {tabla} WHERE UsuarioId = ?", (usuario_id,))
    cur.execute("DELETE FROM seg.Usuario WHERE UsuarioId = ?", (usuario_id,))
    conn.commit()


@pytest.fixture
def usuarios_descartables_ddm():
    if not os.environ.get("DB_SERVER") or not os.environ.get("DB_PASSWORD"):
        pytest.skip("Requiere SQL Server real y credenciales en backend/.env.")
    conn = _conectar_servicio()
    sufijo = uuid.uuid4().hex[:8]
    clave = "ClaveDdmPrueba#2026"
    nombre_admin = f"TEST_DDM_ADMIN_{sufijo}"
    nombre_cobrador = f"TEST_DDM_COBRADOR_{sufijo}"
    id_admin = _crear_usuario_descartable(conn, nombre_admin, "ADMINISTRADOR", clave)
    id_cobrador = _crear_usuario_descartable(conn, nombre_cobrador, "VENDEDOR/COBRADOR", clave)
    yield {"admin": (nombre_admin, clave), "cobrador": (nombre_cobrador, clave)}
    _borrar_usuario_descartable(conn, id_admin)
    _borrar_usuario_descartable(conn, id_cobrador)
    conn.close()


@pytest.fixture
def live_client():
    # Deliberadamente SIN "with app.test_client() as ...": ese modismo
    # preserva el contexto de la petición anterior hasta la siguiente
    # llamada (para poder inspeccionar flask.g/session desde la prueba),
    # lo que retrasa el teardown_appcontext (close_db) un ciclo y duplica
    # el cierre de conexiones cuando esta prueba hace varias peticiones
    # seguidas. Sin el "with", cada llamada empuja y cierra su propio
    # contexto de inmediato, como en producción.
    from app import create_app
    from config import Config

    app = create_app(Config)
    return app.test_client()


@pytestmark_vivo
def test_ddm_enmascara_distinto_segun_el_rol_conectado(live_client, usuarios_descartables_ddm):
    resultados = {}
    for rol, (usuario, clave) in usuarios_descartables_ddm.items():
        login = live_client.post("/api/auth/login", json={"username": usuario, "password": clave})
        assert login.status_code == 200, login.get_json()
        token = login.get_json()["token"]

        respuesta = live_client.get("/api/clientes?activo=1", headers={"Authorization": f"Bearer {token}"})
        assert respuesta.status_code == 200
        filas = respuesta.get_json()
        assert filas, "no hay clientes activos para comparar el enmascaramiento"
        resultados[rol] = filas[0]

    # ADMINISTRADOR: sin UNMASK denegado -> identificación real (solo dígitos).
    assert resultados["admin"]["Identificacion"].isdigit()
    # VENDEDOR/COBRADOR: identificación enmascarada por partial(2,"XXXXXXX",2).
    assert "X" in resultados["cobrador"]["Identificacion"]
    # El mismo cliente (activo=1, ORDER BY ClienteId DESC en ambos casos).
    assert resultados["admin"]["ClienteId"] == resultados["cobrador"]["ClienteId"]


@pytestmark_vivo
def test_ddm_enmascara_tambien_en_la_pantalla_consultar_clientes(live_client, usuarios_descartables_ddm):
    """Mismo criterio que test_ddm_enmascara_distinto_segun_el_rol_conectado,
    pero contra GET /api/clientes/consultar (clientes_service.consultar,
    pantalla "Clientes" del frontend) en vez del CRUD genérico — confirma
    que la extensión también cubre esta ruta."""
    resultados = {}
    for rol, (usuario, clave) in usuarios_descartables_ddm.items():
        login = live_client.post("/api/auth/login", json={"username": usuario, "password": clave})
        assert login.status_code == 200, login.get_json()
        token = login.get_json()["token"]

        respuesta = live_client.get("/api/clientes/consultar", headers={"Authorization": f"Bearer {token}"})
        assert respuesta.status_code == 200
        filas = respuesta.get_json()
        assert filas, "no hay clientes para comparar el enmascaramiento"
        resultados[rol] = filas[0]

    assert resultados["admin"]["Identificacion"].isdigit()
    assert "X" in resultados["cobrador"]["Identificacion"]
    assert resultados["admin"]["CodigoCliente"] == resultados["cobrador"]["CodigoCliente"]
