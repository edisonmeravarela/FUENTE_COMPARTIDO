from unittest.mock import patch

from conftest import (
    ADMIN_PASSWORD,
    ADMIN_USERNAME,
    SUPERVISOR_PASSWORD,
    SUPERVISOR_USERNAME,
    VENDEDOR_PASSWORD,
    VENDEDOR_USERNAME,
    auth_headers,
    login,
)

# El módulo Seguridad es nuevo (no una migración): control exclusivo por
# permiso desde el inicio. STRING_AGG (listar_usuarios) y el trigger de
# protección no son portables al doble SQLite, así que se prueba la ruta
# con seguridad_service simulado — se verificó a mano contra el SQL
# Server real (ver manual técnico).

RUTAS_PROTEGIDAS = [
    ("get", "/api/seguridad/usuarios"),
    ("get", "/api/seguridad/usuarios/1"),
    ("post", "/api/seguridad/usuarios"),
    ("put", "/api/seguridad/usuarios/1"),
    ("put", "/api/seguridad/usuarios/1/clave"),
    ("put", "/api/seguridad/usuarios/1/estado"),
    ("get", "/api/seguridad/roles"),
    ("get", "/api/seguridad/matriz-permisos"),
    ("post", "/api/seguridad/matriz-permisos"),
    ("get", "/api/seguridad/auditoria"),
    ("get", "/api/seguridad/bitacora-autorizacion"),
]


def _llamar(client, metodo, ruta, headers=None):
    return getattr(client, metodo)(ruta, headers=headers or {})


def test_todas_las_rutas_requieren_sesion(client):
    for metodo, ruta in RUTAS_PROTEGIDAS:
        assert _llamar(client, metodo, ruta).status_code == 401, ruta


def test_ningun_rol_de_negocio_accede_sin_el_permiso_de_seguridad(client):
    """SEGURIDAD.* solo está asignado a ADMINISTRADOR en la base real; ni
    Supervisor ni Vendedor deben poder entrar, aunque administren otros
    módulos por rol de respaldo."""
    for username, password in [(SUPERVISOR_USERNAME, SUPERVISOR_PASSWORD), (VENDEDOR_USERNAME, VENDEDOR_PASSWORD)]:
        headers = auth_headers(login(client, username, password))
        for metodo, ruta in RUTAS_PROTEGIDAS:
            assert _llamar(client, metodo, ruta, headers).status_code == 403, (username, ruta)


def test_listar_usuarios_devuelve_lista(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.listar_usuarios") as mock_fn:
        mock_fn.return_value = [{"UsuarioId": 1, "NombreUsuario": "admin_prueba", "Roles": "ADMINISTRADOR", "Activo": True}]
        response = client.get("/api/seguridad/usuarios", headers=auth_headers(token))
    assert response.status_code == 200
    assert response.get_json()[0]["NombreUsuario"] == "admin_prueba"


def test_obtener_usuario_devuelve_el_detalle_con_roles(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.obtener_usuario") as mock_fn:
        mock_fn.return_value = {"UsuarioId": 2, "NombreUsuario": "vendedor_prueba", "Roles": [2]}
        response = client.get("/api/seguridad/usuarios/2", headers=auth_headers(token))
    assert response.status_code == 200
    assert response.get_json()["Roles"] == [2]


def test_obtener_usuario_inexistente_da_404(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.obtener_usuario") as mock_fn:
        mock_fn.return_value = None
        response = client.get("/api/seguridad/usuarios/999", headers=auth_headers(token))
    assert response.status_code == 404


def test_crear_usuario_devuelve_201_y_el_id(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.crear_usuario") as mock_fn:
        mock_fn.return_value = 42
        response = client.post(
            "/api/seguridad/usuarios",
            json={"NombreUsuario": "nuevo", "Correo": "n@x.com", "NombresCompletos": "Nuevo", "Clave": "Clave1234", "Roles": [2]},
            headers=auth_headers(token),
        )
    assert response.status_code == 201
    assert response.get_json()["UsuarioId"] == 42
    args = mock_fn.call_args.args
    assert args[2] == "Clave1234"
    assert args[3] == [2]


def test_crear_usuario_con_datos_invalidos_da_400(client):
    from src.services.crud_service import ValidationError

    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.crear_usuario") as mock_fn:
        mock_fn.side_effect = ValidationError({"Correo": "El correo es obligatorio."})
        response = client.post("/api/seguridad/usuarios", json={"NombreUsuario": "x"}, headers=auth_headers(token))
    assert response.status_code == 400
    assert "Correo" in response.get_json()["errores"]


def test_crear_usuario_duplicado_da_409(client):
    from src.services.crud_service import ConflictError

    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.crear_usuario") as mock_fn:
        mock_fn.side_effect = ConflictError("El nombre de usuario ya está en uso.")
        response = client.post("/api/seguridad/usuarios", json={"NombreUsuario": "admin_prueba"}, headers=auth_headers(token))
    assert response.status_code == 409


def test_editar_usuario_ok(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.editar_usuario") as mock_fn:
        mock_fn.return_value = True
        response = client.put(
            "/api/seguridad/usuarios/2",
            json={"NombreUsuario": "vendedor_prueba", "Correo": "v@x.com", "NombresCompletos": "Vendedor", "Roles": [2, 3]},
            headers=auth_headers(token),
        )
    assert response.status_code == 204
    assert mock_fn.call_args.args[3] == [2, 3]


def test_editar_usuario_inexistente_da_404(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.editar_usuario") as mock_fn:
        mock_fn.return_value = False
        response = client.put("/api/seguridad/usuarios/999", json={"Roles": []}, headers=auth_headers(token))
    assert response.status_code == 404


def test_actualizar_clave_ok(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.actualizar_clave") as mock_fn:
        mock_fn.return_value = True
        response = client.put(
            "/api/seguridad/usuarios/2/clave", json={"Clave": "NuevaClave123"}, headers=auth_headers(token)
        )
    assert response.status_code == 204
    assert mock_fn.call_args.args[2] == "NuevaClave123"


def test_actualizar_clave_muy_corta_da_400(client):
    from src.services.crud_service import ValidationError

    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.actualizar_clave") as mock_fn:
        mock_fn.side_effect = ValidationError({"Clave": "La contraseña debe tener al menos 8 caracteres."})
        response = client.put("/api/seguridad/usuarios/2/clave", json={"Clave": "123"}, headers=auth_headers(token))
    assert response.status_code == 400


def test_cambiar_estado_usuario_exige_el_campo_activo(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.put("/api/seguridad/usuarios/2/estado", json={}, headers=auth_headers(token))
    assert response.status_code == 400


def test_cambiar_estado_usuario_inexistente_da_404(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.cambiar_estado_usuario") as mock_fn:
        mock_fn.return_value = False
        response = client.put("/api/seguridad/usuarios/999/estado", json={"activo": False}, headers=auth_headers(token))
    assert response.status_code == 404


def test_cambiar_estado_usuario_ok(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.cambiar_estado_usuario") as mock_fn:
        mock_fn.return_value = True
        response = client.put("/api/seguridad/usuarios/2/estado", json={"activo": False}, headers=auth_headers(token))
    assert response.status_code == 204
    mock_fn.assert_called_once()
    assert mock_fn.call_args.args[1:] == (2, False)


def test_matriz_permisos_devuelve_roles_permisos_y_asignaciones(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.matriz_permisos") as mock_fn:
        mock_fn.return_value = {
            "roles": [{"RolId": 1, "Nombre": "ADMINISTRADOR"}],
            "permisos": [{"PermisoId": 1, "Codigo": "SCORING.EJECUTAR", "ModuloCodigo": "SCORING", "SoloAdministrador": False}],
            "asignaciones": [{"RolId": 1, "PermisoId": 1}],
        }
        response = client.get("/api/seguridad/matriz-permisos", headers=auth_headers(token))
    assert response.status_code == 200
    body = response.get_json()
    assert body["roles"][0]["Nombre"] == "ADMINISTRADOR"


def test_cambiar_asignacion_permiso_exige_los_tres_campos(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    response = client.post("/api/seguridad/matriz-permisos", json={"rol_id": 1}, headers=auth_headers(token))
    assert response.status_code == 400


def test_cambiar_asignacion_permiso_asigna(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.asignar_permiso") as mock_fn:
        response = client.post(
            "/api/seguridad/matriz-permisos",
            json={"rol_id": 3, "permiso_id": 5, "asignar": True},
            headers=auth_headers(token),
        )
    assert response.status_code == 204
    mock_fn.assert_called_once()


def test_cambiar_asignacion_permiso_revoca(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.revocar_permiso") as mock_fn:
        response = client.post(
            "/api/seguridad/matriz-permisos",
            json={"rol_id": 3, "permiso_id": 5, "asignar": False},
            headers=auth_headers(token),
        )
    assert response.status_code == 204
    mock_fn.assert_called_once()


def test_cambiar_asignacion_permiso_restringido_da_409(client):
    """seg.TR_RolPermiso_ProtegerRestringidos: un módulo SoloAdministrador
    no puede asignarse a otro rol — la ruta traduce el rechazo a 409, no
    a un 500 genérico."""
    from src.services import seguridad_service

    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.asignar_permiso") as mock_fn:
        mock_fn.side_effect = seguridad_service.AsignacionRestringidaError(
            "Los permisos de un módulo restringido solo pueden asignarse al rol ADMINISTRADOR."
        )
        response = client.post(
            "/api/seguridad/matriz-permisos",
            json={"rol_id": 3, "permiso_id": 99, "asignar": True},
            headers=auth_headers(token),
        )
    assert response.status_code == 409


def test_auditoria_pasa_los_filtros_de_query_string(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.auditoria") as mock_fn:
        mock_fn.return_value = []
        client.get(
            "/api/seguridad/auditoria?UsuarioId=2&Accion=UPDATE&Dias=7",
            headers=auth_headers(token),
        )
    mock_fn.assert_called_once()
    assert mock_fn.call_args.args[1:] == (2, "UPDATE", 7)


def test_bitacora_autorizacion_devuelve_lista_de_lineas(client):
    token = login(client, ADMIN_USERNAME, ADMIN_PASSWORD)
    with patch("src.api.seguridad_routes.seguridad_service.bitacora_autorizacion") as mock_fn:
        mock_fn.return_value = ["2026-09-11 10:00:00 INFO Autorizado POST /api/vendedores por PERMISO ..."]
        response = client.get("/api/seguridad/bitacora-autorizacion", headers=auth_headers(token))
    assert response.status_code == 200
    assert "PERMISO" in response.get_json()[0]
