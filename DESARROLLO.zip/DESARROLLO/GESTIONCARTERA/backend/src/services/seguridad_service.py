import json
import sqlite3
from pathlib import Path

import pyodbc

from src.services.crud_service import ConflictError, ValidationError, serialize_value
from src.utils.security import hash_password

_DB_ERRORS = (pyodbc.IntegrityError, sqlite3.IntegrityError)

# logs/autorizacion.log lo escribe src/utils/authz.py (decorador de
# transición): cada línea dice qué operación se autorizó y por cuál de
# los dos criterios (PERMISO o ROL) — la traza que exige el paso 5 de la
# migración ("revisando periódicamente la bitácora").
_RUTA_BITACORA_AUTORIZACION = Path(__file__).resolve().parents[2] / "logs" / "autorizacion.log"


def _filas(cur) -> list[dict]:
    columnas = [c[0] for c in cur.description]
    return [{col: serialize_value(val) for col, val in zip(columnas, row)} for row in cur.fetchall()]


def _fila(cur) -> dict | None:
    columnas = [c[0] for c in cur.description]
    row = cur.fetchone()
    return {col: serialize_value(val) for col, val in zip(columnas, row)} if row is not None else None


def listar_usuarios(db) -> list[dict]:
    """seg.Usuario con sus roles activos agregados en una sola columna
    (STRING_AGG) — evita una consulta aparte por usuario."""
    cur = db.cursor()
    cur.execute(
        """
        SELECT u.UsuarioId, u.NombreUsuario, u.Correo, u.NombresCompletos, u.VendedorId,
               u.DebeCambiarClave, u.Activo, u.UltimoAcceso, u.FechaCreacion,
               STRING_AGG(r.Nombre, ', ') WITHIN GROUP (ORDER BY r.Nombre) AS Roles
        FROM seg.Usuario u
        LEFT JOIN seg.UsuarioRol ur ON ur.UsuarioId = u.UsuarioId
        LEFT JOIN seg.Rol r ON r.RolId = ur.RolId AND r.Activo = 1
        GROUP BY u.UsuarioId, u.NombreUsuario, u.Correo, u.NombresCompletos, u.VendedorId,
                 u.DebeCambiarClave, u.Activo, u.UltimoAcceso, u.FechaCreacion
        ORDER BY u.NombreUsuario
        """
    )
    return _filas(cur)


def cambiar_estado_usuario(db, usuario_id: int, activo: bool) -> bool:
    """Activa/inactiva un usuario (no elimina nada — un usuario inactivo
    conserva su historial de auditoría, pero no puede iniciar sesión ni
    validar una sesión ya abierta: auth_service filtra por Activo=1)."""
    cur = db.cursor()
    cur.execute("UPDATE seg.Usuario SET Activo = ? WHERE UsuarioId = ?", (activo, usuario_id))
    db.commit()
    return cur.rowcount > 0


def _auditar(cur, usuario_id, accion, entidad_id, anteriores, nuevos) -> None:
    # Mismo criterio que crud_service._auditar: el CHECK constraint
    # CK_Auditoria_Accion solo admite INSERT/UPDATE/DELETE/ANULAR/LOGIN/LOGOUT.
    cur.execute(
        "INSERT INTO seg.Auditoria (UsuarioId, Accion, Entidad, EntidadId, ValoresAnteriores, ValoresNuevos) "
        "VALUES (?, ?, 'seg.Usuario', ?, ?, ?)",
        (
            usuario_id,
            accion,
            str(entidad_id),
            json.dumps(anteriores, default=str) if anteriores else None,
            json.dumps(nuevos, default=str) if nuevos else None,
        ),
    )


def _validar_datos_usuario(datos: dict, requerir_nombre_usuario: bool) -> dict:
    errores = {}
    nombre_usuario = (datos.get("NombreUsuario") or "").strip()
    correo = (datos.get("Correo") or "").strip()
    nombres_completos = (datos.get("NombresCompletos") or "").strip()

    if requerir_nombre_usuario and not nombre_usuario:
        errores["NombreUsuario"] = "El usuario es obligatorio."
    if not correo:
        errores["Correo"] = "El correo es obligatorio."
    if not nombres_completos:
        errores["NombresCompletos"] = "Los nombres completos son obligatorios."
    if errores:
        raise ValidationError(errores)

    vendedor_id = datos.get("VendedorId")
    return {
        "NombreUsuario": nombre_usuario,
        "Correo": correo,
        "NombresCompletos": nombres_completos,
        "VendedorId": int(vendedor_id) if vendedor_id not in (None, "") else None,
    }


def _validar_clave(clave: str) -> str:
    if not clave or len(clave) < 8:
        raise ValidationError({"Clave": "La contraseña debe tener al menos 8 caracteres."})
    return clave


def _asignar_roles(cur, usuario_id: int, roles_ids: list[int]) -> None:
    cur.execute("SELECT RolId FROM seg.UsuarioRol WHERE UsuarioId = ?", (usuario_id,))
    actuales = {r[0] for r in cur.fetchall()}
    nuevos = {int(r) for r in roles_ids}

    for rol_id in nuevos - actuales:
        cur.execute(
            "INSERT INTO seg.UsuarioRol (UsuarioId, RolId, FechaAsignacion) VALUES (?, ?, SYSDATETIME())",
            (usuario_id, rol_id),
        )
    for rol_id in actuales - nuevos:
        cur.execute("DELETE FROM seg.UsuarioRol WHERE UsuarioId = ? AND RolId = ?", (usuario_id, rol_id))


def obtener_usuario(db, usuario_id: int) -> dict | None:
    cur = db.cursor()
    cur.execute(
        "SELECT UsuarioId, NombreUsuario, Correo, NombresCompletos, VendedorId, Activo, DebeCambiarClave "
        "FROM seg.Usuario WHERE UsuarioId = ?",
        (usuario_id,),
    )
    usuario = _fila(cur)
    if usuario is None:
        return None
    cur.execute("SELECT RolId FROM seg.UsuarioRol WHERE UsuarioId = ?", (usuario_id,))
    usuario["Roles"] = [r[0] for r in cur.fetchall()]
    return usuario


def crear_usuario(db, datos: dict, clave: str, roles_ids: list[int], usuario_id_creador: int) -> int:
    """Crea el usuario y le asigna los roles indicados. La clave inicial
    la fija el administrador, y DebeCambiarClave queda en 1 para que la
    persona la reemplace en su primer inicio de sesión."""
    limpios = _validar_datos_usuario(datos, requerir_nombre_usuario=True)
    _validar_clave(clave)
    clave_hash, clave_salt = hash_password(clave)

    cur = db.cursor()
    try:
        cur.execute(
            "INSERT INTO seg.Usuario "
            "(NombreUsuario, Correo, NombresCompletos, ClaveHash, ClaveSalt, VendedorId, "
            " DebeCambiarClave, Activo, FechaCreacion, CreadoPor) "
            "VALUES (?, ?, ?, ?, ?, ?, 1, 1, SYSDATETIME(), ?); SELECT SCOPE_IDENTITY() AS id;",
            (
                limpios["NombreUsuario"], limpios["Correo"], limpios["NombresCompletos"],
                clave_hash, clave_salt, limpios["VendedorId"], usuario_id_creador,
            ),
        )
        while cur.description is None:
            if not cur.nextset():
                break
        nuevo_id = int(cur.fetchval())

        _asignar_roles(cur, nuevo_id, roles_ids)
        _auditar(cur, usuario_id_creador, "INSERT", nuevo_id, None, {**limpios, "Roles": roles_ids})
        db.commit()
    except _DB_ERRORS as exc:
        db.rollback()
        raise ConflictError(
            "No se pudo crear el usuario: el nombre de usuario, el correo o el vendedor ya están en uso."
        ) from exc
    return nuevo_id


def _como_bool(valor) -> bool:
    if isinstance(valor, bool):
        return valor
    return str(valor).strip().lower() in ("1", "true", "on", "yes", "si", "sí")


def editar_usuario(db, usuario_id: int, datos: dict, roles_ids: list[int], usuario_id_editor: int) -> bool:
    anterior = obtener_usuario(db, usuario_id)
    if anterior is None:
        return False

    limpios = _validar_datos_usuario(datos, requerir_nombre_usuario=True)
    activo = _como_bool(datos["Activo"]) if "Activo" in datos else bool(anterior["Activo"])

    cur = db.cursor()
    try:
        cur.execute(
            "UPDATE seg.Usuario SET NombreUsuario = ?, Correo = ?, NombresCompletos = ?, VendedorId = ?, Activo = ? "
            "WHERE UsuarioId = ?",
            (limpios["NombreUsuario"], limpios["Correo"], limpios["NombresCompletos"], limpios["VendedorId"], activo, usuario_id),
        )
        _asignar_roles(cur, usuario_id, roles_ids)
        _auditar(cur, usuario_id_editor, "UPDATE", usuario_id, anterior, {**limpios, "Activo": activo, "Roles": roles_ids})
        db.commit()
    except _DB_ERRORS as exc:
        db.rollback()
        raise ConflictError(
            "No se pudo actualizar el usuario: el nombre de usuario, el correo o el vendedor ya están en uso."
        ) from exc
    return True


def actualizar_clave(db, usuario_id: int, clave_nueva: str, usuario_id_editor: int) -> bool:
    """Reinicia la contraseña de un usuario. Además de la clave, limpia
    los intentos fallidos y el bloqueo temporal (un reinicio manual del
    administrador es, en la práctica, la salida de un usuario bloqueado),
    y exige que la cambie de nuevo en su próximo inicio de sesión."""
    cur = db.cursor()
    cur.execute("SELECT 1 FROM seg.Usuario WHERE UsuarioId = ?", (usuario_id,))
    if cur.fetchone() is None:
        return False

    _validar_clave(clave_nueva)
    clave_hash, clave_salt = hash_password(clave_nueva)

    cur.execute(
        "UPDATE seg.Usuario SET ClaveHash = ?, ClaveSalt = ?, DebeCambiarClave = 1, "
        "IntentosFallidos = 0, BloqueadoHasta = NULL WHERE UsuarioId = ?",
        (clave_hash, clave_salt, usuario_id),
    )
    _auditar(cur, usuario_id_editor, "UPDATE", usuario_id, None, {"clave_reiniciada": True})
    db.commit()
    return True


def listar_roles(db) -> list[dict]:
    cur = db.cursor()
    cur.execute("SELECT RolId, Nombre, Descripcion, Activo FROM seg.Rol ORDER BY Nombre")
    return _filas(cur)


def matriz_permisos(db) -> dict:
    """Estructura para pintar la grilla rol × permiso completa (no solo lo
    ya asignado): roles activos, permisos agrupados por módulo (con el
    indicador de módulo restringido, para que el frontend deshabilite las
    casillas que la base rechazaría igual), y la lista de asignaciones
    vigentes."""
    cur = db.cursor()
    cur.execute("SELECT RolId, Nombre FROM seg.Rol WHERE Activo = 1 ORDER BY Nombre")
    roles = _filas(cur)

    cur.execute(
        """
        SELECT m.ModuloId, m.Codigo AS ModuloCodigo, m.Nombre AS ModuloNombre,
               m.SoloAdministrador, p.PermisoId, p.Codigo, p.Nombre
        FROM seg.Permiso p
        JOIN seg.Modulo m ON m.ModuloId = p.ModuloId
        WHERE p.Activo = 1 AND m.Activo = 1
        ORDER BY m.Orden, p.Codigo
        """
    )
    permisos = _filas(cur)

    cur.execute("SELECT RolId, PermisoId FROM seg.RolPermiso")
    asignaciones = _filas(cur)

    return {"roles": roles, "permisos": permisos, "asignaciones": asignaciones}


class AsignacionRestringidaError(Exception):
    """El módulo del permiso está marcado SoloAdministrador=1 y el rol no
    es ADMINISTRADOR — seg.TR_RolPermiso_ProtegerRestringidos lo rechaza."""


def asignar_permiso(db, rol_id: int, permiso_id: int) -> None:
    cur = db.cursor()
    try:
        cur.execute(
            "IF NOT EXISTS (SELECT 1 FROM seg.RolPermiso WHERE RolId = ? AND PermisoId = ?) "
            "INSERT INTO seg.RolPermiso (RolId, PermisoId) VALUES (?, ?)",
            (rol_id, permiso_id, rol_id, permiso_id),
        )
        db.commit()
    except Exception as exc:
        db.rollback()
        if "ProtegerRestringidos" in str(exc) or "restringido" in str(exc).lower():
            raise AsignacionRestringidaError(
                "Los permisos de un módulo restringido solo pueden asignarse al rol ADMINISTRADOR."
            ) from exc
        raise


def revocar_permiso(db, rol_id: int, permiso_id: int) -> None:
    cur = db.cursor()
    cur.execute("DELETE FROM seg.RolPermiso WHERE RolId = ? AND PermisoId = ?", (rol_id, permiso_id))
    db.commit()


def auditoria(db, usuario_id: int | None = None, accion: str | None = None, dias: int | None = None) -> list[dict]:
    """seg.Auditoria (ya poblada por crud_service._auditar en cada
    CREATE/UPDATE/DELETE/ANULAR, y por auth_service en LOGIN/LOGOUT),
    más reciente primero, acotada a los últimos `dias` días si se indica
    (por defecto los últimos 30, para no traer el historial completo)."""
    cur = db.cursor()
    cur.execute(
        """
        SELECT TOP 500 a.AuditoriaId, a.Fecha, u.NombreUsuario, a.Accion, a.Entidad,
               a.EntidadId, a.ValoresAnteriores, a.ValoresNuevos, a.DireccionIP
        FROM seg.Auditoria a
        LEFT JOIN seg.Usuario u ON u.UsuarioId = a.UsuarioId
        WHERE (? IS NULL OR a.UsuarioId = ?)
          AND (? IS NULL OR a.Accion = ?)
          AND a.Fecha >= DATEADD(DAY, -?, SYSDATETIME())
        ORDER BY a.Fecha DESC
        """,
        (usuario_id, usuario_id, accion, accion, dias if dias is not None else 30),
    )
    return _filas(cur)


def bitacora_autorizacion(lineas: int = 200) -> list[str]:
    """Últimas líneas de logs/autorizacion.log (paso 5 de la migración:
    observar en operación real cuál de los dos criterios —permiso o
    rol— concedió cada acceso, antes de retirar el respaldo por rol).
    Devuelve una lista vacía, no un error, si el archivo aún no existe
    (ninguna ruta con el decorador de transición se ha invocado todavía)."""
    if not _RUTA_BITACORA_AUTORIZACION.exists():
        return []
    with open(_RUTA_BITACORA_AUTORIZACION, encoding="utf-8") as f:
        todas = f.readlines()
    return [linea.rstrip("\n") for linea in todas[-lineas:]]
