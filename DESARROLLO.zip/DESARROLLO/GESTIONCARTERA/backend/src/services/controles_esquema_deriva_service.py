from src.services.crud_service import serialize_value

# Mismo contrato que src/esquema.py del pipeline de scoring-morosidad
# (dbo.ContratoEsquema.Version = '1.0').
VERSION_CONTRATO_DEFECTO = "1.0"

# Única variable categórica con baseline registrado hoy (ver limitación
# documentada en scoring-morosidad/src/drift.py: PlazoPagoId no tiene una
# columna equivalente y confiable en la vista de entrenamiento).
VARIABLE_DERIVA_DEFECTO = "CiudadId"


def _filas(cur) -> list[dict]:
    columnas = [c[0] for c in cur.description]
    return [{col: serialize_value(val) for col, val in zip(columnas, row)} for row in cur.fetchall()]


def _fila(cur) -> dict | None:
    columnas = [c[0] for c in cur.description]
    row = cur.fetchone()
    return {col: serialize_value(val) for col, val in zip(columnas, row)} if row is not None else None


def validar_esquema(db, version: str = VERSION_CONTRATO_DEFECTO) -> dict:
    """EXEC dbo.sp_ValidarEsquema @Version: dos result sets — el detalle
    columna por columna del catálogo real contra dbo.ContratoEsquema, y
    el conteo agregado de críticos/advertencias. Control 1 de 3 del
    documento "Controles de Esquema, Calidad y Deriva de Datos": a
    diferencia de la calidad de datos (bloquea solo ante críticos) o la
    deriva (nunca bloquea), un cambio de esquema siempre debería detener
    el pipeline antes de leer un solo registro. Es de solo lectura, no
    inserta nada."""
    cur = db.cursor()
    cur.execute("EXEC dbo.sp_ValidarEsquema @Version = ?", (version,))
    detalle = _filas(cur)
    cur.nextset()
    veredicto = _fila(cur)
    return {"detalle": detalle, "veredicto": veredicto}


def medir_deriva_categorica(db, variable: str = VARIABLE_DERIVA_DEFECTO) -> dict:
    """Mide la deriva de una variable categórica contra el baseline más
    reciente registrado para ella en dbo.BaselineVariable — ese baseline
    lo registra el pipeline de scoring-morosidad al terminar cada
    entrenamiento (train.entrenar() -> src/drift.registrar_baseline).
    Control 3 de 3: nunca bloquea, es puramente informativo. Inserta la
    medición en dbo.DriftMedicion/dbo.DriftDetalleTramo, así que confirma
    la transacción."""
    cur = db.cursor()
    cur.execute(
        "SELECT TOP 1 VersionModelo FROM dbo.BaselineVariable WHERE Variable = ? ORDER BY BaselineId DESC",
        (variable,),
    )
    fila_version = _fila(cur)
    if fila_version is None:
        return {"variable": variable, "sin_baseline": True, "diagnostico": None}

    version_modelo = fila_version["VersionModelo"]
    cur.execute(
        "EXEC dbo.sp_CalcularDriftCategorico @VersionModelo = ?, @Variable = ?",
        (version_modelo, variable),
    )
    diagnostico = _fila(cur)
    db.commit()
    return {"variable": variable, "sin_baseline": False, "diagnostico": diagnostico}


def diagnostico_drift(db) -> list[dict]:
    """dbo.vw_DiagnosticoDrift: todas las mediciones de deriva ya
    persistidas, con el diagnóstico resuelto (deriva real vs. cobertura
    insuficiente vs. concentrada en un tramo) — solo lectura."""
    cur = db.cursor()
    cur.execute("SELECT * FROM dbo.vw_DiagnosticoDrift ORDER BY Fecha DESC")
    return _filas(cur)


def desglose_por_medicion(db, medicion_id: int) -> list[dict]:
    """Aporte de cada tramo a una medición puntual de deriva
    (dbo.DriftDetalleTramo), con las mismas fórmulas que
    dbo.vw_DriftPorTramo pero filtradas por MedicionId (esa vista no
    expone la columna, solo Variable/VersionModelo/Fecha)."""
    cur = db.cursor()
    cur.execute(
        """
        SELECT d.Tramo,
               CAST(100.0 * d.ProporcionBase AS DECIMAL(6,2)) AS PctBase,
               CAST(100.0 * d.ProporcionActual AS DECIMAL(6,2)) AS PctActual,
               CAST(100.0 * (d.ProporcionActual - d.ProporcionBase) AS DECIMAL(6,2)) AS Variacion,
               d.AportePSI,
               CAST(100.0 * d.AportePSI / NULLIF(m.PSI, 0) AS DECIMAL(6,2)) AS PctDelPSI,
               CASE WHEN d.EnBaseline = 1 THEN 'CONOCIDO' ELSE 'NO VISTO EN ENTRENAMIENTO' END AS Origen
        FROM dbo.DriftDetalleTramo d
        JOIN dbo.DriftMedicion m ON m.MedicionId = d.MedicionId
        WHERE d.MedicionId = ?
        ORDER BY d.AportePSI DESC
        """,
        (medicion_id,),
    )
    return _filas(cur)


def evolucion_drift(db) -> list[dict]:
    """dbo.vw_EvolucionDrift: PSI de cada variable a través de
    ejecuciones sucesivas, con la variación respecto a la medición
    anterior — permite distinguir una desviación puntual de una
    tendencia sostenida. Solo lectura."""
    cur = db.cursor()
    cur.execute("SELECT * FROM dbo.vw_EvolucionDrift ORDER BY Variable, Fecha DESC")
    return _filas(cur)
