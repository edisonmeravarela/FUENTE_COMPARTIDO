"""Invoca el orquestador de línea de comandos del proyecto scoring-morosidad
(paso 8.10 de esa especificación: `main.py entrenar|scorear|monitorear`)
como subproceso, desde el intérprete de SU PROPIO entorno virtual — es un
repositorio independiente, con sus propias dependencias (scikit-learn,
xgboost), que este backend no instala ni importa directamente.

Lista blanca de comandos (COMANDOS): nunca se arma el argv a partir de
texto libre del cliente HTTP, solo se acepta una de las claves conocidas.
"""

import subprocess
import time

from flask import current_app

COMANDOS: dict[str, list[str]] = {
    "entrenar": ["entrenar"],
    "scorear-dry-run": ["scorear", "--dry-run"],
    "scorear": ["scorear"],
    "monitorear": ["monitorear"],
}

# Entrenar/scorear puede tardar bastante más que una petición HTTP típica
# (extracción + features + ajuste del modelo, o 150+ clientes uno a uno
# contra el procedimiento almacenado); se generosa a propósito.
TIMEOUT_SEGUNDOS_DEFECTO = 600


class ComandoInvalidoError(Exception):
    """`clave` no está en la lista blanca de comandos permitidos."""


def ejecutar_comando(clave: str, timeout: int | None = None) -> dict:
    """Ejecuta `python main.py <argv de COMANDOS[clave]>` en el proyecto
    scoring-morosidad y devuelve un resumen serializable: código de
    salida, salida estándar, salida de error y duración. Nunca lanza por
    un fallo del script hijo (exit_code != 0) — eso es un resultado
    válido a mostrar al usuario, no un error de este servicio; solo
    lanza ComandoInvalidoError si `clave` es desconocida."""
    if clave not in COMANDOS:
        raise ComandoInvalidoError(f"Comando de scoring desconocido: {clave!r}. Válidos: {sorted(COMANDOS)}.")

    proyecto = current_app.config["SCORING_MOROSIDAD_PATH"]
    python_exe = current_app.config["SCORING_MOROSIDAD_PYTHON"]
    timeout = timeout if timeout is not None else TIMEOUT_SEGUNDOS_DEFECTO

    inicio = time.monotonic()
    try:
        proceso = subprocess.run(
            [python_exe, "main.py", *COMANDOS[clave]],
            cwd=proyecto,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
        duracion = time.monotonic() - inicio
        return {
            "comando": clave,
            "exit_code": proceso.returncode,
            "salida": proceso.stdout,
            "errores": proceso.stderr,
            "duracion_segundos": round(duracion, 1),
            "agotado": False,
        }
    except subprocess.TimeoutExpired as exc:
        duracion = time.monotonic() - inicio
        return {
            "comando": clave,
            "exit_code": None,
            "salida": exc.stdout or "",
            "errores": (exc.stderr or "") + f"\nEl proceso superó el tiempo máximo de {timeout}s y fue cancelado.",
            "duracion_segundos": round(duracion, 1),
            "agotado": True,
        }
