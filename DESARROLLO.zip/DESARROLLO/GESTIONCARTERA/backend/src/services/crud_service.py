import json
import sqlite3
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

import pyodbc

from src.entities import EntityDef, FieldDef

_DB_ERRORS = (pyodbc.IntegrityError, sqlite3.IntegrityError)


class ValidationError(Exception):
    def __init__(self, errors: dict[str, str]):
        super().__init__(str(errors))
        self.errors = errors


class ConflictError(Exception):
    pass


def _is_sqlite(db) -> bool:
    return isinstance(db, sqlite3.Connection)


def serialize_value(value):
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return value


def _row_to_dict(entity: EntityDef, row) -> dict:
    data = {entity.pk: getattr(row, entity.pk)}
    for f in entity.fields:
        value = getattr(row, f.column)
        data[f.column] = bool(value) if f.type == "checkbox" else serialize_value(value)
    return data


def _coerce_for_write(field: FieldDef, raw):
    if raw is None or raw == "":
        if field.required:
            raise ValidationError({field.column: f"{field.label} es obligatorio."})
        return field.default
    try:
        if field.type == "decimal":
            return Decimal(str(raw))
        if field.type in ("number", "select"):
            return int(raw)
        if field.type == "date":
            return raw if isinstance(raw, date) else date.fromisoformat(str(raw))
        if field.type == "checkbox":
            return raw if isinstance(raw, bool) else str(raw).lower() in ("1", "true", "on", "yes")
        return str(raw)
    except (InvalidOperation, ValueError) as exc:
        raise ValidationError({field.column: f"Valor inválido para {field.label}."}) from exc


def _auditar(cur, usuario_id, accion, entidad, entidad_id, anteriores, nuevos, ip_address) -> None:
    cur.execute(
        "INSERT INTO seg.Auditoria (UsuarioId, Accion, Entidad, EntidadId, ValoresAnteriores, ValoresNuevos, DireccionIP) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (
            usuario_id,
            accion,
            entidad,
            str(entidad_id) if entidad_id is not None else None,
            json.dumps(anteriores, default=str) if anteriores else None,
            json.dumps(nuevos, default=str) if nuevos else None,
            ip_address,
        ),
    )


def _leer_por_procedimiento(db, entity: EntityDef, row_id, solo_activos: bool):
    """list_rows/get_row para una entidad con `read_procedure` (hoy, solo
    `clientes` — enmascaramiento dinámico de datos por rol): la conexión
    de enmascaramiento del rol en sesión (si existe) no tiene SELECT
    directo, solo EXECUTE, así que se llama al procedimiento en vez de
    construir el SELECT dinámico habitual."""
    from src.services import db as db_service

    conexion = db_service.get_db_enmascarado() or db
    cur = conexion.cursor()
    cur.execute(f"EXEC {entity.read_procedure} @Id = ?, @SoloActivos = ?", (row_id, 1 if solo_activos else 0))
    return cur.fetchall()


def list_rows(db, entity: EntityDef, vendedor_id: int | None = None, solo_activos: bool = False) -> list[dict]:
    if entity.read_procedure and not _is_sqlite(db):
        filas = _leer_por_procedimiento(db, entity, None, solo_activos)
        return [_row_to_dict(entity, r) for r in filas]

    cols = ", ".join([entity.pk] + [f.column for f in entity.fields])
    clauses = []
    params: list = []
    if entity.vendedor_scope_column and vendedor_id is not None:
        clauses.append(f"{entity.vendedor_scope_column} = ?")
        params.append(vendedor_id)
    if solo_activos and entity.soft_delete:
        # "activo" = no está en el valor inactivo; evita asumir que solo hay
        # dos estados posibles (p.ej. Factura tiene PENDIENTE/CANCELADA/ANULADA,
        # y "activas" son las dos primeras, no solo la de creación).
        column, _, valor_inactivo = entity.soft_delete
        clauses.append(f"{column} != ?")
        params.append(valor_inactivo)

    sql = f"SELECT {cols} FROM {entity.table}"
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += f" ORDER BY {entity.pk} DESC"

    cur = db.cursor()
    cur.execute(sql, tuple(params))
    return [_row_to_dict(entity, r) for r in cur.fetchall()]


def get_row(db, entity: EntityDef, row_id, vendedor_id: int | None = None) -> dict | None:
    if entity.read_procedure and not _is_sqlite(db):
        filas = _leer_por_procedimiento(db, entity, row_id, solo_activos=False)
        return _row_to_dict(entity, filas[0]) if filas else None

    cols = ", ".join([entity.pk] + [f.column for f in entity.fields])
    sql = f"SELECT {cols} FROM {entity.table} WHERE {entity.pk} = ?"
    params = [row_id]
    if entity.vendedor_scope_column and vendedor_id is not None:
        sql += f" AND {entity.vendedor_scope_column} = ?"
        params.append(vendedor_id)

    cur = db.cursor()
    cur.execute(sql, tuple(params))
    row = cur.fetchone()
    return _row_to_dict(entity, row) if row else None


def create_row(db, entity: EntityDef, data: dict, usuario_id: int, ip_address: str | None):
    values, errors = {}, {}
    for f in entity.fields:
        if not f.editable:
            continue
        try:
            values[f.column] = _coerce_for_write(f, data.get(f.column))
        except ValidationError as exc:
            errors.update(exc.errors)
    if errors:
        raise ValidationError(errors)

    if entity.soft_delete:
        # columnas de estado no editables por el usuario (p.ej. EstadoFacturaId
        # de Factura) se inicializan al valor "activo" al crear un registro.
        column, valor_activo, _ = entity.soft_delete
        values.setdefault(column, valor_activo)

    if entity.usuario_column:
        # graba quién crea el registro (p.ej. UsuarioId de Abono), tomado de
        # la sesión que hace la llamada, no de algo que el formulario envíe.
        values[entity.usuario_column] = usuario_id

    columns = list(values.keys())
    placeholders = ", ".join("?" for _ in columns)
    col_list = ", ".join(columns)
    cur = db.cursor()
    try:
        if _is_sqlite(db):
            cur.execute(f"INSERT INTO {entity.table} ({col_list}) VALUES ({placeholders})", tuple(values.values()))
            new_id = cur.lastrowid
        else:
            # OUTPUT INSERTED.<pk> falla si la tabla tiene triggers habilitados
            # (p.ej. TR_Abono_ActualizarFactura en dbo.Abono); SCOPE_IDENTITY()
            # evita ese conflicto y funciona igual para tablas sin triggers.
            cur.execute(
                f"INSERT INTO {entity.table} ({col_list}) VALUES ({placeholders}); SELECT SCOPE_IDENTITY() AS id;",
                tuple(values.values()),
            )
            while cur.description is None:
                if not cur.nextset():
                    break
            new_id = int(cur.fetchval())
        _auditar(cur, usuario_id, "INSERT", entity.table, new_id, None, values, ip_address)
        db.commit()
    except _DB_ERRORS as exc:
        db.rollback()
        raise ConflictError("No se pudo crear: hay un valor duplicado o una referencia inválida.") from exc
    return new_id


def update_row(db, entity: EntityDef, row_id, data: dict, usuario_id: int, ip_address: str | None) -> bool:
    anterior = get_row(db, entity, row_id)
    if anterior is None:
        return False

    values, errors = {}, {}
    for f in entity.fields:
        if not f.editable:
            continue
        try:
            values[f.column] = _coerce_for_write(f, data.get(f.column))
        except ValidationError as exc:
            errors.update(exc.errors)
    if errors:
        raise ValidationError(errors)

    set_clause = ", ".join(f"{c} = ?" for c in values)
    cur = db.cursor()
    try:
        cur.execute(f"UPDATE {entity.table} SET {set_clause} WHERE {entity.pk} = ?", (*values.values(), row_id))
        _auditar(cur, usuario_id, "UPDATE", entity.table, row_id, anterior, values, ip_address)
        db.commit()
    except _DB_ERRORS as exc:
        db.rollback()
        raise ConflictError("No se pudo actualizar: hay un valor duplicado o una referencia inválida.") from exc
    return True


def delete_row(db, entity: EntityDef, row_id, usuario_id: int, ip_address: str | None) -> bool:
    anterior = get_row(db, entity, row_id)
    if anterior is None:
        return False

    if entity.dependency_check:
        dep_table, dep_column, mensaje = entity.dependency_check
        cur = db.cursor()
        cur.execute(f"SELECT 1 FROM {dep_table} WHERE {dep_column} = ?", (row_id,))
        if cur.fetchone() is not None:
            raise ConflictError(mensaje)

    cur = db.cursor()
    try:
        if entity.soft_delete:
            column, _activo, valor_inactivo = entity.soft_delete
            cur.execute(f"UPDATE {entity.table} SET {column} = ? WHERE {entity.pk} = ?", (valor_inactivo, row_id))
            accion = entity.soft_delete_accion
        else:
            cur.execute(f"DELETE FROM {entity.table} WHERE {entity.pk} = ?", (row_id,))
            accion = "DELETE"
        _auditar(cur, usuario_id, accion, entity.table, row_id, anterior, None, ip_address)
        db.commit()
    except _DB_ERRORS as exc:
        db.rollback()
        raise ConflictError("No se puede eliminar: hay registros relacionados que dependen de este.") from exc
    return True


def lookup_rows(
    db,
    table: str,
    pk: str,
    label_column: str,
    order_by: str | None = None,
    solo_activos: bool = False,
    extra_column: str | None = None,
    extra_alias: str = "extra",
) -> list[dict]:
    cols = f"{pk} AS id, {label_column} AS label"
    if extra_column:
        cols += f", {extra_column} AS {extra_alias}"
    sql = f"SELECT {cols} FROM {table}"
    if solo_activos:
        sql += " WHERE Activo = 1"
    sql += f" ORDER BY {order_by or label_column}"
    cur = db.cursor()
    cur.execute(sql)
    if extra_column:
        return [{"id": r.id, "label": r.label, extra_alias: getattr(r, extra_alias)} for r in cur.fetchall()]
    return [{"id": r.id, "label": r.label} for r in cur.fetchall()]
