import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from src.utils.security import verify_password

MAX_INTENTOS = 5
MINUTOS_BLOQUEO = 15
HORAS_SESION = 8

MENSAJE_GENERICO = "Usuario o contraseña incorrectos."
MENSAJE_BLOQUEADO = "Cuenta bloqueada temporalmente, intenta más tarde."


@dataclass
class AuthResult:
    exitoso: bool
    motivo: str
    usuario_id: int | None = None
    username: str | None = None
    nombres_completos: str | None = None
    roles: list[str] = field(default_factory=list)
    permisos: list[str] = field(default_factory=list)
    vendedor_id: int | None = None
    sesion_id: str | None = None
    debe_cambiar_clave: bool = False


def mensaje_publico(motivo: str) -> str:
    if motivo == "Cuenta bloqueada temporalmente":
        return MENSAJE_BLOQUEADO
    return MENSAJE_GENERICO


def authenticate(db, username: str, password: str, ip_address: str | None, user_agent: str | None = None) -> AuthResult:
    cur = db.cursor()
    cur.execute(
        "SELECT UsuarioId, NombresCompletos, ClaveHash, ClaveSalt, DebeCambiarClave, "
        "IntentosFallidos, BloqueadoHasta, Activo "
        "FROM seg.Usuario WHERE NombreUsuario = ?",
        (username,),
    )
    row = cur.fetchone()
    ahora = datetime.now()
    usuario_id = row.UsuarioId if row else None
    result = AuthResult(exitoso=False, motivo="", usuario_id=usuario_id, username=username)

    if row is None:
        result.motivo = "Usuario no existe"
    elif not row.Activo:
        result.motivo = "Usuario inactivo"
    elif row.BloqueadoHasta and row.BloqueadoHasta > ahora:
        result.motivo = "Cuenta bloqueada temporalmente"
    elif not verify_password(password, row.ClaveHash, row.ClaveSalt):
        result.motivo = "Clave incorrecta"
        _registrar_intento_fallido(cur, row, ahora)
    else:
        result.exitoso = True
        result.motivo = "Acceso correcto"
        result.nombres_completos = row.NombresCompletos
        result.debe_cambiar_clave = bool(row.DebeCambiarClave)
        result.roles = fetch_roles(cur, usuario_id)
        result.permisos, result.vendedor_id = fetch_permisos_context(cur, usuario_id)
        result.sesion_id = _iniciar_sesion(cur, usuario_id, ip_address, user_agent, ahora)
        cur.execute(
            "UPDATE seg.Usuario SET IntentosFallidos = 0, BloqueadoHasta = NULL, UltimoAcceso = ? "
            "WHERE UsuarioId = ?",
            (ahora, usuario_id),
        )

    _registrar_intento_acceso(cur, username, usuario_id, result.exitoso, result.motivo, ip_address, ahora)
    db.commit()
    return result


def logout(db, sesion_id: str | None, usuario_id: int | None, ip_address: str | None) -> None:
    if not sesion_id or not usuario_id:
        return
    cur = db.cursor()
    ahora = datetime.now()
    cur.execute(
        "UPDATE seg.Sesion SET Activa = 0, FechaCierre = ? WHERE SesionId = ?",
        (ahora, sesion_id),
    )
    cur.execute(
        "INSERT INTO seg.Auditoria (UsuarioId, Accion, Entidad, EntidadId, DireccionIP) "
        "VALUES (?, 'LOGOUT', 'Sesion', ?, ?)",
        (usuario_id, sesion_id, ip_address),
    )
    db.commit()


def validar_sesion(db, sesion_id: str) -> dict | None:
    """Valida un token de sesión y devuelve el contexto del usuario, o None si no es válida."""
    cur = db.cursor()
    cur.execute(
        "SELECT s.UsuarioId, s.Activa, s.FechaExpiracion, u.NombreUsuario, u.NombresCompletos "
        "FROM seg.Sesion s JOIN seg.Usuario u ON u.UsuarioId = s.UsuarioId "
        "WHERE s.SesionId = ? AND u.Activo = 1",
        (sesion_id,),
    )
    row = cur.fetchone()
    if row is None or not row.Activa or row.FechaExpiracion <= datetime.now():
        return None

    permisos, vendedor_id = fetch_permisos_context(cur, row.UsuarioId)
    return {
        "usuario_id": row.UsuarioId,
        "username": row.NombreUsuario,
        "nombres_completos": row.NombresCompletos,
        "roles": fetch_roles(cur, row.UsuarioId),
        "permisos": permisos,
        "vendedor_id": vendedor_id,
    }


def fetch_roles(cur, usuario_id: int) -> list[str]:
    cur.execute(
        "SELECT r.Nombre FROM seg.UsuarioRol ur JOIN seg.Rol r ON r.RolId = ur.RolId "
        "WHERE ur.UsuarioId = ? AND r.Activo = 1",
        (usuario_id,),
    )
    return [r.Nombre for r in cur.fetchall()]


def fetch_permisos_context(cur, usuario_id: int) -> tuple[list[str], int | None]:
    """Equivalente a seg.vw_PermisosUsuario: permisos efectivos + VendedorId
    del usuario (si no es NULL, la app debe filtrar la cartera por ese
    vendedor)."""
    cur.execute(
        "SELECT DISTINCT u.VendedorId, p.Codigo "
        "FROM seg.Usuario u "
        "JOIN seg.UsuarioRol ur ON ur.UsuarioId = u.UsuarioId "
        "JOIN seg.Rol r ON r.RolId = ur.RolId AND r.Activo = 1 "
        "JOIN seg.RolPermiso rp ON rp.RolId = r.RolId "
        "JOIN seg.Permiso p ON p.PermisoId = rp.PermisoId AND p.Activo = 1 "
        "JOIN seg.Modulo m ON m.ModuloId = p.ModuloId AND m.Activo = 1 "
        "WHERE u.UsuarioId = ? AND u.Activo = 1",
        (usuario_id,),
    )
    rows = cur.fetchall()
    permisos = sorted({r.Codigo for r in rows})
    vendedor_id = rows[0].VendedorId if rows else None
    return permisos, vendedor_id


def _registrar_intento_fallido(cur, row, ahora: datetime) -> None:
    intentos = (row.IntentosFallidos or 0) + 1
    bloqueado_hasta = ahora + timedelta(minutes=MINUTOS_BLOQUEO) if intentos >= MAX_INTENTOS else None
    cur.execute(
        "UPDATE seg.Usuario SET IntentosFallidos = ?, BloqueadoHasta = ? WHERE UsuarioId = ?",
        (intentos, bloqueado_hasta, row.UsuarioId),
    )


def _iniciar_sesion(cur, usuario_id: int, ip_address: str | None, user_agent: str | None, ahora: datetime) -> str:
    sesion_id = str(uuid.uuid4())
    expiracion = ahora + timedelta(hours=HORAS_SESION)
    cur.execute(
        "INSERT INTO seg.Sesion (SesionId, UsuarioId, DireccionIP, AgenteUsuario, FechaExpiracion) "
        "VALUES (?, ?, ?, ?, ?)",
        (sesion_id, usuario_id, ip_address, user_agent, expiracion),
    )
    cur.execute(
        "INSERT INTO seg.Auditoria (UsuarioId, Accion, Entidad, EntidadId, DireccionIP) "
        "VALUES (?, 'LOGIN', 'Sesion', ?, ?)",
        (usuario_id, sesion_id, ip_address),
    )
    return sesion_id


def _registrar_intento_acceso(cur, username: str, usuario_id, exitoso: bool, motivo: str, ip_address, ahora: datetime) -> None:
    cur.execute(
        "INSERT INTO seg.IntentoAcceso (NombreUsuario, UsuarioId, Exitoso, Motivo, DireccionIP, Fecha) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (username, usuario_id, exitoso, motivo, ip_address, ahora),
    )
