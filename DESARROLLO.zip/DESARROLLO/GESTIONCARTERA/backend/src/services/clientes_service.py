from src.services.crud_service import serialize_value


def consultar(
    db,
    cliente_id: int | None = None,
    nombre: str | None = None,
    identificacion: str | None = None,
    ciudad_id: int | None = None,
    segmento_riesgo_id: int | None = None,
    clasificacion_id: int | None = None,
    plazo_pago_id: int | None = None,
) -> list[dict]:
    """Invoca dbo.sp_ConsultarClientes con los filtros dados (cualquiera en
    None se traduce a @Parametro = NULL, sin filtrar por esa columna).
    @Nombre busca por coincidencia parcial (LIKE) dentro del procedimiento.

    Enmascaramiento dinámico de datos por rol (sección 11 del manual
    técnico): se ejecuta con la conexión del login del rol en sesión si
    existe una (`db_service.get_db_enmascarado()`) — el procedimiento ya
    funciona con esos logins de solo EXECUTE por encadenamiento de
    propiedad (pertenece a `dbo`, igual que las tablas que consulta), así
    que no hizo falta ningún procedimiento nuevo, a diferencia del CRUD
    genérico de Clientes (`dbo.sp_ConsultarClienteCrud`, sección 11.2).
    Si el rol no tiene login de enmascaramiento asignado, sigue con la
    conexión que recibió (la cuenta de servicio de siempre)."""
    from src.services import db as db_service

    conexion = db_service.get_db_enmascarado() or db
    cur = conexion.cursor()
    cur.execute(
        "EXEC dbo.sp_ConsultarClientes "
        "@ClienteId = ?, @Nombre = ?, @Identificacion = ?, @CiudadId = ?, "
        "@SegmentoRiesgoId = ?, @ClasificacionId = ?, @PlazoPagoId = ?",
        (cliente_id, nombre, identificacion, ciudad_id, segmento_riesgo_id, clasificacion_id, plazo_pago_id),
    )
    columns = [c[0] for c in cur.description]
    return [{col: serialize_value(val) for col, val in zip(columns, row)} for row in cur.fetchall()]


def historial_riesgo(db, cliente_id: int) -> list[dict]:
    """Invoca dbo.sp_ConsultarHistorialRiesgo filtrado por un cliente
    puntual (el procedimiento admite más filtros opcionales, pero esta
    pantalla solo necesita el historial de un cliente a la vez)."""
    cur = db.cursor()
    cur.execute("EXEC dbo.sp_ConsultarHistorialRiesgo @ClienteId = ?", (cliente_id,))
    columns = [c[0] for c in cur.description]
    return [{col: serialize_value(val) for col, val in zip(columns, row)} for row in cur.fetchall()]


def riesgo_actual(db, cliente_id: int) -> dict | None:
    """Segmento de riesgo y clasificación vigentes de un cliente (con sus
    Descripcion de catálogo) más el motivo/fecha de su última entrada en
    dbo.ClienteRiesgoHistorial, para mostrar como mensaje informativo al
    elegir el cliente en el formulario de una nueva factura. Devuelve
    None si el cliente no existe."""
    cur = db.cursor()
    cur.execute(
        """
        SELECT
            c.ClienteId,
            sr.Codigo         AS CodigoSegmento,
            sr.Nombre         AS SegmentoRiesgo,
            sr.Descripcion    AS SegmentoRiesgoDescripcion,
            sr.RequiereGarantia,
            sr.BloqueaVentas,
            cc.Nombre         AS Clasificacion,
            cc.Descripcion    AS ClasificacionDescripcion,
            h.Fecha           AS UltimaActualizacion,
            h.Motivo          AS UltimoMotivo
        FROM dbo.Cliente c
        LEFT JOIN dbo.SegmentoRiesgo sr        ON sr.SegmentoRiesgoId = c.SegmentoRiesgoId
        LEFT JOIN dbo.ClasificacionCliente cc  ON cc.ClasificacionId  = c.ClasificacionId
        OUTER APPLY (
            SELECT TOP 1 h2.Fecha, h2.Motivo
            FROM dbo.ClienteRiesgoHistorial h2
            WHERE h2.ClienteId = c.ClienteId
            ORDER BY h2.Fecha DESC
        ) h
        WHERE c.ClienteId = ?
        """,
        (cliente_id,),
    )
    columns = [c[0] for c in cur.description]
    row = cur.fetchone()
    if row is None:
        return None
    return {col: serialize_value(val) for col, val in zip(columns, row)}
