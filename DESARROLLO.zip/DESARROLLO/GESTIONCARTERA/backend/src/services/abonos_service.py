import re
from datetime import date

import pyodbc

from src.services.crud_service import serialize_value


class ConsultaInvalida(Exception):
    """El procedimiento rechazó los parámetros (RAISERROR): factura vacía,
    inexistente, o número ambiguo entre varios vendedores."""


def _extraer_mensaje_sql(exc: Exception) -> str:
    """Los errores de pyodbc para un RAISERROR de SQL Server tienen la forma
    "...[SQL Server]<mensaje> (<código>) (SQLExecDirectW)"; nos quedamos solo
    con <mensaje> para mostrárselo al usuario."""
    match = re.search(r"\[SQL Server\](.*?)\s*\(\d+\)", str(exc))
    if match:
        return match.group(1).strip()
    return "No se pudo generar el detalle de abonos para esa factura."


def detalle_por_factura(db, numero_factura: str, vendedor_id: int | None = None) -> list[dict]:
    """Invoca dbo.sp_DetalleAbonosFactura. A diferencia de sp_ConsultarAbonos,
    @NumeroFactura es obligatorio y el procedimiento valida con RAISERROR si
    la factura no existe o el número es ambiguo entre varios vendedores."""
    cur = db.cursor()
    try:
        cur.execute(
            "EXEC dbo.sp_DetalleAbonosFactura @NumeroFactura = ?, @VendedorId = ?",
            (numero_factura, vendedor_id),
        )
    except pyodbc.Error as exc:
        raise ConsultaInvalida(_extraer_mensaje_sql(exc)) from exc
    columns = [c[0] for c in cur.description]
    return [{col: serialize_value(val) for col, val in zip(columns, row)} for row in cur.fetchall()]


def facturas_con_saldo(db) -> list[dict]:
    """Invoca dbo.sp_FacturasConSaldo (sin parámetros) para el combo de
    facturas del formulario de nuevo abono. El procedimiento no devuelve
    FacturaId, así que se captura su resultado en una tabla temporal y se
    une contra dbo.Factura (por NumeroFactura + FechaEmision + ValorTotal,
    suficiente para desambiguar entre vendedores) para poder resolverlo."""
    cur = db.cursor()
    cur.execute(
        """
        CREATE TABLE #FacturasConSaldo (
            NumeroFactura VARCHAR(20),
            Vendedor NVARCHAR(120),
            Cliente NVARCHAR(150),
            FechaEmision DATE,
            ValorTotal DECIMAL(12,2),
            TotalPagado DECIMAL(12,2),
            SaldoPendiente DECIMAL(12,2),
            FechaUltimoAbono DATE
        );
        INSERT INTO #FacturasConSaldo
        EXEC dbo.sp_FacturasConSaldo;

        SELECT f.FacturaId, f.VendedorId, s.*
        FROM #FacturasConSaldo s
        JOIN dbo.Factura f
          ON f.NumeroFactura = s.NumeroFactura
         AND f.FechaEmision = s.FechaEmision
         AND f.ValorTotal = s.ValorTotal
        ORDER BY s.SaldoPendiente DESC;

        DROP TABLE #FacturasConSaldo;
        """
    )
    while cur.description is None:
        if not cur.nextset():
            break
    columns = [c[0] for c in cur.description]
    return [{col: serialize_value(val) for col, val in zip(columns, row)} for row in cur.fetchall()]


def estado_cuenta(db, numero_factura: str, vendedor_id: int | None = None) -> dict:
    """Invoca dbo.sp_EstadoCuentaFactura y devuelve solo su primer resultado
    (la cabecera con SaldoActual); el segundo resultset (detalle de abonos)
    no se usa aquí, ya lo cubre detalle_por_factura."""
    cur = db.cursor()
    try:
        cur.execute(
            "EXEC dbo.sp_EstadoCuentaFactura @NumeroFactura = ?, @VendedorId = ?",
            (numero_factura, vendedor_id),
        )
    except pyodbc.Error as exc:
        raise ConsultaInvalida(_extraer_mensaje_sql(exc)) from exc
    columns = [c[0] for c in cur.description]
    row = cur.fetchone()
    return {col: serialize_value(val) for col, val in zip(columns, row)}


def validar_saldo_suficiente(db, factura_id_raw, valor_abono_raw, valor_retencion_raw) -> str | None:
    """Verifica, contra el saldo actualmente almacenado en dbo.Factura
    (columna SaldoPendiente, mantenida por el trigger TR_Abono_ActualizarFactura),
    que el abono a registrar no deje la factura con saldo negativo.

    Se llama antes del INSERT genérico; si FacturaId/ValorAbono no son
    parseables aquí, se deja pasar sin bloquear — la validación genérica de
    campos requeridos/tipo de crud_service.create_row ya lo reporta."""
    try:
        factura_id = int(factura_id_raw)
        valor_abono = float(valor_abono_raw)
    except (TypeError, ValueError):
        return None
    try:
        valor_retencion = float(valor_retencion_raw) if valor_retencion_raw not in (None, "") else 0.0
    except (TypeError, ValueError):
        valor_retencion = 0.0

    cur = db.cursor()
    cur.execute("SELECT NumeroFactura, SaldoPendiente FROM dbo.Factura WHERE FacturaId = ?", (factura_id,))
    row = cur.fetchone()
    if row is None or row.SaldoPendiente is None:
        return None

    total_aplicado = valor_abono + valor_retencion
    saldo = float(row.SaldoPendiente)
    if total_aplicado > saldo:
        return (
            f"El valor abonado ({total_aplicado:.2f}) es mayor al saldo pendiente "
            f"de la factura {row.NumeroFactura} ({saldo:.2f})."
        )
    return None


def consultar(
    db,
    fecha_registro: date | None = None,
    numero_factura: str | None = None,
    abono_id: int | None = None,
    fecha_abono: date | None = None,
    forma_pago_id: int | None = None,
    cliente_id: int | None = None,
    usuario_id: int | None = None,
) -> list[dict]:
    """Invoca dbo.sp_ConsultarAbonos con los filtros dados (cualquiera en
    None se traduce a @Parametro = NULL, sin filtrar por esa columna)."""
    cur = db.cursor()
    cur.execute(
        "EXEC dbo.sp_ConsultarAbonos "
        "@FechaRegistro = ?, @NumeroFactura = ?, @AbonoId = ?, @FechaAbono = ?, "
        "@FormaPagoId = ?, @ClienteId = ?, @UsuarioId = ?",
        (fecha_registro, numero_factura, abono_id, fecha_abono, forma_pago_id, cliente_id, usuario_id),
    )
    columns = [c[0] for c in cur.description]
    return [{col: serialize_value(val) for col, val in zip(columns, row)} for row in cur.fetchall()]
