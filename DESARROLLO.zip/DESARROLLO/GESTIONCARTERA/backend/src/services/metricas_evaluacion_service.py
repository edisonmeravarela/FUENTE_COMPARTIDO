from src.services.crud_service import serialize_value


def _filas(cur) -> list[dict]:
    columnas = [c[0] for c in cur.description]
    return [{col: serialize_value(val) for col, val in zip(columnas, row)} for row in cur.fetchall()]


def _fila(cur) -> dict | None:
    columnas = [c[0] for c in cur.description]
    row = cur.fetchone()
    return {col: serialize_value(val) for col, val in zip(columnas, row)} if row is not None else None


def comparativo_alternativas(db) -> list[dict]:
    """dbo.vw_ComparativoAlternativas: KS/AUC/sensibilidad/precisión/F1/F2
    de cada versión y alternativa entrenada (línea base interpretable —
    regresión logística WOE, la que se sirve— y XGBoost, solo para
    comparar), con el resultado de aceptación de dbo.sp_RegistrarEvaluacion.
    Solo lectura: lo pobla el pipeline de scoring-morosidad al terminar
    cada entrenamiento (src/evaluacion.py), no hay ninguna acción que
    ejecutar desde aquí.

    Hallazgo (no corregible desde este servicio, es un objeto ya
    construido en la base): NumParticiones/DesviacionF1 siempre llegan en
    NULL porque la vista solo cruza dbo.EvaluacionMetrica con
    Origen='VALIDACION', y esas dos columnas solo se llenan en la fila con
    Origen='CROSSVAL' de la misma evaluación (ver la sección de
    validación cruzada del manual técnico)."""
    cur = db.cursor()
    cur.execute("SELECT * FROM dbo.vw_ComparativoAlternativas ORDER BY VersionModelo DESC, Alternativa")
    return _filas(cur)


def desempeno_produccion(db) -> dict | None:
    """dbo.vw_DesempenoProduccion: matriz de confusión real, calculada en
    SQL a partir de las reclasificaciones de dbo.ClienteRiesgoHistorial
    ya vencidas — siempre una sola fila (agregado sin GROUP BY), aunque
    todavía no haya eventos evaluables."""
    cur = db.cursor()
    cur.execute("SELECT * FROM dbo.vw_DesempenoProduccion")
    return _fila(cur)


def declarado_vs_observado(db) -> list[dict]:
    """dbo.vw_DeclaradoVsObservado: contraste, por versión del modelo
    servido, entre la sensibilidad/precisión declaradas en la aceptación
    y las observadas en producción, con el veredicto de tres estados
    (insuficiente / deterioro / conforme)."""
    cur = db.cursor()
    cur.execute("SELECT * FROM dbo.vw_DeclaradoVsObservado ORDER BY VersionModelo DESC")
    return _filas(cur)
