from datetime import date

from src.services.crud_service import serialize_value


def cartera_por_cobrar(
    db,
    numero_factura: str | None = None,
    fecha_emision: date | None = None,
    vendedor_id: int | None = None,
    cliente_id: int | None = None,
    dias: int | None = None,
) -> list[dict]:
    """Invoca dbo.sp_ConsultarFacturasVencidas con los filtros dados
    (cualquiera en None se traduce a @Parametro = NULL, sin filtrar por esa
    columna). Solo devuelve facturas vigentes (no anuladas)."""
    cur = db.cursor()
    cur.execute(
        "EXEC dbo.sp_ConsultarFacturasVencidas "
        "@NumeroFactura = ?, @FechaEmision = ?, @VendedorId = ?, @ClienteId = ?, @Dias = ?",
        (numero_factura, fecha_emision, vendedor_id, cliente_id, dias),
    )
    columns = [c[0] for c in cur.description]
    return [{col: serialize_value(val) for col, val in zip(columns, row)} for row in cur.fetchall()]
