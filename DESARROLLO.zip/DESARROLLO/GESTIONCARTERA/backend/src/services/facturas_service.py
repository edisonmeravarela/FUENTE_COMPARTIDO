from datetime import date

from src.services.crud_service import serialize_value


def consultar(
    db,
    numero_factura: str | None = None,
    fecha_emision: date | None = None,
    vendedor_id: int | None = None,
    cliente_id: int | None = None,
    estado_factura_id: int | None = None,
    plazo_pago_id: int | None = None,
    fecha_vencimiento: date | None = None,
) -> list[dict]:
    """Invoca dbo.sp_ConsultarFacturas con los filtros dados (cualquiera en
    None se traduce a @Parametro = NULL, que el procedimiento ya interpreta
    como "sin filtrar por esta columna")."""
    cur = db.cursor()
    cur.execute(
        "EXEC dbo.sp_ConsultarFacturas "
        "@NumeroFactura = ?, @FechaEmision = ?, @VendedorId = ?, @ClienteId = ?, @EstadoFacturaId = ?, "
        "@PlazoPagoId = ?, @FechaVencimiento = ?",
        (numero_factura, fecha_emision, vendedor_id, cliente_id, estado_factura_id, plazo_pago_id, fecha_vencimiento),
    )
    columns = [c[0] for c in cur.description]
    return [{col: serialize_value(val) for col, val in zip(columns, row)} for row in cur.fetchall()]
