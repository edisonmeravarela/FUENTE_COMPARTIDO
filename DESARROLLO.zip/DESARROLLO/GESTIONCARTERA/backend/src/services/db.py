import pyodbc
from flask import Flask, current_app, g


def _build_conn_str(usuario: str, password: str) -> str:
    cfg = current_app.config
    return (
        f"DRIVER={{{cfg['DB_DRIVER']}}};"
        f"SERVER={cfg['DB_SERVER']};"
        f"DATABASE={cfg['DB_NAME']};"
        f"UID={usuario};"
        f"PWD={password};"
        "TrustServerCertificate=yes;"
    )


def get_db() -> pyodbc.Connection:
    if "db" not in g:
        cfg = current_app.config
        g.db = pyodbc.connect(_build_conn_str(cfg["DB_USER"], cfg["DB_PASSWORD"]), timeout=5)
        g.setdefault("_conexiones_abiertas", []).append(g.db)
    return g.db


# Enmascaramiento dinámico de datos por rol (ddm_gestioncartera_definitivo.sql):
# DDM enmascara según el PRINCIPAL DE BASE DE DATOS que ejecuta la consulta,
# no según seg.Rol — por eso, con la única cuenta de servicio de get_db()
# (hoy `sa`, que además es sysadmin y siempre ve todo sin enmascarar), el
# enmascaramiento nunca tendría efecto. get_db_enmascarado() abre una
# conexión aparte con el login SQL Server propio del rol del usuario en
# sesión — se usa únicamente donde el acceso ya pasa por un procedimiento
# almacenado (dbo.sp_ConsultarClienteCrud, ver crud_service.list_rows/
# get_row), porque esos cuatro logins no tienen ningún permiso directo de
# SELECT/INSERT/UPDATE/DELETE sobre las tablas, solo EXECUTE sobre el
# esquema dbo (y UNMASK, según el rol) — un SELECT directo con ellos falla.
_ROL_A_CONFIG = {
    "ADMINISTRADOR": ("DB_USER_ADMIN", "DB_PASSWORD_ADMIN"),
    "SUPERVISOR DE CARTERA": ("DB_USER_SUPERVISOR", "DB_PASSWORD_SUPERVISOR"),
    "VENDEDOR/COBRADOR": ("DB_USER_COBRADOR", "DB_PASSWORD_COBRADOR"),
    "CONSULTA": ("DB_USER_CONSULTA", "DB_PASSWORD_CONSULTA"),
}
# Si un usuario tiene más de un rol asignado, se conecta con el más
# privilegiado de los que tengan login de enmascaramiento — es el mismo
# criterio de "más acceso, no menos" que ya aplica g.roles en el resto
# de la autorización.
_PRIORIDAD_ROLES = ["ADMINISTRADOR", "SUPERVISOR DE CARTERA", "VENDEDOR/COBRADOR", "CONSULTA"]


def _rol_de_enmascaramiento(roles: list[str]) -> str | None:
    for candidato in _PRIORIDAD_ROLES:
        if candidato in roles:
            return candidato
    return None


def get_db_enmascarado() -> pyodbc.Connection | None:
    """Conexión con el login del rol de enmascaramiento del usuario en
    sesión, o None si su rol no tiene uno asignado (p. ej. en las pruebas,
    que no pasan por Flask `g.roles`, o un rol fuera de los cuatro del
    script). El llamador debe usar la conexión de servicio normal en ese
    caso — nunca debe fallar la operación por no poder enmascarar."""
    rol = _rol_de_enmascaramiento(g.get("roles") or [])
    if rol is None:
        return None

    cache_key = f"_db_rol_{rol}"
    if cache_key not in g:
        cfg = current_app.config
        clave_usuario, clave_password = _ROL_A_CONFIG[rol]
        conexion = pyodbc.connect(_build_conn_str(cfg[clave_usuario], cfg[clave_password]), timeout=5)
        setattr(g, cache_key, conexion)
        g.setdefault("_conexiones_abiertas", []).append(conexion)
    return getattr(g, cache_key)


def close_db(e=None) -> None:
    for conexion in g.get("_conexiones_abiertas", []):
        conexion.close()


def init_app(app: Flask) -> None:
    app.teardown_appcontext(close_db)
