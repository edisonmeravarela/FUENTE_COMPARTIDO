from src.services.crud_service import serialize_value


def _filas(cur) -> list[dict]:
    columnas = [c[0] for c in cur.description]
    return [{col: serialize_value(val) for col, val in zip(columnas, row)} for row in cur.fetchall()]


def _fila(cur) -> dict | None:
    columnas = [c[0] for c in cur.description]
    row = cur.fetchone()
    return {col: serialize_value(val) for col, val in zip(columnas, row)} if row is not None else None


def ejecucion_completa(db) -> dict:
    """EXEC dbo.sp_ValidarCalidadDatos (detalle + veredicto): el
    procedimiento devuelve dos result sets — el detalle de los 21
    controles y, a continuación, el veredicto final. Cada ejecución
    inserta esos 21 hallazgos en dbo.ValidacionCalidadDatos, así que se
    confirma la transacción (a diferencia de una simple consulta)."""
    cur = db.cursor()
    cur.execute("EXEC dbo.sp_ValidarCalidadDatos")
    detalle = _filas(cur)
    cur.nextset()
    veredicto = _fila(cur)
    db.commit()
    return {"detalle": detalle, "veredicto": veredicto}


def solo_veredicto(db) -> dict:
    """EXEC dbo.sp_ValidarCalidadDatos @SoloResumen = 1: un único result
    set con el veredicto — la compuerta rápida que usa el pipeline de
    scoring antes de entrenar (src/calidad.py en scoring-morosidad).
    Igual que la ejecución completa, inserta los 21 hallazgos en
    dbo.ValidacionCalidadDatos y por eso confirma la transacción."""
    cur = db.cursor()
    cur.execute("EXEC dbo.sp_ValidarCalidadDatos @SoloResumen = 1")
    veredicto = _fila(cur)
    db.commit()
    return veredicto


def ultima_validacion(db) -> list[dict]:
    """dbo.vw_UltimaValidacion: detalle completo de la ejecución más
    reciente (solo lectura, no inserta nada)."""
    cur = db.cursor()
    cur.execute("SELECT * FROM dbo.vw_UltimaValidacion")
    return _filas(cur)


def evolucion(db) -> list[dict]:
    """Conteo de hallazgos CRÍTICO por fecha y dimensión, para ver cómo
    evoluciona la calidad de los datos entre ejecuciones sucesivas
    (solo lectura, no inserta nada)."""
    cur = db.cursor()
    cur.execute(
        """
        SELECT CAST(Fecha AS DATE) AS Fecha, Dimension,
               SUM(CASE WHEN Severidad = 'CRITICO' THEN 1 ELSE 0 END) AS Criticos
        FROM dbo.ValidacionCalidadDatos
        GROUP BY CAST(Fecha AS DATE), Dimension
        ORDER BY Fecha DESC
        """
    )
    return _filas(cur)
