from flask import Blueprint, g, jsonify, request

from src.services import db as db_service
from src.services.auth_service import authenticate, logout, mensaje_publico
from src.utils.authz import require_session
from src.utils.http import client_ip

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")


@auth_bp.route("/login", methods=["POST"])
def login():
    payload = request.get_json(silent=True) or {}
    username = payload.get("username", "")
    password = payload.get("password", "")
    result = authenticate(
        db_service.get_db(), username, password, client_ip(), request.headers.get("User-Agent")
    )
    if not result.exitoso:
        return jsonify(mensaje=mensaje_publico(result.motivo)), 401

    return jsonify(
        token=result.sesion_id,
        usuario={
            "id": result.usuario_id,
            "username": result.username,
            "nombres_completos": result.nombres_completos,
            "roles": result.roles,
            "permisos": result.permisos,
            "vendedor_id": result.vendedor_id,
            "debe_cambiar_clave": result.debe_cambiar_clave,
        },
    ), 200


@auth_bp.route("/logout", methods=["POST"])
@require_session
def logout_route():
    logout(db_service.get_db(), g.token, g.usuario_id, client_ip())
    return "", 204
