from flask import Blueprint, jsonify, request

from src.services import db as db_service
from src.services import reportes_service
from src.utils.authz import require_permiso
from src.utils.query_params import parse_date, parse_int

reportes_bp = Blueprint("reportes", __name__, url_prefix="/api/reportes")


@reportes_bp.route("/cartera-por-cobrar", methods=["GET"])
@require_permiso("REPORTES.CARTERA_VENCIDA")
def cartera_por_cobrar():
    filas = reportes_service.cartera_por_cobrar(
        db_service.get_db(),
        numero_factura=request.args.get("NumeroFactura") or None,
        fecha_emision=parse_date(request.args.get("FechaEmision")),
        vendedor_id=parse_int(request.args.get("VendedorId")),
        cliente_id=parse_int(request.args.get("ClienteId")),
        dias=parse_int(request.args.get("Dias")),
    )
    return jsonify(filas)
