from flask import Blueprint, g, jsonify, request

from src.services import db as db_service
from src.services import seguridad_service
from src.services.crud_service import ConflictError, ValidationError
from src.utils.authz import require_permiso

seguridad_bp = Blueprint("seguridad", __name__, url_prefix="/api/seguridad")

# Módulo nuevo (no viene de una migración): control exclusivo por permiso
# desde el inicio, sin decorador de transición — SEGURIDAD.* ya está
# asignado solo a ADMINISTRADOR en la base (seg.RolPermiso), reforzado
# además por el trigger seg.TR_RolPermiso_ProtegerRestringidos.


@seguridad_bp.route("/usuarios", methods=["GET"])
@require_permiso("SEGURIDAD.USUARIOS")
def listar_usuarios():
    return jsonify(seguridad_service.listar_usuarios(db_service.get_db()))


@seguridad_bp.route("/usuarios/<int:usuario_id>", methods=["GET"])
@require_permiso("SEGURIDAD.USUARIOS")
def obtener_usuario(usuario_id):
    usuario = seguridad_service.obtener_usuario(db_service.get_db(), usuario_id)
    if usuario is None:
        return jsonify(error="No encontrado"), 404
    return jsonify(usuario)


@seguridad_bp.route("/usuarios", methods=["POST"])
@require_permiso("SEGURIDAD.USUARIOS")
def crear_usuario():
    payload = request.get_json(silent=True) or {}
    try:
        nuevo_id = seguridad_service.crear_usuario(
            db_service.get_db(), payload, payload.get("Clave", ""), payload.get("Roles", []), g.usuario_id
        )
    except ValidationError as exc:
        return jsonify(errores=exc.errors), 400
    except ConflictError as exc:
        return jsonify(error=str(exc)), 409
    return jsonify({"UsuarioId": nuevo_id}), 201


@seguridad_bp.route("/usuarios/<int:usuario_id>", methods=["PUT"])
@require_permiso("SEGURIDAD.USUARIOS")
def editar_usuario(usuario_id):
    payload = request.get_json(silent=True) or {}
    try:
        ok = seguridad_service.editar_usuario(
            db_service.get_db(), usuario_id, payload, payload.get("Roles", []), g.usuario_id
        )
    except ValidationError as exc:
        return jsonify(errores=exc.errors), 400
    except ConflictError as exc:
        return jsonify(error=str(exc)), 409
    if not ok:
        return jsonify(error="No encontrado"), 404
    return "", 204


@seguridad_bp.route("/usuarios/<int:usuario_id>/clave", methods=["PUT"])
@require_permiso("SEGURIDAD.USUARIOS")
def actualizar_clave(usuario_id):
    payload = request.get_json(silent=True) or {}
    try:
        ok = seguridad_service.actualizar_clave(db_service.get_db(), usuario_id, payload.get("Clave", ""), g.usuario_id)
    except ValidationError as exc:
        return jsonify(errores=exc.errors), 400
    if not ok:
        return jsonify(error="No encontrado"), 404
    return "", 204


@seguridad_bp.route("/usuarios/<int:usuario_id>/estado", methods=["PUT"])
@require_permiso("SEGURIDAD.USUARIOS")
def cambiar_estado_usuario(usuario_id):
    payload = request.get_json(silent=True) or {}
    if "activo" not in payload:
        return jsonify(error="Falta el campo 'activo'."), 400
    ok = seguridad_service.cambiar_estado_usuario(db_service.get_db(), usuario_id, bool(payload["activo"]))
    if not ok:
        return jsonify(error="No encontrado"), 404
    return "", 204


@seguridad_bp.route("/roles", methods=["GET"])
@require_permiso("SEGURIDAD.ROLES")
def listar_roles():
    return jsonify(seguridad_service.listar_roles(db_service.get_db()))


@seguridad_bp.route("/matriz-permisos", methods=["GET"])
@require_permiso("SEGURIDAD.ROLES")
def matriz_permisos():
    return jsonify(seguridad_service.matriz_permisos(db_service.get_db()))


@seguridad_bp.route("/matriz-permisos", methods=["POST"])
@require_permiso("SEGURIDAD.ROLES")
def cambiar_asignacion_permiso():
    payload = request.get_json(silent=True) or {}
    rol_id, permiso_id, asignar = payload.get("rol_id"), payload.get("permiso_id"), payload.get("asignar")
    if rol_id is None or permiso_id is None or asignar is None:
        return jsonify(error="Faltan campos: 'rol_id', 'permiso_id', 'asignar'."), 400

    db = db_service.get_db()
    try:
        if asignar:
            seguridad_service.asignar_permiso(db, rol_id, permiso_id)
        else:
            seguridad_service.revocar_permiso(db, rol_id, permiso_id)
    except seguridad_service.AsignacionRestringidaError as exc:
        return jsonify(error=str(exc)), 409
    return "", 204


@seguridad_bp.route("/auditoria", methods=["GET"])
@require_permiso("SEGURIDAD.AUDITORIA")
def auditoria():
    usuario_id = request.args.get("UsuarioId", type=int)
    accion = request.args.get("Accion") or None
    dias = request.args.get("Dias", type=int)
    return jsonify(seguridad_service.auditoria(db_service.get_db(), usuario_id, accion, dias))


@seguridad_bp.route("/bitacora-autorizacion", methods=["GET"])
@require_permiso("SEGURIDAD.AUDITORIA")
def bitacora_autorizacion():
    return jsonify(seguridad_service.bitacora_autorizacion())
