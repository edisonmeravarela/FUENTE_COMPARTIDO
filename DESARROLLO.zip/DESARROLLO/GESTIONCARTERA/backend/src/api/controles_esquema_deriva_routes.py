from flask import Blueprint, jsonify

from src.services import controles_esquema_deriva_service as service
from src.services import db as db_service
from src.utils.authz import require_permiso_o_rol

controles_esquema_deriva_bp = Blueprint(
    "controles_esquema_deriva", __name__, url_prefix="/api/controles-esquema-deriva"
)

# Migración a control por permiso: validar el esquema es, como
# sp_ValidarCalidadDatos, una compuerta del pipeline (SCORING.CALIDAD);
# medir/consultar la deriva encaja en "Consultar deriva y desempeño del
# modelo" (SCORING.MONITOREAR, el mismo código que metricas_evaluacion_routes.py).
ROLES_RESPALDO = ["ADMINISTRADOR", "SUPERVISOR DE CARTERA"]


@controles_esquema_deriva_bp.route("/validar-esquema", methods=["POST"])
@require_permiso_o_rol("SCORING.CALIDAD", roles=ROLES_RESPALDO)
def validar_esquema():
    return jsonify(service.validar_esquema(db_service.get_db()))


@controles_esquema_deriva_bp.route("/medir-deriva", methods=["POST"])
@require_permiso_o_rol("SCORING.MONITOREAR", roles=ROLES_RESPALDO)
def medir_deriva():
    return jsonify(service.medir_deriva_categorica(db_service.get_db()))


@controles_esquema_deriva_bp.route("/diagnostico-drift", methods=["GET"])
@require_permiso_o_rol("SCORING.MONITOREAR", roles=ROLES_RESPALDO)
def diagnostico_drift():
    return jsonify(service.diagnostico_drift(db_service.get_db()))


@controles_esquema_deriva_bp.route("/diagnostico-drift/<int:medicion_id>/desglose", methods=["GET"])
@require_permiso_o_rol("SCORING.MONITOREAR", roles=ROLES_RESPALDO)
def desglose_por_medicion(medicion_id):
    return jsonify(service.desglose_por_medicion(db_service.get_db(), medicion_id))


@controles_esquema_deriva_bp.route("/evolucion-drift", methods=["GET"])
@require_permiso_o_rol("SCORING.MONITOREAR", roles=ROLES_RESPALDO)
def evolucion_drift():
    return jsonify(service.evolucion_drift(db_service.get_db()))
