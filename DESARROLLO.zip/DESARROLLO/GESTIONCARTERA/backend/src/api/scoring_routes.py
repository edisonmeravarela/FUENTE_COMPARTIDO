from flask import Blueprint, jsonify, request

from src.services import scoring_runner
from src.utils.authz import autorizado_por_permiso_o_rol, require_permiso_o_rol, require_session

scoring_bp = Blueprint("scoring", __name__, url_prefix="/api/scoring-morosidad")

# Migración a control por permiso (Migracion_Control_Por_Permiso.pdf): cada
# comando exige un permiso distinto de dbo/seg.Permiso (módulo SCORING),
# reflejando la separación de consulta/simulación/ejecución/monitoreo que
# el control por rol no distinguía. ROLES_RESPALDO es el decorador de
# transición del paso 4 — se retira en el paso 6, cuando la bitácora
# (logs/autorizacion.log) confirme que ya nadie depende de él.
PERMISO_POR_COMANDO = {
    "entrenar": "SCORING.EJECUTAR",
    "scorear": "SCORING.EJECUTAR",
    "scorear-dry-run": "SCORING.SIMULAR",
    "monitorear": "SCORING.MONITOREAR",
}
# Única decisión que altera el alcance del control por rol (apartado 3 del
# documento): la ejecución real (entrenar/scorear) queda reservada al
# ADMINISTRADOR — el Supervisor conserva la simulación y el monitoreo.
ROLES_RESPALDO_POR_PERMISO = {
    "SCORING.EJECUTAR": ["ADMINISTRADOR"],
    "SCORING.SIMULAR": ["ADMINISTRADOR", "SUPERVISOR DE CARTERA"],
    "SCORING.MONITOREAR": ["ADMINISTRADOR", "SUPERVISOR DE CARTERA"],
}


@scoring_bp.route("/comandos", methods=["GET"])
@require_permiso_o_rol("SCORING.CONSULTAR", roles=["ADMINISTRADOR", "SUPERVISOR DE CARTERA"])
def comandos_disponibles():
    return jsonify(sorted(scoring_runner.COMANDOS))


@scoring_bp.route("/ejecutar", methods=["POST"])
@require_session
def ejecutar():
    payload = request.get_json(silent=True) or {}
    clave = payload.get("comando")
    if not clave:
        return jsonify(error="Falta el campo 'comando'."), 400

    permiso = PERMISO_POR_COMANDO.get(clave)
    if permiso is None:
        return jsonify(error=f"Comando de scoring desconocido: {clave!r}."), 400

    # El permiso exacto a exigir depende del comando concreto del payload
    # (y, para EJECUTAR, de la exclusión del Supervisor), así que la
    # autorización se resuelve aquí y no con un decorador de ruta fijo.
    if not autorizado_por_permiso_o_rol(permiso, roles=ROLES_RESPALDO_POR_PERMISO[permiso]):
        return jsonify(error="No autorizado"), 403

    try:
        resultado = scoring_runner.ejecutar_comando(clave)
    except scoring_runner.ComandoInvalidoError as exc:
        return jsonify(error=str(exc)), 400

    return jsonify(resultado), 200
