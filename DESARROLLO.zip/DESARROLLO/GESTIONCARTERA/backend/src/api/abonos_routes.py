from flask import Blueprint, jsonify, request

from src.services import abonos_service
from src.services import db as db_service
from src.utils.authz import require_permiso
from src.utils.query_params import parse_date, parse_int

abonos_bp = Blueprint("abonos_consulta", __name__, url_prefix="/api/abonos")


@abonos_bp.route("/consultar", methods=["GET"])
@require_permiso("COBRANZA.CONSULTAR")
def consultar():
    filas = abonos_service.consultar(
        db_service.get_db(),
        fecha_registro=parse_date(request.args.get("FechaRegistro")),
        numero_factura=request.args.get("NumeroFactura") or None,
        abono_id=parse_int(request.args.get("AbonoId")),
        fecha_abono=parse_date(request.args.get("FechaAbono")),
        forma_pago_id=parse_int(request.args.get("FormaPagoId")),
        cliente_id=parse_int(request.args.get("ClienteId")),
        usuario_id=parse_int(request.args.get("UsuarioId")),
    )
    return jsonify(filas)


@abonos_bp.route("/detalle-factura", methods=["GET"])
@require_permiso("COBRANZA.CONSULTAR")
def detalle_factura():
    numero_factura = (request.args.get("NumeroFactura") or "").strip()
    if not numero_factura:
        return jsonify(error="Debe ingresar el número de factura."), 400

    try:
        filas = abonos_service.detalle_por_factura(
            db_service.get_db(),
            numero_factura=numero_factura,
            vendedor_id=parse_int(request.args.get("VendedorId")),
        )
    except abonos_service.ConsultaInvalida as exc:
        return jsonify(error=str(exc)), 400

    return jsonify(filas)


@abonos_bp.route("/facturas-con-saldo", methods=["GET"])
@require_permiso("COBRANZA.REGISTRAR_ABONO")
def facturas_con_saldo():
    return jsonify(abonos_service.facturas_con_saldo(db_service.get_db()))


@abonos_bp.route("/estado-cuenta", methods=["GET"])
@require_permiso("COBRANZA.REGISTRAR_ABONO")
def estado_cuenta():
    numero_factura = (request.args.get("NumeroFactura") or "").strip()
    if not numero_factura:
        return jsonify(error="Debe seleccionar una factura."), 400

    try:
        cabecera = abonos_service.estado_cuenta(
            db_service.get_db(),
            numero_factura=numero_factura,
            vendedor_id=parse_int(request.args.get("VendedorId")),
        )
    except abonos_service.ConsultaInvalida as exc:
        return jsonify(error=str(exc)), 400

    return jsonify(cabecera)
