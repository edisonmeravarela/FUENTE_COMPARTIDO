from flask import Blueprint, g, jsonify, request

from src.entities import EntityDef
from src.services import abonos_service, crud_service
from src.services import db as db_service
from src.utils.authz import require_permiso, require_permiso_o_rol, require_rol, require_session
from src.utils.http import client_ip


def _protect(entity: EntityDef, action: str):
    """Elige el decorador de autorización según lo que declare la entidad
    para esa acción (ver src/entities.py):
      - permiso + roles_fallback -> decorador de transición (permiso, con
        el rol como respaldo mientras se confirma que el permiso ya cubre
        todos los casos — migración a control por permiso, paso 4).
      - solo permiso -> control exclusivo por permiso (migración concluida).
      - solo roles_fallback -> control por rol (todavía no migrado).
    """
    codigo = entity.permisos.get(action)
    if codigo and entity.roles_fallback:
        return require_permiso_o_rol(codigo, roles=entity.roles_fallback)
    if codigo:
        return require_permiso(codigo)
    if entity.roles_fallback:
        return require_rol(*entity.roles_fallback)
    return require_session


def make_crud_blueprint(entity: EntityDef) -> Blueprint:
    bp = Blueprint(f"crud_{entity.key}", __name__, url_prefix=f"/api/{entity.key}")

    @bp.route("", methods=["GET"])
    @_protect(entity, "consultar")
    def listar():
        solo_activos = request.args.get("activo") == "1"
        vendedor_id = g.vendedor_id if entity.vendedor_scope_column else None
        return jsonify(
            crud_service.list_rows(db_service.get_db(), entity, vendedor_id=vendedor_id, solo_activos=solo_activos)
        )

    @bp.route("/<int:row_id>", methods=["GET"])
    @_protect(entity, "consultar")
    def obtener(row_id):
        vendedor_id = g.vendedor_id if entity.vendedor_scope_column else None
        row = crud_service.get_row(db_service.get_db(), entity, row_id, vendedor_id=vendedor_id)
        if row is None:
            return jsonify(error="No encontrado"), 404
        return jsonify(row)

    @bp.route("", methods=["POST"])
    @_protect(entity, "crear")
    def crear():
        payload = request.get_json(silent=True) or {}
        if entity.key == "abonos":
            mensaje = abonos_service.validar_saldo_suficiente(
                db_service.get_db(), payload.get("FacturaId"), payload.get("ValorAbono"), payload.get("ValorRetencion")
            )
            if mensaje:
                return jsonify(errores={"ValorAbono": mensaje}), 400
        try:
            new_id = crud_service.create_row(db_service.get_db(), entity, payload, g.usuario_id, client_ip())
        except crud_service.ValidationError as exc:
            return jsonify(errores=exc.errors), 400
        except crud_service.ConflictError as exc:
            return jsonify(error=str(exc)), 409
        return jsonify({entity.pk: new_id}), 201

    @bp.route("/<int:row_id>", methods=["PUT"])
    @_protect(entity, "editar")
    def editar(row_id):
        payload = request.get_json(silent=True) or {}
        try:
            ok = crud_service.update_row(db_service.get_db(), entity, row_id, payload, g.usuario_id, client_ip())
        except crud_service.ValidationError as exc:
            return jsonify(errores=exc.errors), 400
        except crud_service.ConflictError as exc:
            return jsonify(error=str(exc)), 409
        if not ok:
            return jsonify(error="No encontrado"), 404
        return "", 204

    @bp.route("/<int:row_id>", methods=["DELETE"])
    @_protect(entity, "eliminar")
    def eliminar(row_id):
        try:
            ok = crud_service.delete_row(db_service.get_db(), entity, row_id, g.usuario_id, client_ip())
        except crud_service.ConflictError as exc:
            return jsonify(error=str(exc)), 409
        if not ok:
            return jsonify(error="No encontrado"), 404
        return "", 204

    return bp
