from flask import Blueprint, jsonify, request

from src.services import db as db_service
from src.services import facturas_service
from src.utils.authz import require_permiso
from src.utils.query_params import parse_date, parse_int

facturas_bp = Blueprint("facturas_consulta", __name__, url_prefix="/api/facturas")


@facturas_bp.route("/consultar", methods=["GET"])
@require_permiso("FACTURAS.CONSULTAR")
def consultar():
    filas = facturas_service.consultar(
        db_service.get_db(),
        numero_factura=request.args.get("NumeroFactura") or None,
        fecha_emision=parse_date(request.args.get("FechaEmision")),
        vendedor_id=parse_int(request.args.get("VendedorId")),
        cliente_id=parse_int(request.args.get("ClienteId")),
        estado_factura_id=parse_int(request.args.get("EstadoFacturaId")),
        plazo_pago_id=parse_int(request.args.get("PlazoPagoId")),
        fecha_vencimiento=parse_date(request.args.get("FechaVencimiento")),
    )
    return jsonify(filas)
