from flask import Blueprint, jsonify

from src.services import calidad_datos_service
from src.services import db as db_service
from src.utils.authz import require_permiso_o_rol

calidad_datos_bp = Blueprint("calidad_datos", __name__, url_prefix="/api/calidad-datos")

# Migración a control por permiso: SCORING.CALIDAD ("Ejecutar la compuerta
# de calidad", seg.Permiso) — decorador de transición, con el rol como
# respaldo hasta confirmar por logs/autorizacion.log que ya no hace falta.
PERMISO = "SCORING.CALIDAD"
ROLES_RESPALDO = ["ADMINISTRADOR", "SUPERVISOR DE CARTERA"]


@calidad_datos_bp.route("/ejecucion-completa", methods=["POST"])
@require_permiso_o_rol(PERMISO, roles=ROLES_RESPALDO)
def ejecucion_completa():
    return jsonify(calidad_datos_service.ejecucion_completa(db_service.get_db()))


@calidad_datos_bp.route("/solo-veredicto", methods=["POST"])
@require_permiso_o_rol(PERMISO, roles=ROLES_RESPALDO)
def solo_veredicto():
    return jsonify(calidad_datos_service.solo_veredicto(db_service.get_db()))


@calidad_datos_bp.route("/ultima-validacion", methods=["GET"])
@require_permiso_o_rol(PERMISO, roles=ROLES_RESPALDO)
def ultima_validacion():
    return jsonify(calidad_datos_service.ultima_validacion(db_service.get_db()))


@calidad_datos_bp.route("/evolucion", methods=["GET"])
@require_permiso_o_rol(PERMISO, roles=ROLES_RESPALDO)
def evolucion():
    return jsonify(calidad_datos_service.evolucion(db_service.get_db()))
