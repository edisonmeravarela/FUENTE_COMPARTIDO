from flask import Blueprint, jsonify

from src.services import crud_service
from src.services import db as db_service
from src.utils.authz import require_session

lookup_bp = Blueprint("lookup", __name__, url_prefix="/api")


@lookup_bp.route("/ciudades", methods=["GET"])
@require_session
def ciudades():
    return jsonify(crud_service.lookup_rows(db_service.get_db(), "dbo.Ciudad", "CiudadId", "Nombre"))


@lookup_bp.route("/formas-pago", methods=["GET"])
@require_session
def formas_pago():
    return jsonify(crud_service.lookup_rows(db_service.get_db(), "dbo.FormaPago", "FormaPagoId", "Descripcion"))


@lookup_bp.route("/segmentos-riesgo", methods=["GET"])
@require_session
def segmentos_riesgo():
    return jsonify(
        crud_service.lookup_rows(
            db_service.get_db(),
            "dbo.SegmentoRiesgo",
            "SegmentoRiesgoId",
            "Codigo + ' - ' + Nombre",
            order_by="Orden",
            solo_activos=True,
        )
    )


@lookup_bp.route("/clasificaciones-cliente", methods=["GET"])
@require_session
def clasificaciones_cliente():
    return jsonify(
        crud_service.lookup_rows(
            db_service.get_db(),
            "dbo.ClasificacionCliente",
            "ClasificacionId",
            "Codigo + ' - ' + Nombre",
            order_by="Orden",
            solo_activos=True,
        )
    )


@lookup_bp.route("/estados-factura", methods=["GET"])
@require_session
def estados_factura():
    return jsonify(
        crud_service.lookup_rows(
            db_service.get_db(),
            "dbo.EstadoFactura",
            "EstadoFacturaId",
            "Codigo + ' - ' + Nombre",
            order_by="EstadoFacturaId",
            solo_activos=True,
        )
    )


@lookup_bp.route("/usuarios", methods=["GET"])
@require_session
def usuarios():
    return jsonify(
        crud_service.lookup_rows(
            db_service.get_db(),
            "seg.Usuario",
            "UsuarioId",
            "NombreUsuario + ' - ' + NombresCompletos",
            order_by="NombresCompletos",
            solo_activos=True,
        )
    )


@lookup_bp.route("/plazos-pago", methods=["GET"])
@require_session
def plazos_pago():
    return jsonify(
        crud_service.lookup_rows(
            db_service.get_db(),
            "dbo.PlazoPago",
            "PlazoPagoId",
            "Nombre",
            order_by="Dias",
            solo_activos=True,
            extra_column="Dias",
            extra_alias="dias",
        )
    )
