from flask import Blueprint, jsonify, request

from src.services import clientes_service
from src.services import db as db_service
from src.utils.authz import require_permiso
from src.utils.query_params import parse_int

clientes_bp = Blueprint("clientes_consulta", __name__, url_prefix="/api/clientes")


@clientes_bp.route("/consultar", methods=["GET"])
@require_permiso("CLIENTES.CONSULTAR")
def consultar():
    filas = clientes_service.consultar(
        db_service.get_db(),
        cliente_id=parse_int(request.args.get("ClienteId")),
        nombre=request.args.get("Nombre") or None,
        identificacion=request.args.get("Identificacion") or None,
        ciudad_id=parse_int(request.args.get("CiudadId")),
        segmento_riesgo_id=parse_int(request.args.get("SegmentoRiesgoId")),
        clasificacion_id=parse_int(request.args.get("ClasificacionId")),
        plazo_pago_id=parse_int(request.args.get("PlazoPagoId")),
    )
    return jsonify(filas)


@clientes_bp.route("/historial-riesgo", methods=["GET"])
@require_permiso("CLIENTES.CONSULTAR")
def historial_riesgo():
    cliente_id = parse_int(request.args.get("ClienteId"))
    if not cliente_id:
        return jsonify(error="Falta el parámetro ClienteId."), 400
    filas = clientes_service.historial_riesgo(db_service.get_db(), cliente_id)
    return jsonify(filas)


@clientes_bp.route("/riesgo-actual", methods=["GET"])
@require_permiso("FACTURAS.CONSULTAR")
def riesgo_actual():
    cliente_id = parse_int(request.args.get("ClienteId"))
    if not cliente_id:
        return jsonify(error="Falta el parámetro ClienteId."), 400
    info = clientes_service.riesgo_actual(db_service.get_db(), cliente_id)
    if info is None:
        return jsonify(error="No existe el cliente."), 404
    return jsonify(info)
