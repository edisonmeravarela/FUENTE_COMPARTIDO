from flask import Blueprint, jsonify

from src.services import metricas_evaluacion_service as service
from src.services import db as db_service
from src.utils.authz import require_permiso_o_rol

metricas_evaluacion_bp = Blueprint("metricas_evaluacion", __name__, url_prefix="/api/metricas-evaluacion")

# Migración a control por permiso: SCORING.MONITOREAR ("Consultar deriva y
# desempeño del modelo", seg.Permiso) — mismo código que las lecturas de
# deriva en controles_esquema_deriva_routes.py.
PERMISO = "SCORING.MONITOREAR"
ROLES_RESPALDO = ["ADMINISTRADOR", "SUPERVISOR DE CARTERA"]


@metricas_evaluacion_bp.route("/comparativo-alternativas", methods=["GET"])
@require_permiso_o_rol(PERMISO, roles=ROLES_RESPALDO)
def comparativo_alternativas():
    return jsonify(service.comparativo_alternativas(db_service.get_db()))


@metricas_evaluacion_bp.route("/desempeno-produccion", methods=["GET"])
@require_permiso_o_rol(PERMISO, roles=ROLES_RESPALDO)
def desempeno_produccion():
    return jsonify(service.desempeno_produccion(db_service.get_db()))


@metricas_evaluacion_bp.route("/declarado-vs-observado", methods=["GET"])
@require_permiso_o_rol(PERMISO, roles=ROLES_RESPALDO)
def declarado_vs_observado():
    return jsonify(service.declarado_vs_observado(db_service.get_db()))
