from dataclasses import dataclass, field


@dataclass
class FieldDef:
    column: str
    label: str
    type: str  # text | number | decimal | date | checkbox | select
    required: bool = False
    fk_lookup: str | None = None  # clave en ENTITIES o LOOKUPS que provee las opciones
    editable: bool = True  # False para columnas que solo cambian vía una acción (p.ej. EstadoFacturaId)
    default: object = None  # valor si el campo queda vacío y no es requerido (p.ej. columnas NOT NULL con default en la BD)


@dataclass
class EntityDef:
    key: str  # usado en la URL: /api/<key>
    table: str  # tabla real, p.ej. "dbo.Cliente"
    pk: str
    label: str
    fields: list[FieldDef]
    # (columna, valor_activo, valor_inactivo) o None si el DELETE es físico
    soft_delete: tuple[str, object, object] | None = None
    # Accion registrada en seg.Auditoria para el soft-delete; debe estar en
    # el CHECK constraint CK_Auditoria_Accion (INSERT/UPDATE/DELETE/ANULAR/LOGIN/LOGOUT)
    soft_delete_accion: str = "UPDATE"
    # acción -> código de seg.Permiso, o None si se usa roles_fallback
    permisos: dict[str, str | None] = field(default_factory=dict)
    # roles habilitados cuando la acción no tiene permiso puntual
    roles_fallback: list[str] | None = None
    # columna por la que se filtra la cartera de un usuario-vendedor (VendedorId)
    vendedor_scope_column: str | None = None
    # (tabla_dependiente, columna_fk, mensaje) — antes de eliminar/anular se
    # verifica que no existan filas dependientes; si existen, se bloquea con
    # este mensaje en vez del genérico de conflicto.
    dependency_check: tuple[str, str, str] | None = None
    # columna que crud_service.create_row llena con el UsuarioId de la
    # sesión que graba el registro (p.ej. "UsuarioId" en Abono); None si la
    # entidad no registra quién la creó.
    usuario_column: str | None = None
    # Procedimiento almacenado (p.ej. "dbo.sp_ConsultarClienteCrud") que
    # list_rows/get_row usan en vez de un SELECT dinámico contra `table`,
    # con la firma (@Id INT = NULL, @SoloActivos BIT = 0) y devolviendo
    # exactamente las columnas pk + fields. Necesario para que el
    # enmascaramiento dinámico de datos por rol (DDM) tenga efecto: los
    # logins de enmascaramiento no tienen SELECT directo, solo EXECUTE
    # sobre el esquema — ver src/services/db.get_db_enmascarado(). None
    # (el valor por defecto) mantiene el SELECT dinámico de siempre.
    read_procedure: str | None = None


ENTITIES: dict[str, EntityDef] = {
    "vendedores": EntityDef(
        key="vendedores",
        table="dbo.Vendedor",
        pk="VendedorId",
        label="Vendedores",
        fields=[
            FieldDef("Nombres", "Nombres", "text", required=True),
            FieldDef("Telefono", "Teléfono", "text"),
            FieldDef("PorcComision", "% Comisión", "decimal", default=0),
            FieldDef("Activo", "Activo", "checkbox"),
        ],
        soft_delete=("Activo", 1, 0),
        # Migración a control por permiso (Migracion_Control_Por_Permiso.pdf,
        # paso 4): decorador de transición — permiso definitivo, rol como
        # respaldo hasta confirmar por bitácora (logs/autorizacion.log) que
        # ningún acceso real depende ya de él (paso 6, luego se retira
        # roles_fallback).
        permisos={
            "consultar": "VENDEDORES.CONSULTAR",
            "crear": "VENDEDORES.CREAR",
            "editar": "VENDEDORES.EDITAR",
            "eliminar": "VENDEDORES.INACTIVAR",
        },
        roles_fallback=["ADMINISTRADOR", "SUPERVISOR DE CARTERA"],
    ),
    "clientes": EntityDef(
        key="clientes",
        table="dbo.Cliente",
        pk="ClienteId",
        label="Clientes",
        fields=[
            FieldDef("NombreCompleto", "Nombre completo", "text", required=True),
            FieldDef("Identificacion", "Identificación", "text"),
            FieldDef("Direccion", "Dirección", "text"),
            FieldDef("CiudadId", "Ciudad", "select", fk_lookup="ciudades"),
            FieldDef("Telefono", "Teléfono", "text"),
            FieldDef("SegmentoRiesgoId", "Segmento de riesgo", "select", fk_lookup="segmentos-riesgo"),
            FieldDef("ClasificacionId", "Clasificación", "select", fk_lookup="clasificaciones-cliente"),
            FieldDef("PlazoPagoId", "Plazo de pago", "select", fk_lookup="plazos-pago"),
            FieldDef("LimiteCreditoPersonal", "Límite de crédito personal", "decimal"),
            FieldDef("Activo", "Activo", "checkbox"),
        ],
        soft_delete=("Activo", 1, 0),
        # Enmascaramiento dinámico de datos por rol (ddm_gestioncartera_definitivo.sql).
        read_procedure="dbo.sp_ConsultarClienteCrud",
        permisos={
            "consultar": "CLIENTES.CONSULTAR",
            "crear": "CLIENTES.CREAR",
            "editar": "CLIENTES.EDITAR",
            "eliminar": "CLIENTES.INACTIVAR",
        },
    ),
    "facturas": EntityDef(
        key="facturas",
        table="dbo.Factura",
        pk="FacturaId",
        label="Facturas",
        fields=[
            FieldDef("NumeroFactura", "Número de factura", "text", required=True),
            FieldDef("VendedorId", "Vendedor", "select", required=True, fk_lookup="vendedores"),
            FieldDef("ClienteId", "Cliente", "select", required=True, fk_lookup="clientes"),
            FieldDef("FechaEmision", "Fecha de emisión", "date", required=True),
            FieldDef("PlazoPagoId", "Plazo de pago", "select", fk_lookup="plazos-pago"),
            FieldDef("FechaVencimiento", "Fecha de vencimiento", "date"),
            FieldDef("ValorTotal", "Valor total", "decimal", required=True),
            FieldDef("Observaciones", "Observaciones", "text"),
            FieldDef("EstadoFacturaId", "Estado", "number", editable=False),
        ],
        # 1 = PENDIENTE (dbo.EstadoFactura); crud_service.create_row lo asigna
        # automáticamente a las facturas nuevas. 3 = ANULADA, usado por
        # delete_row para "eliminar" (soft-delete) una factura.
        soft_delete=("EstadoFacturaId", 1, 3),
        soft_delete_accion="ANULAR",
        permisos={
            "consultar": "FACTURAS.CONSULTAR",
            "crear": "FACTURAS.CREAR",
            "editar": "FACTURAS.EDITAR",
            "eliminar": "FACTURAS.ANULAR",
        },
        vendedor_scope_column="VendedorId",
        dependency_check=(
            "dbo.Abono",
            "FacturaId",
            "No se puede eliminar la factura: tiene abonos registrados.",
        ),
    ),
    "abonos": EntityDef(
        key="abonos",
        table="dbo.Abono",
        pk="AbonoId",
        label="Abonos",
        fields=[
            FieldDef("FacturaId", "Factura", "select", required=True, fk_lookup="facturas"),
            FieldDef("FechaAbono", "Fecha de abono", "date", required=True),
            FieldDef("ValorAbono", "Valor abonado", "decimal", required=True),
            FieldDef("ValorRetencion", "Valor retención", "decimal", default=0),
            FieldDef("FormaPagoId", "Forma de pago", "select", fk_lookup="formas-pago"),
            FieldDef("Observacion", "Observación", "text"),
            FieldDef("UsuarioId", "Usuario", "number", editable=False),
        ],
        soft_delete=None,
        permisos={
            "consultar": "COBRANZA.CONSULTAR",
            "crear": "COBRANZA.REGISTRAR_ABONO",
            "editar": "COBRANZA.EDITAR_ABONO",
            "eliminar": "COBRANZA.ELIMINAR_ABONO",
        },
        # crud_service.create_row lo asigna automáticamente al usuario de la
        # sesión que graba el abono; no es editable desde el formulario.
        usuario_column="UsuarioId",
    ),
    "tipos-gasto": EntityDef(
        key="tipos-gasto",
        table="dbo.TipoGasto",
        pk="TipoGastoId",
        label="Tipos de Gasto",
        fields=[
            FieldDef("Descripcion", "Descripción", "text", required=True),
        ],
        soft_delete=None,
        # Ídem vendedores: decorador de transición (permiso + rol de respaldo).
        permisos={
            "consultar": "TIPOS_GASTO.CONSULTAR",
            "crear": "TIPOS_GASTO.CREAR",
            "editar": "TIPOS_GASTO.EDITAR",
            "eliminar": "TIPOS_GASTO.ELIMINAR",
        },
        roles_fallback=["ADMINISTRADOR", "SUPERVISOR DE CARTERA"],
    ),
    "gastos-vendedor": EntityDef(
        key="gastos-vendedor",
        table="dbo.GastoVendedor",
        pk="GastoId",
        label="Gastos de Vendedor",
        fields=[
            FieldDef("VendedorId", "Vendedor", "select", required=True, fk_lookup="vendedores"),
            FieldDef("FechaGasto", "Fecha del gasto", "date", required=True),
            FieldDef("NumComprobante", "N.º comprobante", "text"),
            FieldDef("TipoGastoId", "Tipo de gasto", "select", fk_lookup="tipos-gasto"),
            FieldDef("Detalle", "Detalle", "text", required=True),
            FieldDef("Valor", "Valor", "decimal", required=True),
        ],
        soft_delete=None,
        permisos={
            "consultar": "GASTOS.CONSULTAR",
            "crear": "GASTOS.REGISTRAR",
            "editar": None,
            "eliminar": None,
        },
        roles_fallback=["ADMINISTRADOR", "SUPERVISOR DE CARTERA"],
        vendedor_scope_column="VendedorId",
    ),
}
