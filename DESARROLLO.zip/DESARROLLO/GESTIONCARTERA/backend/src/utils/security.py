import hashlib
import hmac
import os

_HASH_ALGO = "sha256"
_ITERATIONS = 200_000
_SALT_BYTES = 16


def hash_password(password: str) -> tuple[bytes, bytes]:
    salt = os.urandom(_SALT_BYTES)
    hashed = hashlib.pbkdf2_hmac(_HASH_ALGO, password.encode("utf-8"), salt, _ITERATIONS)
    return hashed, salt


def verify_password(password: str, stored_hash: bytes, salt: bytes) -> bool:
    candidate = hashlib.pbkdf2_hmac(_HASH_ALGO, password.encode("utf-8"), bytes(salt), _ITERATIONS)
    return hmac.compare_digest(candidate, bytes(stored_hash))
