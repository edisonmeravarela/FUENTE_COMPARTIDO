from flask import request


def client_ip() -> str | None:
    """IP real del navegador si el frontend la reenvió (X-Forwarded-For);
    si no, la IP de quien hizo la petición HTTP directa."""
    return request.headers.get("X-Forwarded-For") or request.remote_addr
