import logging
from functools import wraps
from pathlib import Path

from flask import g, jsonify, request

from src.services import db as db_service
from src.services.auth_service import validar_sesion

# Bitácora de autorización — paso 4 de la migración a control por permiso
# (Migracion_Control_Por_Permiso.pdf): mientras conviven permiso y rol de
# respaldo, cada operación autorizada por el decorador de transición deja
# constancia de cuál de los dos criterios la concedió. Es la traza que
# permite comprobar, antes de retirar el respaldo por rol (paso 6), que
# los permisos ya cubren la totalidad de los casos.
_LOGS_DIR = Path(__file__).resolve().parents[2] / "logs"
_LOGS_DIR.mkdir(exist_ok=True)

_logger = logging.getLogger("gestioncartera.autorizacion")
if not _logger.handlers:
    _logger.setLevel(logging.INFO)
    _handler = logging.FileHandler(_LOGS_DIR / "autorizacion.log", encoding="utf-8")
    _handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    _logger.addHandler(_handler)


def _extract_token() -> str | None:
    header = request.headers.get("Authorization", "")
    if header.startswith("Bearer "):
        return header[len("Bearer ") :].strip()
    return None


def require_session(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        token = _extract_token()
        if not token:
            return jsonify(error="No autenticado"), 401

        contexto = validar_sesion(db_service.get_db(), token)
        if contexto is None:
            return jsonify(error="Sesión inválida o expirada"), 401

        g.token = token
        g.usuario_id = contexto["usuario_id"]
        g.username = contexto["username"]
        g.roles = contexto["roles"]
        g.permisos = contexto["permisos"]
        g.vendedor_id = contexto["vendedor_id"]
        return f(*args, **kwargs)

    return wrapper


def require_permiso(codigo: str):
    def decorator(f):
        @wraps(f)
        @require_session
        def wrapper(*args, **kwargs):
            if codigo not in g.permisos:
                return jsonify(error="No autorizado"), 403
            return f(*args, **kwargs)

        return wrapper

    return decorator


def require_rol(*roles: str):
    def decorator(f):
        @wraps(f)
        @require_session
        def wrapper(*args, **kwargs):
            if not set(roles) & set(g.roles):
                return jsonify(error="No autorizado"), 403
            return f(*args, **kwargs)

        return wrapper

    return decorator


def _evaluar_permiso_o_rol(permisos: tuple[str, ...], roles: list[str]) -> str | None:
    """Devuelve el criterio que concedió el acceso ('PERMISO' o 'ROL'), o
    None si ninguno lo hizo. El permiso se evalúa primero: es el criterio
    definitivo, el rol es solo el respaldo de transición."""
    if permisos and set(permisos) & set(g.permisos):
        return "PERMISO"
    if roles and set(roles) & set(g.roles):
        return "ROL"
    return None


def autorizado_por_permiso_o_rol(*permisos: str, roles: list[str] | None = None) -> bool:
    """Para autorizaciones que dependen del contenido de la petición (p.
    ej. el `comando` de POST /api/scoring-morosidad/ejecutar), donde el
    permiso exacto a exigir no se conoce hasta dentro de la propia ruta —
    ahí un decorador de ruta no alcanza. Requiere que `require_session` ya
    haya poblado `g.roles`/`g.permisos` (la ruta debe declarar ese
    decorador, o uno que lo incluya, antes de llamar a esta función)."""
    criterio = _evaluar_permiso_o_rol(permisos, roles or [])
    if criterio:
        _logger.info(
            "Autorizado %s %s por %s (usuario=%s, permisos=%s, roles_respaldo=%s).",
            request.method, request.path, criterio, g.username, permisos, roles or [],
        )
    return criterio is not None


def require_permiso_o_rol(*permisos: str, roles: list[str] | None = None):
    """Decorador de transición (paso 4 de la migración): concede acceso si
    el usuario tiene alguno de `permisos`, o —a falta de eso— pertenece a
    alguno de los `roles` de respaldo. Se retira una vez confirmado, por la
    bitácora, que ningún acceso real depende ya del respaldo por rol (paso
    6: en ese punto se reemplaza por `require_permiso`)."""

    def decorator(f):
        @wraps(f)
        @require_session
        def wrapper(*args, **kwargs):
            if not autorizado_por_permiso_o_rol(*permisos, roles=roles):
                return jsonify(error="No autorizado"), 403
            return f(*args, **kwargs)

        return wrapper

    return decorator
