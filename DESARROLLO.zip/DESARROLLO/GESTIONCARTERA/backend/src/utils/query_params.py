from datetime import date


def parse_int(value: str | None) -> int | None:
    return int(value) if value not in (None, "") else None


def parse_bool(value: str | None) -> bool | None:
    if value in (None, ""):
        return None
    return value in ("1", "true", "True")


def parse_date(value: str | None) -> date | None:
    if value in (None, ""):
        return None
    return date.fromisoformat(value)
