-- Esquema de seguridad (seg) de la base GestionCartera.
-- Documenta/reproduce la estructura que ya existe en el SQL Server local
-- (servidor: localhost, base: GestionCartera). No se ejecuta contra la
-- base actual; sirve para poder recrearla en otro entorno.
-- Ejecutar DESPUÉS de schema_dbo.sql (seg.Usuario referencia dbo.Vendedor).

CREATE SCHEMA seg;
GO

CREATE TABLE seg.Usuario (
    UsuarioId          INT IDENTITY(1,1) NOT NULL,
    NombreUsuario      VARCHAR(50)       NOT NULL,
    Correo             VARCHAR(150)      NOT NULL,
    NombresCompletos   NVARCHAR(150)     NOT NULL,
    ClaveHash          VARBINARY(256)    NOT NULL,
    ClaveSalt          VARBINARY(128)    NOT NULL,
    VendedorId         INT               NULL,
    DebeCambiarClave   BIT               NOT NULL CONSTRAINT DF_Usuario_DebeCambiarClave DEFAULT (1),
    IntentosFallidos   TINYINT           NOT NULL CONSTRAINT DF_Usuario_IntentosFallidos DEFAULT (0),
    BloqueadoHasta     DATETIME2         NULL,
    UltimoAcceso       DATETIME2         NULL,
    Activo             BIT               NOT NULL CONSTRAINT DF_Usuario_Activo DEFAULT (1),
    FechaCreacion      DATETIME2         NOT NULL CONSTRAINT DF_Usuario_FechaCreacion DEFAULT (SYSDATETIME()),
    CreadoPor          INT               NULL,
    CONSTRAINT PK_Usuario PRIMARY KEY (UsuarioId),
    CONSTRAINT UQ_Usuario_Login UNIQUE (NombreUsuario),
    CONSTRAINT UQ_Usuario_Correo UNIQUE (Correo),
    CONSTRAINT FK_Usuario_Vendedor FOREIGN KEY (VendedorId) REFERENCES dbo.Vendedor (VendedorId),
    CONSTRAINT FK_Usuario_CreadoPor FOREIGN KEY (CreadoPor) REFERENCES seg.Usuario (UsuarioId)
);

CREATE TABLE seg.Rol (
    RolId         INT IDENTITY(1,1) NOT NULL,
    Nombre        NVARCHAR(60)      NOT NULL,
    Descripcion   NVARCHAR(250)     NULL,
    Activo        BIT               NOT NULL CONSTRAINT DF_Rol_Activo DEFAULT (1),
    CONSTRAINT PK_Rol PRIMARY KEY (RolId),
    CONSTRAINT UQ_Rol_Nombre UNIQUE (Nombre)
);

CREATE TABLE seg.Modulo (
    ModuloId  INT IDENTITY(1,1) NOT NULL,
    Nombre    NVARCHAR(60)      NOT NULL,
    Icono     VARCHAR(50)       NULL,
    Orden     TINYINT           NOT NULL CONSTRAINT DF_Modulo_Orden DEFAULT (0),
    Activo    BIT               NOT NULL CONSTRAINT DF_Modulo_Activo DEFAULT (1),
    CONSTRAINT PK_Modulo PRIMARY KEY (ModuloId),
    CONSTRAINT UQ_Modulo_Nombre UNIQUE (Nombre)
);

CREATE TABLE seg.Permiso (
    PermisoId     INT IDENTITY(1,1) NOT NULL,
    ModuloId      INT               NOT NULL,
    Codigo        VARCHAR(60)       NOT NULL,
    Nombre        NVARCHAR(100)     NOT NULL,
    Descripcion   NVARCHAR(250)     NULL,
    Activo        BIT               NOT NULL CONSTRAINT DF_Permiso_Activo DEFAULT (1),
    CONSTRAINT PK_Permiso PRIMARY KEY (PermisoId),
    CONSTRAINT UQ_Permiso_Codigo UNIQUE (Codigo),
    CONSTRAINT FK_Permiso_Modulo FOREIGN KEY (ModuloId) REFERENCES seg.Modulo (ModuloId)
);

CREATE TABLE seg.UsuarioRol (
    UsuarioId         INT       NOT NULL,
    RolId             INT       NOT NULL,
    FechaAsignacion   DATETIME2 NOT NULL CONSTRAINT DF_UsuarioRol_Fecha DEFAULT (SYSDATETIME()),
    AsignadoPor       INT       NULL,
    CONSTRAINT PK_UsuarioRol PRIMARY KEY (UsuarioId, RolId),
    CONSTRAINT FK_UsuarioRol_Usuario FOREIGN KEY (UsuarioId) REFERENCES seg.Usuario (UsuarioId),
    CONSTRAINT FK_UsuarioRol_Rol FOREIGN KEY (RolId) REFERENCES seg.Rol (RolId),
    CONSTRAINT FK_UsuarioRol_Asigna FOREIGN KEY (AsignadoPor) REFERENCES seg.Usuario (UsuarioId)
);

CREATE TABLE seg.RolPermiso (
    RolId       INT NOT NULL,
    PermisoId   INT NOT NULL,
    CONSTRAINT PK_RolPermiso PRIMARY KEY (RolId, PermisoId),
    CONSTRAINT FK_RolPermiso_Rol FOREIGN KEY (RolId) REFERENCES seg.Rol (RolId),
    CONSTRAINT FK_RolPermiso_Permiso FOREIGN KEY (PermisoId) REFERENCES seg.Permiso (PermisoId)
);

CREATE TABLE seg.Sesion (
    SesionId          UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_Sesion_Id DEFAULT (NEWID()),
    UsuarioId         INT               NOT NULL,
    TokenRefresco     VARCHAR(500)      NULL,
    DireccionIP       VARCHAR(45)       NULL,
    AgenteUsuario     NVARCHAR(300)     NULL,
    FechaInicio       DATETIME2         NOT NULL CONSTRAINT DF_Sesion_FechaInicio DEFAULT (SYSDATETIME()),
    FechaExpiracion   DATETIME2         NOT NULL,
    FechaCierre       DATETIME2         NULL,
    Activa            BIT               NOT NULL CONSTRAINT DF_Sesion_Activa DEFAULT (1),
    CONSTRAINT PK_Sesion PRIMARY KEY (SesionId),
    CONSTRAINT FK_Sesion_Usuario FOREIGN KEY (UsuarioId) REFERENCES seg.Usuario (UsuarioId)
);

CREATE TABLE seg.IntentoAcceso (
    IntentoId        BIGINT IDENTITY(1,1) NOT NULL,
    NombreUsuario    VARCHAR(50)          NOT NULL,
    UsuarioId        INT                  NULL,
    Exitoso          BIT                  NOT NULL,
    Motivo           NVARCHAR(100)        NULL,
    DireccionIP      VARCHAR(45)          NULL,
    Fecha            DATETIME2            NOT NULL CONSTRAINT DF_IntentoAcceso_Fecha DEFAULT (SYSDATETIME()),
    CONSTRAINT PK_IntentoAcceso PRIMARY KEY (IntentoId),
    CONSTRAINT FK_Intento_Usuario FOREIGN KEY (UsuarioId) REFERENCES seg.Usuario (UsuarioId)
);

CREATE TABLE seg.Auditoria (
    AuditoriaId         BIGINT IDENTITY(1,1) NOT NULL,
    UsuarioId           INT                  NOT NULL,
    Fecha               DATETIME2            NOT NULL CONSTRAINT DF_Auditoria_Fecha DEFAULT (SYSDATETIME()),
    Accion              VARCHAR(20)          NOT NULL,
    Entidad             VARCHAR(60)          NOT NULL,
    EntidadId           VARCHAR(40)          NULL,
    ValoresAnteriores   NVARCHAR(MAX)        NULL,
    ValoresNuevos       NVARCHAR(MAX)        NULL,
    DireccionIP         VARCHAR(45)          NULL,
    CONSTRAINT PK_Auditoria PRIMARY KEY (AuditoriaId),
    CONSTRAINT FK_Auditoria_Usuario FOREIGN KEY (UsuarioId) REFERENCES seg.Usuario (UsuarioId),
    CONSTRAINT CK_Auditoria_Accion CHECK (Accion IN ('LOGIN', 'LOGOUT', 'INSERT', 'UPDATE', 'DELETE', 'ANULAR'))
);
GO

-- La app consulta esta vista al iniciar sesión para armar el menú y
-- validar cada acción. Si VendedorId no es NULL, la app filtra la
-- cartera (facturas/gastos) por ese vendedor.
CREATE VIEW seg.vw_PermisosUsuario
AS
SELECT DISTINCT
    u.UsuarioId,
    u.NombreUsuario,
    u.VendedorId,
    m.Nombre    AS Modulo,
    m.Orden     AS OrdenModulo,
    p.Codigo    AS CodigoPermiso,
    p.Nombre    AS Permiso
FROM seg.Usuario u
JOIN seg.UsuarioRol ur ON ur.UsuarioId = u.UsuarioId
JOIN seg.Rol r         ON r.RolId = ur.RolId AND r.Activo = 1
JOIN seg.RolPermiso rp ON rp.RolId = r.RolId
JOIN seg.Permiso p     ON p.PermisoId = rp.PermisoId AND p.Activo = 1
JOIN seg.Modulo m      ON m.ModuloId = p.ModuloId AND m.Activo = 1
WHERE u.Activo = 1;
GO
