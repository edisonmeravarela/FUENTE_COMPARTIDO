-- Esquema de negocio (dbo) de la base GestionCartera.
-- Documenta/reproduce la estructura que ya existe en el SQL Server local
-- (servidor: localhost, base: GestionCartera). No se ejecuta contra la
-- base actual; sirve para poder recrearla en otro entorno.
-- Ejecutar ANTES de schema_seg.sql (seg.Usuario referencia dbo.Vendedor).

CREATE TABLE dbo.Vendedor (
    VendedorId    INT IDENTITY(1,1) NOT NULL,
    Nombres       NVARCHAR(120)     NOT NULL,
    Telefono      VARCHAR(20)       NULL,
    PorcComision  DECIMAL(5,2)      NOT NULL CONSTRAINT DF_Vendedor_PorcComision DEFAULT (0),
    Activo        BIT               NOT NULL CONSTRAINT DF_Vendedor_Activo DEFAULT (1),
    CONSTRAINT PK_Vendedor PRIMARY KEY (VendedorId)
);

CREATE TABLE dbo.Ciudad (
    CiudadId   INT IDENTITY(1,1) NOT NULL,
    Nombre     NVARCHAR(80)      NOT NULL,
    Provincia  NVARCHAR(80)      NULL,
    CONSTRAINT PK_Ciudad PRIMARY KEY (CiudadId),
    CONSTRAINT UQ_Ciudad_Nombre UNIQUE (Nombre)
);

CREATE TABLE dbo.SegmentoRiesgo (
    SegmentoRiesgoId  TINYINT IDENTITY(1,1) NOT NULL,
    Codigo            VARCHAR(10)           NOT NULL,
    Nombre            NVARCHAR(60)          NOT NULL,
    Descripcion       NVARCHAR(300)         NULL,
    LimiteCredito     DECIMAL(12,2)         NULL,
    DiasMaxMora       SMALLINT              NULL,
    RequiereGarantia  BIT                   NOT NULL CONSTRAINT DF_SegmentoRiesgo_Garantia DEFAULT (0),
    BloqueaVentas     BIT                   NOT NULL CONSTRAINT DF_SegmentoRiesgo_Bloquea DEFAULT (0),
    Orden             TINYINT               NULL,
    Activo            BIT                   NOT NULL CONSTRAINT DF_SegmentoRiesgo_Activo DEFAULT (1),
    CONSTRAINT PK_SegmentoRiesgo PRIMARY KEY (SegmentoRiesgoId)
);

CREATE TABLE dbo.ClasificacionCliente (
    ClasificacionId    TINYINT IDENTITY(1,1) NOT NULL,
    Codigo             VARCHAR(5)            NOT NULL,
    Nombre             NVARCHAR(60)          NOT NULL,
    Descripcion        NVARCHAR(300)         NULL,
    PorcDescuentoMax   DECIMAL(5,2)          NULL,
    Orden              TINYINT               NULL,
    Activo             BIT                   NOT NULL CONSTRAINT DF_ClasificacionCliente_Activo DEFAULT (1),
    CONSTRAINT PK_ClasificacionCliente PRIMARY KEY (ClasificacionId)
);

CREATE TABLE dbo.PlazoPago (
    PlazoPagoId  TINYINT IDENTITY(1,1) NOT NULL,
    Nombre       NVARCHAR(50)          NOT NULL,
    Dias         SMALLINT              NOT NULL,
    Activo       BIT                   NOT NULL CONSTRAINT DF_PlazoPago_Activo DEFAULT (1),
    CONSTRAINT PK_PlazoPago PRIMARY KEY (PlazoPagoId)
);

CREATE TABLE dbo.Cliente (
    ClienteId              INT IDENTITY(1,1) NOT NULL,
    NombreCompleto         NVARCHAR(150)     NOT NULL,
    Identificacion         VARCHAR(13)       NULL,
    Direccion              NVARCHAR(250)     NULL,
    CiudadId               INT               NULL,
    Telefono               VARCHAR(20)       NULL,
    SegmentoRiesgoId       TINYINT           NULL,
    ClasificacionId        TINYINT           NULL,
    PlazoPagoId            TINYINT           NULL,
    LimiteCreditoPersonal  DECIMAL(12,2)     NULL,
    Activo                 BIT               NOT NULL CONSTRAINT DF_Cliente_Activo DEFAULT (1),
    FechaRegistro          DATETIME2         NOT NULL CONSTRAINT DF_Cliente_FechaRegistro DEFAULT (SYSDATETIME()),
    CONSTRAINT PK_Cliente PRIMARY KEY (ClienteId),
    CONSTRAINT FK_Cliente_Ciudad FOREIGN KEY (CiudadId) REFERENCES dbo.Ciudad (CiudadId),
    CONSTRAINT FK_Cliente_SegmentoRiesgo FOREIGN KEY (SegmentoRiesgoId) REFERENCES dbo.SegmentoRiesgo (SegmentoRiesgoId),
    CONSTRAINT FK_Cliente_Clasificacion FOREIGN KEY (ClasificacionId) REFERENCES dbo.ClasificacionCliente (ClasificacionId),
    CONSTRAINT FK_Cliente_PlazoPago FOREIGN KEY (PlazoPagoId) REFERENCES dbo.PlazoPago (PlazoPagoId)
);

CREATE TABLE dbo.ClienteTelefono (
    ClienteTelefonoId  INT IDENTITY(1,1) NOT NULL,
    ClienteId          INT               NOT NULL,
    Telefono           VARCHAR(20)       NOT NULL,
    Observacion        NVARCHAR(100)     NULL,
    CONSTRAINT PK_ClienteTelefono PRIMARY KEY (ClienteTelefonoId),
    CONSTRAINT FK_ClienteTelefono_Cliente FOREIGN KEY (ClienteId) REFERENCES dbo.Cliente (ClienteId)
);

CREATE TABLE dbo.FormaPago (
    FormaPagoId   TINYINT IDENTITY(1,1) NOT NULL,
    Descripcion   NVARCHAR(50)          NOT NULL,
    CONSTRAINT PK_FormaPago PRIMARY KEY (FormaPagoId),
    CONSTRAINT UQ_FormaPago UNIQUE (Descripcion)
);

CREATE TABLE dbo.TipoGasto (
    TipoGastoId  TINYINT IDENTITY(1,1) NOT NULL,
    Descripcion  NVARCHAR(60)          NOT NULL,
    CONSTRAINT PK_TipoGasto PRIMARY KEY (TipoGastoId),
    CONSTRAINT UQ_TipoGasto UNIQUE (Descripcion)
);

CREATE TABLE dbo.EstadoFactura (
    EstadoFacturaId  TINYINT IDENTITY(1,1) NOT NULL,
    Codigo           VARCHAR(20)           NOT NULL,
    Nombre           NVARCHAR(60)          NOT NULL,
    Activo           BIT                   NOT NULL CONSTRAINT DF_EstadoFactura_Activo DEFAULT (1),
    CONSTRAINT PK_EstadoFactura PRIMARY KEY (EstadoFacturaId)
);
-- Filas: 1=PENDIENTE, 2=CANCELADA, 3=ANULADA.

CREATE TABLE dbo.Factura (
    FacturaId         INT IDENTITY(1,1) NOT NULL,
    NumeroFactura     VARCHAR(20)       NOT NULL,
    VendedorId        INT               NOT NULL,
    ClienteId         INT               NOT NULL,
    FechaEmision      DATE              NOT NULL,
    PlazoPagoId       TINYINT           NULL,
    FechaVencimiento  DATE              NULL,
    ValorTotal        DECIMAL(12,2)     NOT NULL,
    Observaciones     NVARCHAR(500)     NULL,
    -- TotalAbonado/FechaUltimoPago/SaldoPendiente y el EstadoFacturaId
    -- resultante se mantienen automáticamente vía TR_Abono_ActualizarFactura
    -- (trigger en dbo.Abono) cada vez que se inserta/edita/borra un abono.
    TotalAbonado      DECIMAL(12,2)     NOT NULL CONSTRAINT DF_Factura_TotalAbonado DEFAULT (0),
    FechaUltimoPago   DATE              NULL,
    SaldoPendiente    DECIMAL(12,2)     NULL,
    EstadoFacturaId   TINYINT           NOT NULL,
    FechaRegistro     DATETIME2         NOT NULL CONSTRAINT DF_Factura_FechaRegistro DEFAULT (SYSDATETIME()),
    CONSTRAINT PK_Factura PRIMARY KEY (FacturaId),
    CONSTRAINT FK_Factura_Vendedor FOREIGN KEY (VendedorId) REFERENCES dbo.Vendedor (VendedorId),
    CONSTRAINT FK_Factura_Cliente FOREIGN KEY (ClienteId) REFERENCES dbo.Cliente (ClienteId),
    CONSTRAINT FK_Factura_PlazoPago FOREIGN KEY (PlazoPagoId) REFERENCES dbo.PlazoPago (PlazoPagoId),
    CONSTRAINT UQ_Factura_NumVendedor UNIQUE (NumeroFactura, VendedorId)
);

CREATE TABLE dbo.Abono (
    AbonoId          INT IDENTITY(1,1) NOT NULL,
    FacturaId        INT               NOT NULL,
    FechaAbono       DATE              NOT NULL,
    ValorAbono       DECIMAL(12,2)     NOT NULL,
    ValorRetencion   DECIMAL(12,2)     NOT NULL CONSTRAINT DF_Abono_ValorRetencion DEFAULT (0),
    FormaPagoId      TINYINT           NULL,
    Observacion      NVARCHAR(300)     NULL,
    FechaRegistro    DATETIME2         NOT NULL CONSTRAINT DF_Abono_FechaRegistro DEFAULT (SYSDATETIME()),
    CONSTRAINT PK_Abono PRIMARY KEY (AbonoId),
    CONSTRAINT FK_Abono_Factura FOREIGN KEY (FacturaId) REFERENCES dbo.Factura (FacturaId),
    CONSTRAINT FK_Abono_FormaPago FOREIGN KEY (FormaPagoId) REFERENCES dbo.FormaPago (FormaPagoId)
);

CREATE TABLE dbo.GastoVendedor (
    GastoId         INT IDENTITY(1,1) NOT NULL,
    VendedorId      INT               NOT NULL,
    FechaGasto      DATE              NOT NULL,
    NumComprobante  VARCHAR(20)       NULL,
    TipoGastoId     TINYINT           NULL,
    Detalle         NVARCHAR(200)     NOT NULL,
    Valor           DECIMAL(10,2)     NOT NULL,
    CONSTRAINT PK_GastoVendedor PRIMARY KEY (GastoId),
    CONSTRAINT FK_Gasto_Vendedor FOREIGN KEY (VendedorId) REFERENCES dbo.Vendedor (VendedorId),
    CONSTRAINT FK_Gasto_Tipo FOREIGN KEY (TipoGastoId) REFERENCES dbo.TipoGasto (TipoGastoId)
);
GO

CREATE VIEW dbo.vw_CarteraPorCobrar
AS
SELECT
    f.FacturaId,
    f.NumeroFactura,
    v.Nombres                                   AS Vendedor,
    c.NombreCompleto                            AS Cliente,
    ci.Nombre                                   AS Ciudad,
    c.Telefono,
    f.FechaEmision,
    f.ValorTotal,
    f.TotalAbonado,
    f.SaldoPendiente,
    f.FechaUltimoPago                           AS FechaUltimoAbono,
    DATEDIFF(DAY, f.FechaEmision, f.FechaUltimoPago)       AS DiasEmisionUltimoAbono,
    DATEDIFF(DAY, f.FechaEmision, CAST(GETDATE() AS DATE)) AS DiasEmisionHoy,
    ef.Codigo                                   AS Estado,
    f.Observaciones
FROM dbo.Factura f
JOIN dbo.Vendedor v      ON v.VendedorId      = f.VendedorId
JOIN dbo.Cliente  c      ON c.ClienteId       = f.ClienteId
JOIN dbo.EstadoFactura ef ON ef.EstadoFacturaId = f.EstadoFacturaId
LEFT JOIN dbo.Ciudad ci  ON ci.CiudadId       = c.CiudadId;
GO

-- Recaudos por mes + comisión del vendedor (columna COMISION del archivo de Freddy)
CREATE VIEW dbo.vw_RecaudosPorMes
AS
SELECT
    v.VendedorId,
    v.Nombres                                   AS Vendedor,
    YEAR(a.FechaAbono)                          AS Anio,
    MONTH(a.FechaAbono)                         AS Mes,
    SUM(a.ValorAbono)                           AS TotalRecaudado,
    SUM(a.ValorRetencion)                       AS TotalRetenciones,
    CAST(SUM(a.ValorAbono) * v.PorcComision / 100.0 AS DECIMAL(12,2)) AS ComisionCalculada
FROM dbo.Abono a
JOIN dbo.Factura f  ON f.FacturaId  = a.FacturaId
JOIN dbo.Vendedor v ON v.VendedorId = f.VendedorId
GROUP BY v.VendedorId, v.Nombres, v.PorcComision, YEAR(a.FechaAbono), MONTH(a.FechaAbono);
GO

-- Ventas por mes y vendedor: reemplaza los cortes mensuales "VENTAS MES ... DE ..."
CREATE VIEW dbo.vw_VentasPorMes
AS
SELECT
    v.VendedorId,
    v.Nombres                       AS Vendedor,
    YEAR(f.FechaEmision)            AS Anio,
    MONTH(f.FechaEmision)           AS Mes,
    COUNT(*)                        AS NumFacturas,
    SUM(f.ValorTotal)               AS TotalVendido
FROM dbo.Factura f
JOIN dbo.Vendedor v       ON v.VendedorId       = f.VendedorId
JOIN dbo.EstadoFactura ef ON ef.EstadoFacturaId = f.EstadoFacturaId
WHERE ef.Codigo <> 'ANULADA'
GROUP BY v.VendedorId, v.Nombres, YEAR(f.FechaEmision), MONTH(f.FechaEmision);
GO

-- Cartera segmentada por riesgo/clasificación del cliente y tramo de mora
-- respecto a FechaVencimiento (usa las columnas de saldo mantenidas por
-- TR_Abono_ActualizarFactura, no recalcula sumando dbo.Abono).
CREATE VIEW dbo.vw_CarteraRiesgo
AS
SELECT
    f.FacturaId,
    f.NumeroFactura,
    v.Nombres                                       AS Vendedor,
    c.NombreCompleto                                AS Cliente,
    sr.Codigo                                       AS SegmentoRiesgo,
    cc.Codigo                                       AS Clasificacion,
    pp.Nombre                                        AS PlazoPago,
    f.FechaEmision,
    f.FechaVencimiento,
    f.ValorTotal,
    f.SaldoPendiente,
    CASE WHEN f.FechaVencimiento < CAST(GETDATE() AS DATE)
              AND f.SaldoPendiente > 0
         THEN DATEDIFF(DAY, f.FechaVencimiento, CAST(GETDATE() AS DATE))
         ELSE 0
    END                                              AS DiasMora,
    CASE
        WHEN f.SaldoPendiente <= 0 THEN 'SIN SALDO'
        WHEN f.FechaVencimiento >= CAST(GETDATE() AS DATE) THEN 'POR VENCER'
        WHEN DATEDIFF(DAY, f.FechaVencimiento, GETDATE()) <= 30 THEN 'VENCIDA 1-30'
        WHEN DATEDIFF(DAY, f.FechaVencimiento, GETDATE()) <= 60 THEN 'VENCIDA 31-60'
        WHEN DATEDIFF(DAY, f.FechaVencimiento, GETDATE()) <= 90 THEN 'VENCIDA 61-90'
        ELSE 'VENCIDA +90'
    END                                              AS TramoVencimiento
FROM dbo.Factura f
INNER JOIN dbo.Vendedor v      ON v.VendedorId      = f.VendedorId
INNER JOIN dbo.Cliente  c      ON c.ClienteId       = f.ClienteId
INNER JOIN dbo.EstadoFactura ef ON ef.EstadoFacturaId = f.EstadoFacturaId
LEFT  JOIN dbo.SegmentoRiesgo sr       ON sr.SegmentoRiesgoId = c.SegmentoRiesgoId
LEFT  JOIN dbo.ClasificacionCliente cc ON cc.ClasificacionId  = c.ClasificacionId
LEFT  JOIN dbo.PlazoPago pp            ON pp.PlazoPagoId      = f.PlazoPagoId
WHERE ef.Codigo <> 'ANULADA';
GO
