-- Procedimientos almacenados de dbo en GestionCartera.
-- Documenta procedimientos que ya existen en el SQL Server local; no se
-- ejecuta contra la base actual, es para poder recrearla en otro entorno.
-- Ejecutar DESPUÉS de schema_dbo.sql.

CREATE PROCEDURE dbo.sp_ConsultarFacturas
(
    @NumeroFactura     VARCHAR(20)   = NULL,
    @FechaEmision      DATE          = NULL,
    @VendedorId        INT           = NULL,
    @ClienteId         INT           = NULL,
    @EstadoFacturaId   TINYINT       = NULL,
    @PlazoPagoId       TINYINT       = NULL,
    @FechaVencimiento  DATE          = NULL
)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        f.FacturaId,
        f.NumeroFactura,
        f.FechaEmision,
        v.Nombres           AS NombreVendedor,
        c.NombreCompleto    AS NombreCliente,
        f.ValorTotal,
        f.TotalAbonado,
        f.SaldoPendiente,
        f.FechaUltimoPago,
        ISNULL(pp.Nombre, 'SIN PLAZO')  AS PlazoPago,
        f.FechaVencimiento,
        ef.Nombre            AS Estado,        -- solo la descripción
        f.Observaciones
    FROM dbo.Factura f
    INNER JOIN dbo.Vendedor v ON v.VendedorId = f.VendedorId
    INNER JOIN dbo.Cliente  c ON c.ClienteId  = f.ClienteId
    INNER JOIN dbo.EstadoFactura ef ON ef.EstadoFacturaId = f.EstadoFacturaId
    LEFT  JOIN dbo.PlazoPago pp ON pp.PlazoPagoId = f.PlazoPagoId
    WHERE (@NumeroFactura     IS NULL OR f.NumeroFactura     = @NumeroFactura)
      AND (@FechaEmision      IS NULL OR f.FechaEmision      = @FechaEmision)
      AND (@VendedorId        IS NULL OR f.VendedorId        = @VendedorId)
      AND (@ClienteId         IS NULL OR f.ClienteId         = @ClienteId)
      AND (@EstadoFacturaId   IS NULL OR f.EstadoFacturaId   = @EstadoFacturaId)
      AND (@PlazoPagoId       IS NULL OR f.PlazoPagoId       = @PlazoPagoId)
      AND (@FechaVencimiento  IS NULL OR f.FechaVencimiento  = @FechaVencimiento)
    ORDER BY f.FechaEmision DESC, f.NumeroFactura;
END
GO

CREATE PROCEDURE dbo.sp_ConsultarFacturasVencidas
(
    @NumeroFactura  VARCHAR(20)   = NULL,
    @FechaEmision   DATE          = NULL,
    @VendedorId     INT           = NULL,
    @ClienteId      INT           = NULL,
    @Dias           INT           = NULL
)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Hoy DATE = CAST(GETDATE() AS DATE);

    SELECT
        f.FacturaId,
        f.NumeroFactura,
        f.FechaEmision,
        v.VendedorId        AS CodigoVendedor,
        v.Nombres           AS NombreVendedor,
        c.ClienteId         AS CodigoCliente,
        c.NombreCompleto    AS NombreCliente,
        f.ValorTotal,
        ISNULL(ab.TotalPagado, 0)                       AS TotalPagado,
        f.ValorTotal - ISNULL(ab.TotalPagado, 0)        AS SaldoPendiente,
        ab.FechaUltimoAbono,
        DATEDIFF(DAY, f.FechaEmision, @Hoy)             AS DiasDesdeEmision,
        DATEDIFF(DAY, ab.FechaUltimoAbono, @Hoy)        AS DiasDesdeUltimoAbono,
        f.Observaciones
    FROM dbo.Factura f
    INNER JOIN dbo.Vendedor v ON v.VendedorId = f.VendedorId
    INNER JOIN dbo.Cliente  c ON c.ClienteId  = f.ClienteId
    OUTER APPLY
    (
        SELECT SUM(a.ValorAbono + a.ValorRetencion) AS TotalPagado,
               MAX(a.FechaAbono)                    AS FechaUltimoAbono
        FROM dbo.Abono a
        WHERE a.FacturaId = f.FacturaId
    ) ab
    WHERE f.Anulada = 0                                     -- solo facturas vigentes
      AND (@NumeroFactura IS NULL OR f.NumeroFactura = @NumeroFactura)
      AND (@FechaEmision  IS NULL OR f.FechaEmision  = @FechaEmision)
      AND (@VendedorId    IS NULL OR f.VendedorId    = @VendedorId)
      AND (@ClienteId     IS NULL OR f.ClienteId     = @ClienteId)
      AND (@Dias IS NULL OR DATEDIFF(DAY, f.FechaEmision, @Hoy) > @Dias)
    ORDER BY DiasDesdeEmision DESC, f.NumeroFactura;
END
GO

CREATE PROCEDURE dbo.sp_ConsultarAbonos
(
    @FechaRegistro  DATE          = NULL,
    @NumeroFactura  VARCHAR(20)   = NULL,
    @AbonoId        INT           = NULL,
    @FechaAbono     DATE          = NULL,
    @FormaPagoId    TINYINT       = NULL,
    @ClienteId      INT           = NULL,
    @UsuarioId      INT           = NULL
)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        a.AbonoId,
        f.NumeroFactura,
        c.ClienteId         AS CodigoCliente,
        c.NombreCompleto    AS NombreCliente,
        a.FechaAbono,
        a.ValorAbono,
        a.ValorRetencion,
        a.ValorAbono + a.ValorRetencion         AS TotalAplicado,
        fp.FormaPagoId      AS CodigoFormaPago,
        ISNULL(fp.Descripcion, 'NO REGISTRADA') AS FormaPago,
        a.FechaRegistro,
        ISNULL(u.NombresCompletos, 'NO REGISTRADO')  AS UsuarioRegistro,
        a.Observacion
    FROM dbo.Abono a
    INNER JOIN dbo.Factura f  ON f.FacturaId  = a.FacturaId
    INNER JOIN dbo.Cliente c  ON c.ClienteId  = f.ClienteId
    LEFT  JOIN dbo.FormaPago fp   ON fp.FormaPagoId = a.FormaPagoId
    LEFT  JOIN seg.Usuario   u    ON u.UsuarioId    = a.UsuarioId
    WHERE (@FechaRegistro IS NULL OR CAST(a.FechaRegistro AS DATE) = @FechaRegistro)
      AND (@NumeroFactura IS NULL OR f.NumeroFactura = @NumeroFactura)
      AND (@AbonoId       IS NULL OR a.AbonoId       = @AbonoId)
      AND (@FechaAbono    IS NULL OR a.FechaAbono    = @FechaAbono)
      AND (@FormaPagoId   IS NULL OR a.FormaPagoId   = @FormaPagoId)
      AND (@ClienteId     IS NULL OR c.ClienteId     = @ClienteId)
      AND (@UsuarioId     IS NULL OR a.UsuarioId     = @UsuarioId)
    ORDER BY a.FechaAbono DESC, a.AbonoId DESC;
END
GO

-- @NumeroFactura es obligatorio (sin valor por defecto); valida con
-- RAISERROR si la factura no existe o el número es ambiguo entre varios
-- vendedores (en cuyo caso pide enviar también @VendedorId). Devuelve el
-- detalle de abonos de la factura (con saldo corrido) más una fila final
-- con el saldo actual (Nro = 'TOTAL').
CREATE PROCEDURE dbo.sp_DetalleAbonosFactura
(
    @NumeroFactura  VARCHAR(20),
    @VendedorId     INT = NULL
)
AS
BEGIN
    SET NOCOUNT ON;

    IF @NumeroFactura IS NULL OR LTRIM(RTRIM(@NumeroFactura)) = ''
    BEGIN
        RAISERROR(N'Debe ingresar el número de factura.', 16, 1);
        RETURN;
    END

    DECLARE @Coincidencias INT;
    SELECT @Coincidencias = COUNT(*)
    FROM dbo.Factura
    WHERE NumeroFactura = @NumeroFactura
      AND (@VendedorId IS NULL OR VendedorId = @VendedorId);

    IF @Coincidencias = 0
    BEGIN
        RAISERROR(N'No existe una factura con el número %s.', 16, 1, @NumeroFactura);
        RETURN;
    END

    IF @Coincidencias > 1
    BEGIN
        RAISERROR(N'El número %s existe para más de un vendedor. Envíe también @VendedorId.', 16, 1, @NumeroFactura);
        RETURN;
    END

    DECLARE @FacturaId  INT,
            @ValorTotal DECIMAL(12,2);

    SELECT @FacturaId = FacturaId, @ValorTotal = ValorTotal
    FROM dbo.Factura
    WHERE NumeroFactura = @NumeroFactura
      AND (@VendedorId IS NULL OR VendedorId = @VendedorId);

    ;WITH Detalle AS
    (
        SELECT
            a.AbonoId,
            a.FechaAbono,
            a.FechaRegistro,
            a.ValorAbono,
            a.ValorRetencion,
            a.ValorAbono + a.ValorRetencion AS TotalAplicado,
            ISNULL(fp.Descripcion, 'NO REGISTRADA') AS FormaPago,
            a.Observacion,
            DATEDIFF(DAY,
                     LAG(a.FechaAbono) OVER (ORDER BY a.FechaAbono, a.AbonoId),
                     a.FechaAbono)          AS DiasDesdeAbonoAnterior,
            @ValorTotal
                - SUM(a.ValorAbono + a.ValorRetencion)
                  OVER (ORDER BY a.FechaAbono, a.AbonoId
                        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS SaldoDespuesDelAbono,
            ROW_NUMBER() OVER (ORDER BY a.FechaAbono, a.AbonoId) AS Nro
        FROM dbo.Abono a
        LEFT JOIN dbo.FormaPago fp ON fp.FormaPagoId = a.FormaPagoId
        WHERE a.FacturaId = @FacturaId
    )
    SELECT
        R.Nro, R.NumeroFactura, R.NombreCliente, R.AbonoId, R.FechaAbono,
        R.FechaRegistro, R.DiasDesdeAbonoAnterior, R.ValorAbono,
        R.ValorRetencion, R.TotalAplicado, R.SaldoDespuesDelAbono,
        R.FormaPago, R.Observacion
    FROM
    (
    SELECT
        CAST(Nro AS VARCHAR(10))            AS Nro,
        f.NumeroFactura,
        c.NombreCompleto                    AS NombreCliente,
        d.AbonoId,
        d.FechaAbono,
        CAST(d.FechaRegistro AS DATETIME2(0)) AS FechaRegistro,
        d.DiasDesdeAbonoAnterior,
        d.ValorAbono,
        d.ValorRetencion,
        d.TotalAplicado,
        d.SaldoDespuesDelAbono,
        d.FormaPago,
        d.Observacion
    FROM Detalle d
    CROSS JOIN dbo.Factura f
    INNER JOIN dbo.Cliente c ON c.ClienteId = f.ClienteId
    WHERE f.FacturaId = @FacturaId

    UNION ALL

    SELECT
        'TOTAL',
        f.NumeroFactura,
        c.NombreCompleto,
        NULL, NULL, NULL, NULL,
        ISNULL(SUM(a.ValorAbono), 0),
        ISNULL(SUM(a.ValorRetencion), 0),
        ISNULL(SUM(a.ValorAbono + a.ValorRetencion), 0),
        @ValorTotal - ISNULL(SUM(a.ValorAbono + a.ValorRetencion), 0),
        CAST(NULL AS NVARCHAR(50)),
        N'Saldo actual de la factura (valor ' + FORMAT(@ValorTotal, 'N2') + N')'
    FROM dbo.Factura f
    INNER JOIN dbo.Cliente c ON c.ClienteId = f.ClienteId
    LEFT  JOIN dbo.Abono a   ON a.FacturaId = f.FacturaId
    WHERE f.FacturaId = @FacturaId
    GROUP BY f.NumeroFactura, c.NombreCompleto
    ) AS R
    ORDER BY CASE WHEN R.Nro = 'TOTAL' THEN 1 ELSE 0 END, R.FechaAbono, R.AbonoId;
END
GO

-- Sin parámetros; lista las facturas vigentes con saldo pendiente > 0. No
-- devuelve FacturaId (solo NumeroFactura) — el backend lo resuelve uniendo
-- contra dbo.Factura por NumeroFactura + FechaEmision + ValorTotal.
CREATE PROCEDURE dbo.sp_FacturasConSaldo
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        f.NumeroFactura,
        v.Nombres                                   AS Vendedor,
        c.NombreCompleto                            AS Cliente,
        f.FechaEmision,
        f.ValorTotal,
        ISNULL(ab.TotalPagado, 0)                   AS TotalPagado,
        f.ValorTotal - ISNULL(ab.TotalPagado, 0)    AS SaldoPendiente,
        ab.FechaUltimoAbono
    FROM dbo.Factura f
    INNER JOIN dbo.Vendedor v ON v.VendedorId = f.VendedorId
    INNER JOIN dbo.Cliente  c ON c.ClienteId  = f.ClienteId
    OUTER APPLY
    (
        SELECT SUM(a.ValorAbono + a.ValorRetencion) AS TotalPagado,
               MAX(a.FechaAbono)                    AS FechaUltimoAbono
        FROM dbo.Abono a
        WHERE a.FacturaId = f.FacturaId
    ) ab
    WHERE f.Anulada = 0
      AND f.ValorTotal - ISNULL(ab.TotalPagado, 0) > 0      -- solo con saldo
    ORDER BY SaldoPendiente DESC, f.FechaEmision;
END
GO

-- @NumeroFactura es obligatorio, misma validación con RAISERROR que
-- sp_DetalleAbonosFactura/sp_EstadoCuentaFactura. Devuelve DOS resultsets:
-- 1) cabecera con SaldoActual y Estado; 2) detalle de abonos con saldo
-- corrido. El backend solo usa el primero (estado_cuenta en abonos_service.py).
CREATE PROCEDURE dbo.sp_EstadoCuentaFactura
(
    @NumeroFactura  VARCHAR(20),
    @VendedorId     INT = NULL
)
AS
BEGIN
    SET NOCOUNT ON;

    IF @NumeroFactura IS NULL OR LTRIM(RTRIM(@NumeroFactura)) = ''
    BEGIN
        RAISERROR(N'Debe ingresar el número de factura.', 16, 1);
        RETURN;
    END

    DECLARE @Coincidencias INT;
    SELECT @Coincidencias = COUNT(*)
    FROM dbo.Factura
    WHERE NumeroFactura = @NumeroFactura
      AND (@VendedorId IS NULL OR VendedorId = @VendedorId);

    IF @Coincidencias = 0
    BEGIN
        RAISERROR(N'No existe una factura con el número %s.', 16, 1, @NumeroFactura);
        RETURN;
    END

    IF @Coincidencias > 1
    BEGIN
        RAISERROR(N'El número %s existe para más de un vendedor. Envíe también @VendedorId.', 16, 1, @NumeroFactura);
        RETURN;
    END

    DECLARE @FacturaId INT;
    SELECT @FacturaId = FacturaId
    FROM dbo.Factura
    WHERE NumeroFactura = @NumeroFactura
      AND (@VendedorId IS NULL OR VendedorId = @VendedorId);

    SELECT
        f.FacturaId,
        f.NumeroFactura,
        v.Nombres                                   AS Vendedor,
        c.ClienteId                                 AS CodigoCliente,
        c.NombreCompleto                            AS NombreCliente,
        f.FechaEmision,
        f.ValorTotal,
        ISNULL(t.TotalAbonado, 0)                   AS TotalAbonado,
        ISNULL(t.TotalRetenciones, 0)               AS TotalRetenciones,
        ISNULL(t.NumAbonos, 0)                      AS NumAbonos,
        t.FechaUltimoAbono,
        f.ValorTotal
            - ISNULL(t.TotalAbonado, 0)
            - ISNULL(t.TotalRetenciones, 0)         AS SaldoActual,
        CASE
            WHEN f.Anulada = 1 THEN 'ANULADA'
            WHEN f.ValorTotal - ISNULL(t.TotalAbonado,0) - ISNULL(t.TotalRetenciones,0) <= 0
                 THEN 'CANCELADO'
            WHEN ISNULL(t.NumAbonos, 0) = 0 THEN 'PENDIENTE'
            ELSE 'ABONO PARCIAL'
        END                                         AS Estado
    FROM dbo.Factura f
    INNER JOIN dbo.Vendedor v ON v.VendedorId = f.VendedorId
    INNER JOIN dbo.Cliente  c ON c.ClienteId  = f.ClienteId
    OUTER APPLY
    (
        SELECT SUM(a.ValorAbono)     AS TotalAbonado,
               SUM(a.ValorRetencion) AS TotalRetenciones,
               COUNT(*)              AS NumAbonos,
               MAX(a.FechaAbono)     AS FechaUltimoAbono
        FROM dbo.Abono a
        WHERE a.FacturaId = f.FacturaId
    ) t
    WHERE f.FacturaId = @FacturaId;

    SELECT
        ROW_NUMBER() OVER (ORDER BY a.FechaAbono, a.AbonoId)    AS Nro,
        a.AbonoId,
        a.FechaAbono,
        a.ValorAbono,
        a.ValorRetencion,
        a.ValorAbono + a.ValorRetencion                         AS TotalAplicado,
        ISNULL(fp.Descripcion, 'NO REGISTRADA')                 AS FormaPago,
        f.ValorTotal
            - SUM(a.ValorAbono + a.ValorRetencion)
              OVER (ORDER BY a.FechaAbono, a.AbonoId
                    ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS SaldoDespuesDelAbono,
        a.Observacion
    FROM dbo.Abono a
    INNER JOIN dbo.Factura f    ON f.FacturaId = a.FacturaId
    LEFT  JOIN dbo.FormaPago fp ON fp.FormaPagoId = a.FormaPagoId
    WHERE a.FacturaId = @FacturaId
    ORDER BY a.FechaAbono, a.AbonoId;
END
GO

-- @Nombre busca por coincidencia parcial (LIKE '%...%'); el resto son
-- filtros de igualdad. La paginación de 20 en 20 la hace el frontend sobre
-- el listado completo que devuelve el procedimiento.
CREATE PROCEDURE dbo.sp_ConsultarClientes
(
    @ClienteId         INT            = NULL,
    @Nombre            NVARCHAR(150)  = NULL,
    @Identificacion    VARCHAR(13)    = NULL,
    @CiudadId          INT            = NULL,
    @SegmentoRiesgoId  TINYINT        = NULL,
    @ClasificacionId   TINYINT        = NULL,
    @PlazoPagoId       TINYINT        = NULL
)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        c.ClienteId         AS CodigoCliente,
        c.NombreCompleto,
        c.Identificacion,
        c.Direccion,
        ISNULL(ci.Nombre, 'SIN CIUDAD')  AS Ciudad,
        c.Telefono,
        ISNULL(sr.Nombre, 'SIN SEGMENTO')       AS SegmentoRiesgo,
        ISNULL(cc.Nombre, 'SIN CLASIFICACIÓN')  AS Clasificacion,
        ISNULL(pp.Nombre, 'SIN PLAZO')          AS PlazoPago,
        c.LimiteCreditoPersonal,
        -- Límite vigente: el personal prevalece; si es NULL rige el del segmento
        ISNULL(c.LimiteCreditoPersonal, sr.LimiteCredito) AS LimiteCreditoVigente,
        CASE WHEN c.Activo = 1 THEN 'ACTIVO' ELSE 'INACTIVO' END AS Estado,
        c.FechaRegistro
    FROM dbo.Cliente c
    LEFT JOIN dbo.Ciudad ci                ON ci.CiudadId        = c.CiudadId
    LEFT JOIN dbo.SegmentoRiesgo sr        ON sr.SegmentoRiesgoId = c.SegmentoRiesgoId
    LEFT JOIN dbo.ClasificacionCliente cc  ON cc.ClasificacionId  = c.ClasificacionId
    LEFT JOIN dbo.PlazoPago pp             ON pp.PlazoPagoId      = c.PlazoPagoId
    WHERE (@ClienteId         IS NULL OR c.ClienteId = @ClienteId)
      AND (@Nombre            IS NULL OR c.NombreCompleto LIKE '%' + LTRIM(RTRIM(@Nombre)) + '%')
      AND (@Identificacion    IS NULL OR c.Identificacion = @Identificacion)
      AND (@CiudadId          IS NULL OR c.CiudadId         = @CiudadId)
      AND (@SegmentoRiesgoId  IS NULL OR c.SegmentoRiesgoId = @SegmentoRiesgoId)
      AND (@ClasificacionId   IS NULL OR c.ClasificacionId  = @ClasificacionId)
      AND (@PlazoPagoId       IS NULL OR c.PlazoPagoId      = @PlazoPagoId)
    ORDER BY c.NombreCompleto;
END
GO
